# Paper

This file lists methodology sources backing the procedure in this skill — cited in
Step 5's "References" section on every run (references were fixed when this skill was
built; end users are never asked about them).

**Citation format:** APA (7th ed.)

## James, Witten, Hastie & Tibshirani (2021)
Citation: James, G., Witten, D., Hastie, T., & Tibshirani, R. (2021). *An Introduction
to Statistical Learning with Applications in R* (2nd ed.). Springer.
https://www.statlearning.com/
