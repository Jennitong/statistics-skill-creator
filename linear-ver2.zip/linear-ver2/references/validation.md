# Validation

Checks the validity and correctness of the SKILL. There will be examples of inputs
and outcomes expected. The actual output generated using Claude is compared with
expected outcomes, and if the correctness rate is equal to 100%, the SKILL is overall
valid. Report the exact correctness.

Triggered when developer explicitly asks for the validity of the skill, the accuracy
and correctness of the test result, or anything similar.

## Input

Validation uses **simulated data** (no shipped data file) rather than a fixed dataset,
so each example's generating process is described below instead of literal values —
sample size, distributions/parameters, injected effect (or lack of one), and a fixed
random seed, so it can be regenerated deterministically.

All examples take these inputs:
- `data`: a data frame (simulated per example, or `mtcars` for Example 1)
- `response`: name of the continuous outcome column
- `predictors`: one or more predictor column names
- `alpha`: significance level (0.05 for all examples)

## Running the examples efficiently

Do **not** invoke the full conversational skill (Steps 0-5) separately for each of the
examples below — that requires numerous separate `Rscript` process starts plus rounds
of prose/plot generation and is unnecessarily slow. Since Step 4 of `SKILL.md` requires
every numerical result to come verbatim from `scripts/task_code1.R`, the
numerical/decision path is fully deterministic. To validate it quickly:

1. Write a single `Rscript` file for all examples (generate each simulated dataset with
   its stated seed, then call `validate_inputs()`/`main_function1()` from
   `scripts/task_code1.R` directly).
2. Compare each generated result against the expected outcome for that example. Exact
   wording does not need to match.
3. Only fall back to running the full conversational skill end-to-end with necessary
   plots, tables, or paragraphs if this script-level check reveals a discrepancy, to
   determine whether the bug is in the R scripts, in `SKILL.md`'s instructions, or in
   how the assistant is following them.

- Example 1 (Valid, real data)
Input: `mtcars`; response = `mpg`; predictors = `wt`, `hp`; alpha = 0.05
Output expected: Both `wt` and `hp` significant (negative coefficients), R-squared
around 0.82-0.83, no rejection at Step 1.

- Example 2 (Edge case, minimum sample size boundary)
Input: simulated `n = 4` rows, `response = y`, `predictors = c("x1", "x2")` (2
predictors, so minimum required is n > 3, i.e. n >= 4) — `set.seed(1)`;
`x1 <- rnorm(4)`; `x2 <- rnorm(4)`; `y <- 1 + 2*x1 - 1*x2 + rnorm(4, sd = 0.1)`
Output expected: Passes Step 1 validation (n = 4 > p + 1 = 3, i.e. exactly 1 residual
df) and `main_function1()` returns a fit without error.

- Example 3 (Deliberately invalid input — missing data)
Input: simulated `n = 30` rows, `response = y`, `predictors = c("x1")` — `set.seed(2)`;
`x1 <- rnorm(30)`; `y <- 1 + 2*x1 + rnorm(30)`; then set `y[5] <- NA`
Output expected: Rejected at Step 1 with an error naming `y` and "1 NA" — this skill
rejects runs with missing data rather than dropping rows silently.

- Example 4 (Valid, known true effect)
Input: simulated `n = 200` rows, `response = y`, `predictors = c("x1", "x2")` —
`set.seed(123)`; `x1 <- rnorm(200)`; `x2 <- rnorm(200)`;
`y <- 3 + 2*x1 - 1.5*x2 + rnorm(200, sd = 1)`
Output expected: Both `x1` (β ≈ 2, positive) and `x2` (β ≈ -1.5, negative)
significant at alpha = 0.05, R-squared reasonably high (> 0.8), VIF near 1 for both
(no collinearity). A few outlier/high-leverage flags may appear by chance (the
2×(p+1)/n rule flags ~5-10% of rows in normal data, and |studentized residual| > 3
occurs ~0.3% per row) — these are expected and do not count as a mismatch.

- Example 5 (Valid, no true relationship)
Input: simulated `n = 200` rows, `response = y`, `predictors = c("x1", "x2")` —
`set.seed(456)`; `x1 <- rnorm(200)`; `x2 <- rnorm(200)`; `y <- rnorm(200)` (generated
independently of `x1`, `x2`)
Output expected: Neither `x1` nor `x2` significant at alpha = 0.05, R-squared very low
(< 0.05), conclusion states no predictor term is significantly associated with `y`.

- Example 6 (Valid, collinearity violation)
Input: simulated `n = 200` rows, `response = y`, `predictors = c("x1", "x2")` —
`set.seed(789)`; `x1 <- rnorm(200)`; `x2 <- 0.98 * x1 + rnorm(200, sd = 0.05)`;
`y <- 2 + 1.5*x1 + 0.5*x2 + rnorm(200, sd = 1)`
Output expected: Model fits without error, but VIF for `x1` and `x2` is flagged
**severe** (VIF >= 10), demonstrating the collinearity check catches a near-collinear
predictor pair.

---
# Correctness Rate
Generate the actual output using the SKILL (see "Running the examples efficiently"
above for how to do this without separate full skill invocations), then verify if the
key values in the actual output are equivalent to the expected output shown above —
wording does not have to match exactly, and numerical values can be rounded.
Check whether the correctness rate is 100%; report the exact rate even if it is lower.

Report:
1. The correctness rate as a percentage
2. A markdown table with exactly these four columns: `Test | Outcome Expected | Outcome
   Generated | Match`, one row per example. Keep each cell terse, not a full paragraph.
3. If any example does not match, name it and explain the discrepancy in one sentence.
