# Guide

This file contains guidelines and conventions the model should follow when running
linear regression in this skill — the "why" and "how to interpret" behind the checks
in `assumptions.md`, not the checks themselves. All statistical framing here follows
James, Witten, Hastie & Tibshirani (2021), Ch. 3 — see `references/paper.md`.

## Why coefficients are reported in original units, not standardized

`scripts/task_code1.R` fits `lm()` directly on the response and predictors in their
original units — no z-score standardization. This matches how ISLR itself presents
multiple regression: a coefficient of, say, 21.4 on an income predictor means "a $1
increase in income is associated with a $21.40 increase in the response, holding the
other predictors fixed." Categorical predictors are dummy-coded automatically by
`lm()` (one indicator per non-reference level); their coefficients are still in the
response's original units — "the average difference in the response between this
level and the reference level, holding other predictors fixed."

Consequences to keep in mind when writing the report:
- The intercept is interpretable here (unlike a standardized fit, where it is
  mechanically ~0): it is the predicted response when every numeric predictor is 0 and
  every categorical predictor is at its reference level. Report it, but note explicitly
  when "predictor = 0" is not a realistic value in context.
- Coefficients across predictors measured in different units are **not** directly
  comparable in magnitude — a larger coefficient does not mean a "stronger" effect
  unless the predictors share a scale. Say so if the user seems to be comparing
  coefficient sizes across differently-scaled predictors.
- R², adjusted R², the F-statistic and its p-value, and VIF are the same whether or not
  the variables are standardized — standardizing does not change model fit, only the
  units the coefficients are expressed in.

## Why non-linearity, correlated errors, and heteroscedasticity are visual-only

This skill does not run a formal test (e.g. Breusch-Pagan) for these three — this
mirrors ISLR's own treatment in Sec. 3.3.3, which relies on the residual plot rather
than a single test statistic. A single p-value would invite over-precise claims about
a pattern that is really a matter of degree and judgment; the residuals-vs-fitted plot
(`scripts/diagnostic.R`) is the direct, standard diagnostic for both non-linearity and
non-constant variance simultaneously.

Instead, describe what `residuals_vs_fitted.png` actually shows, in plain language,
and reach a holds/violated judgment from that description alone for each of the two
things it reveals (curvature → non-linearity; funnel shape → heteroscedasticity). Do
not compute or report a p-value for either.

## Why this skill rejects missing data instead of dropping it

Unlike some regression skills that listwise-delete rows with missing values, this
skill's Step 1 **rejects** the run entirely if any missing value is present among the
used columns (see `SKILL.md` Non-negotiable rules). This is a deliberate, stricter
policy: silently dropping rows can change which model is actually fit without the
user's awareness (e.g. if missingness is not random). If the user wants missing rows
excluded, that must be an explicit request/re-run with cleaned data — this skill will
not decide that for them.

## How to interpret assumption failures generally

- If an item is violated, name which one and explain in plain language what that means
  for the reliability of the result (see `assumptions.md` for the specific guidance per
  item).
- This skill's policy is **flag and caveat, not auto-correct**: when any of the six
  items looks violated, report the OLS result with a clearly stated caveat. Do not
  silently switch to a different method (robust SEs, WLS, dropping a predictor or
  observation) to fix it. If the user wants an alternative approach after seeing the
  caveat, that is a separate, explicit request.
- State whether a variable transformation could plausibly help (e.g. log-transforming
  a skewed predictor for a non-linearity or heteroscedasticity violation), but do not
  apply one without the user's confirmation.

## Common pitfalls to avoid

- Don't drop rows, outliers, or high-leverage points without flagging it in the report
  and explaining why.
- Don't treat a high R² on a tiny sample as strong evidence — check the residual
  degrees-of-freedom in Step 4's output and downweight the interpretation if it's low.
- A column that is clearly a free-text or identifier field (e.g. a street address) is
  never a valid response or predictor for linear regression — Step 1 rejects this, but
  flag it in EDA too if noticed early.
- Don't invent a p-value for non-linearity, correlated errors, or heteroscedasticity —
  those three are visual-only by design (see above); only outliers, leverage, and VIF
  get a numeric verdict.
- Don't compare a raw-unit coefficient's magnitude across predictors measured on
  different scales as if it indicated relative importance.
