---
name: linear-ver2
description: >
  Runs OLS multiple linear regression end to end, following James, Witten, Hastie &
  Tibshirani's ISLR (2nd ed., 2021): rejects missing data instead of dropping it,
  checks ISLR Sec. 3.3.3's six potential problems (non-linearity, correlated errors,
  heteroscedasticity, outliers, high-leverage points, collinearity), fits in original
  units, and writes a fitted-model / coefficient-interpretation report at a
  brief/moderate/detailed depth the client picks each run. Trigger whenever the user
  asks to model, predict, or explain a continuous outcome from predictors, mentions
  "multiple linear regression", "OLS", "regression coefficients", "R-squared", "least
  squares", or describes a dataset/question that maps here even without naming the
  test. Also trigger on the skill's own name, linear-ver2.
---

# Linear Regression (OLS) — linear-ver2

## Non-negotiable rules

- Fit and report coefficients in the variables' **original units** — never
  standardize/z-score the response or predictors. Categorical/factor predictors are
  dummy-coded by `lm()`. See `references/guide.md` for why.
- Always report R² / adjusted R² / residual standard error alongside coefficient
  p-values — never p-values alone.
- **Reject** (do not silently drop) any run where the response or a used predictor
  contains a missing value — stop with a clear error naming the affected column(s) and
  how many missing values. See `references/guide.md` for why this skill is stricter
  than listwise deletion.
- Require strictly more observations than predictor terms + 1 (n > p + 1), so at least
  one residual degree of freedom remains — stop otherwise.
- Run and report all 6 assumption checks (Step 3, per ISLR Sec. 3.3.3) before
  presenting the Step 5 output. Non-linearity, correlation of errors, and
  heteroscedasticity are assessed **visually only** (no formal test, no p-value);
  outliers (|studentized residual| > 3), high-leverage points (leverage >
  2×(p+1)/n), and collinearity (VIF: 5 ≤ VIF < 10 moderate, VIF ≥ 10 severe) are the
  three numeric checks.
- Use two-sided significance tests unless the user explicitly asks for one-sided.
- If an assumption looks violated (from the plots, or from the outlier/leverage/VIF
  checks), flag it and caveat the result. Do not silently switch to a different method
  (e.g. robust standard errors, weighted least squares) or drop predictors/observations
  to fix it.
- This skill produces exactly **one** result type — fitted-model / coefficient
  interpretation in original units — so Step 5 never asks which kind of result the
  client wants; it only asks the response depth (brief/moderate/detailed).

## Inputs

- `data`: a data frame or a path to a CSV file containing the response and predictor
  columns.
- `response`: name of the continuous outcome column.
- `predictors`: one or more column names to use as predictors (numeric and/or
  categorical/factor).
- `alpha` (optional, default 0.05): significance level.

---

## Step 0 — Extract Inputs

References for this skill were gathered and fixed when it was built (see
`references/paper.md`) — do not ask the end user about references at all. Step 5's
References section always includes the pre-formatted citation.

If the user's request is phrased as a sentence rather than explicit arguments, extract
and store: which dataset/file, which column is the response, which columns are
predictors, and the alpha level (default 0.05 if not stated).

---

## Step 1 — Validate Inputs

Before running any tasks, check all of the following. If any check fails, report the
issue clearly and stop.

- `data` must be a data frame, or a path to a CSV file that exists and can be read.
- `response` and every name in `predictors` must be columns present in `data`.
- `response` must be numeric, or coercible to numeric without introducing new `NA`
  values. If coercion introduces `NA`s (e.g. the column is free text), reject with:
  "NAs introduced by coercion. Invalid response type: `<column>` is not continuous.
  Linear regression requires a continuous response."
- Each predictor must be numeric, or categorical with a manageable number of distinct
  levels (not a free-text or identifier-like column — more than 20 distinct
  non-numeric values, or as many distinct values as rows, is rejected).
- `alpha` must be strictly between 0 and 1.
- **No missing values are allowed** in `response` or any column in `predictors`. If
  any are found, reject with an error naming the column(s) and how many missing values
  each has — do not drop rows.
- After the above checks pass, the number of rows must satisfy `n > length(predictors)
  + 1`; otherwise stop with an error naming `n` and the minimum required.

---

## Step 2 — Explorative Data Analysis

Create any plots, tables, or numerical summarization in this section, on the data in
its original units (this skill never standardizes variables at any step).

Refer to `references/eda.md` for the full procedure. For the exact code to generate the
table and plots, refer to `scripts/eda_code.R`. After the table and all plots are
shown, ask the client using the exact words **All of the preliminary plots are
displayed. Continue to assumption checks?**

## Step 3 — Check Assumptions

Before showing results, briefly verify the six potential problems for multiple linear
regression from James, Witten, Hastie & Tibshirani (2021), Sec. 3.3.3.

Visual only (no formal test, no p-value)
- Non-linearity of the response-predictor relationships
- Correlation of error terms
- Non-constant variance of error terms (heteroscedasticity)

Numeric
- Outliers — |studentized residual| > 3
- High-leverage points — leverage > 2×(p+1)/n
- Collinearity — VIF (5 ≤ VIF < 10 moderate, VIF ≥ 10 severe)

To check all six, refer to `references/assumptions.md`. For the statistical reasoning
behind why the first three are visual-only by design, why coefficients are reported in
original units, and how to interpret a violation, see `references/guide.md`; for the
citable methodology behind the checks and thresholds, see `references/paper.md`. For
the actual checks, refer to `scripts/diagnostic.R`, which builds the same fit used in
Step 4 (via `scripts/task_code1.R`'s `prepare_data()`/`run_test()`) and produces
`residuals_vs_fitted.png` (non-linearity + heteroscedasticity) and
`residuals_vs_leverage.png` (outliers + high-leverage points, with reference lines),
plus the numeric outlier/leverage/VIF results. Display both plots inline (per
`references/eda.md`'s Read-tool rules) and describe the pattern you see in each — do
not invent a p-value for any of the three visual-only items.

All of the assumptions should be checked and verified by the user before any actual
output in Step 5. Whenever an assumption is verified — numerically (outliers,
leverage, VIF) or visually (non-linearity, correlated errors, heteroscedasticity) —
ask the client whether they want to review and decide on that item's verdict
themselves, or would rather leave the decision to the AI's judgment; proceed according
to their answer, and default to deciding it yourself if they decline to choose.

Explicitly ask:
> "Would you like to review and decide on each assumption by yourself, or should AI
> Agent do this for you?"

Do not skip this question — ask it before EDA and assumption checks so the user could
choose and AI knows what format of assumption checks should be provided.
- If the client wants to decide by themselves, check and show items one by one,
  comment on each numerical value or plot used, interpret and warn anything unusual,
  then ask for the client's opinion of whether the item seems to hold for **each**
  item. Proceed to the next item only when the previous one is verified and agreed by
  the client. Otherwise, provide suggestions (could refer to `references/guide.md`)
  that could make the assumption hold.
- If the client wants to let AI Agent decide, show all six items at once, interpret
  what is observed and what that means, and state the final decision about whether each
  holds. If any is violated, suggest solutions per `references/guide.md`; otherwise
  state that all six hold.

## Step 4 — Execute R Code and Extract Results

### Which script to run

| Test type | Script | Function |
|---|---|---|
| OLS linear regression (numeric and/or categorical predictors) | `scripts/task_code1.R` | `main_function1(data, response, predictors, alpha = 0.05)` |

### Running the script

Run the R script using the Bash tool. This is the authoritative computation step — AI
should not calculate any numerical outputs by itself. All numerical results must come
directly from the output of this command.

From the skill's directory (the folder containing this `SKILL.md`), run:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/task_code1.R')
data <- read.csv('<path-to-data-csv>')
main_function1(data = data, response = '<response_extracted>',
                predictors = c(<predictors_extracted>),
                alpha = <alpha_extracted_or_0.05>)
"
```

Replace the placeholders with the inputs extracted earlier. Replace
`<path-to-skill-directory>` with the actual absolute path to the folder containing this
`SKILL.md`, and `<path-to-data-csv>` with the dataset path (or use `data.frame(...)`/
built-in data directly instead of `read.csv` when the client supplied inline values or
a built-in R dataset such as `mtcars`).

The function prints a full result block to stdout. From that output, extract:
- The fitted formula
- The coefficient table (estimate, std. error, t value, p-value per term), in original
  units
- R-squared, adjusted R-squared, and residual standard error
- The F-statistic and its p-value
- Which rows (if any) are flagged as outliers and as high-leverage points
- The VIF table and moderate/severe collinearity verdict
- The residual degrees-of-freedom check
- The conclusion paragraph

Use these extracted values verbatim when writing the Step 5 report. Do not recompute or
reword numerical results. Non-linearity, correlation of errors, and heteroscedasticity
are not in this script's output — those come from Step 3's plots, described in your
own words.

### If the script fails

Surface the R error message verbatim to the user and stop — do not guess at what the
result would have been, and do not silently fall back to a different test. Common causes
worth checking first: a missing R package (`car`, `gtsummary`, `flextable` — tell the
user which one to install), inputs that don't match the function's expected shape
(revisit Step 1), or a path issue (confirm `<path-to-skill-directory>` and
`<path-to-data-csv>` are correct).

## Step 5 - Output

This skill produces exactly one result type — **fitted-model / coefficient
interpretation** (which predictors matter, effect sizes in original units, R²) — so no
question is asked about which kind of result to produce. Ask only for the response
depth, using the exact wording below:

> Would you like a **brief** (key result, assumptions, numerical values),
> **moderate** (adds context and supporting tables and plots), or **detailed**
> (full background, definitions, and step-by-step interpretation) response?

Output **exactly** the above sentence — nothing before it, nothing after except
waiting for the user's reply. Do not show formulas, intermediate tables, or any other
text.

**Tone:** Professional but accessible. Write for a stakeholder who understands
"statistically significant" but does not need to verify the math. Never show R code in
the output; any exported report must use `echo = FALSE` in its setup chunk. Define
specific statistical terminology (e.g. "studentized residual," "leverage," "VIF") the
first time it's used.

**Table formatting:** use bold headers, alignment markers, and a section break between
tables.

---

### Brief

Exactly one paragraph covering: the fitted formula, whether all six ISLR assumptions
were checked and their holds/violated verdicts, the coefficient table's key values (in
original units), R², adjusted R², residual standard error, and which predictors are
significantly associated with the response at the stated alpha.

No table or plot displayed.

---

### Moderate

A single cohesive paragraph covering all elements in exact order:

1. **Background** — dimension of the dataset (n, predictors), what the response and
   predictors represent, unit of observation.
2. **Method chosen and assumptions** — OLS via `lm()`, why it fits the question, all
   six ISLR items and their verdicts.
3. **Key result and numerical outputs** — coefficient table, R², adjusted R², residual
   standard error, F-statistic and p-value.
4. **Decision** — which predictors are significant at alpha, plain-language direction
   and magnitude of each significant effect.
5. **Key plot and table** — the Step 3 residuals-vs-fitted plot, and the Step 2
   summary statistics table.

---

### Detailed

The full **Moderate** paragraph, table and plot, then:

A short **Plain-language interpretation** written for a non-statistical audience: what
the significant coefficient(s) mean practically, what can and cannot be concluded
(correlation vs. causation, generalizability), any caveats from violated assumptions
or a low residual-degrees-of-freedom count, and the definitions of "R²," "VIF,"
"leverage," and "studentized residual."

---
Return the following based on the response brief/moderate/detailed level, in order:

**Background**
The context of the problem, dataset dimensions, and what response/predictors
represent.

**The assumptions held**

Refer to Step 3 and briefly state the six ISLR items and their verdicts.

**key result**

Refer to Step 4 and interpret the coefficient table, R², adjusted R², residual
standard error.

**decision**

Refer to Step 4 and interpret which predictors are significant at alpha, and their
direction/magnitude.

**plot 1** (in EDA)

Only shown for `detailed` or `moderate` response levels. Refer to Step 2's
scatterplot(s)/boxplot(s) and interpret.

**table 1** (in EDA)

Only shown for `detailed` or `moderate` response levels. Refer to Step 2's summary
statistics table and interpret.

**plot 2** (not in EDA)

Only shown for `detailed` or `moderate` response levels. The Step 3
`residuals_vs_fitted.png` diagnostic plot.
- Axis labels: x = "Fitted values", y = "Residuals"
- Title: "Residuals vs. Fitted"
- Annotation: describe curvature (non-linearity) and funnel shape (heteroscedasticity)
- Color: zero-reference line in red, lowess smoother in blue (as generated by
  `scripts/diagnostic.R`)

**table 2** (not in EDA)

Only shown for `detailed` or `moderate` response levels. The coefficient table:
`Term | Estimate | Std. Error | t value | Pr(>|t|)`. Each row is one model term
(intercept plus each predictor/dummy level), taken verbatim from Step 4's output.

**References**

Only shown for `detailed` or `moderate` response levels. Always include this section —
references were fixed at creation time (see `references/paper.md`):

James, G., Witten, D., Hastie, T., & Tibshirani, R. (2021). *An Introduction to
Statistical Learning with Applications in R* (2nd ed.). Springer.
https://www.statlearning.com/

---

**Formatting conventions** (apply consistently so reports don't vary run to run):
- P-values: report as `p = 0.0004` down to 3 significant figures; below that, report as
  `p < .001` rather than more decimal places.
- Coefficients and test statistics: 3 significant figures unless the input data's
  precision warrants more.
- Significance level: state the alpha used (default 0.05) explicitly in Results.

---

### Notation

- `β` — a regression coefficient in the response's original units: the expected change
  in the response per one-unit increase in the predictor, holding other predictors
  fixed (for a dummy-coded categorical level, the expected difference from the
  reference level).
- VIF — Variance Inflation Factor, a multicollinearity diagnostic.
- Leverage (hat value) — a measure of how unusual a predictor value is relative to the
  others; used to flag high-leverage points (ISLR eq. 3.37).
- Studentized residual — a residual divided by its estimated standard deviation; used
  to flag outliers.

---

## Examples

### Example 1 — Valid, two numeric predictors (mtcars)
Input: `mtcars`; response = `mpg`; predictors = `wt`, `hp`

> Fitting `mpg` on `wt` and `hp` in their original units, both predictors are
significant and negative (wt: β ≈ -3.88, p < .001; hp: β ≈ -0.032, p = .0015). R² ≈
0.827, adjusted R² ≈ 0.815. No severe outliers; a few high-leverage points. VIF is low
for both (no collinearity). The residuals-vs-fitted plot shows roughly even scatter
with no strong curve (linearity and homoscedasticity hold).

### Example 2 — Deliberately invalid input, missing data
Input: `mtcars` with `mpg[1]` set to `NA`; response = `mpg`; predictors = `wt`

> Rejected at Step 1: "Missing values found in column(s): mpg (1 NA). This skill
rejects runs with missing data in used columns rather than dropping rows silently —
clean the data or exclude the affected column(s) and re-run."

### Example 3 — Edge case, minimum sample size boundary
Input: first 4 rows of `mtcars`; response = `mpg`; predictors = `wt`, `hp`, `qsec`

> With n = 4 and 3 predictor terms, n = p + 1 exactly (0 residual degrees of freedom) —
rejected at Step 1: "Sample size too small: n = 4 rows but 3 predictor(s) require n >
4."

---

# Validation steps: this step is only for developer, not for SKILL user
Should be hidden unless explicitly mentioned. This step is only disclosed when
developer explicitly asks for testing the validity of the SKILL. This is different
from Step 1 Validate Inputs. It is used only for checking the validity of the entire
SKILL.md file. Do not mention anything related to this step for regular SKILL user.

Refer to `references/validation.md` for validation steps.

- **Note:** ignore output-formatting/response-depth differences during validation.
  Only check if the key numerical values from expectation and actual computation
  match. Non-linearity, correlation of errors, and heteroscedasticity are visual-only
  and are not part of this numeric check.
- **Speed:** run all 6 example inputs through a single batched `Rscript` call (see
  "Running the examples efficiently" in `references/validation.md`) rather than
  invoking the full conversational Steps 0–5 six separate times. Only fall back to a
  full conversational run for a specific example if the batched script-level check
  disagrees with the expected outcome for that example.
- **Output:** report the correctness rate as a percentage, followed by a 4-column
  markdown table (`Test | Outcome Expected | Outcome Generated | Match`) with one row
  per example.
