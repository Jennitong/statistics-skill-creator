# eda_code.R
#
# EDA for linear-ver2: store the input data frame as `dat`, the response column name
# as `response`, and predictor column names as `predictors` (a character vector).
# Continuous predictors get a scatterplot vs. the response; categorical predictors get
# a boxplot of the response by group. A gtsummary/flextable summary table is also
# produced. All plots/table are saved as PNGs to `plot_dir` for inline display via the
# Read tool (see references/eda.md).

suppressMessages({
  library(gtsummary)
  library(flextable)
})

run_eda <- function(data, response, predictors, plot_dir = tempdir()) {
  if (is.character(data) && length(data) == 1) {
    data <- read.csv(data, stringsAsFactors = FALSE)
  }
  dat <- data[, c(response, predictors), drop = FALSE]

  ## Summary statistics table
  tbl <- gtsummary::tbl_summary(dat)
  tbl_flex <- gtsummary::as_flex_table(tbl)
  summary_path <- file.path(plot_dir, "summary_table.png")
  flextable::save_as_image(tbl_flex, path = summary_path)

  plot_paths <- c(summary_table = summary_path)
  correlations <- list()

  for (p in predictors) {
    x <- dat[[p]]
    y <- dat[[response]]
    if (is.numeric(x)) {
      ## Continuous predictor: scatterplot vs. response
      path <- file.path(plot_dir, paste0("scatter_", p, ".png"))
      png(path, width = 800, height = 600)
      plot(x, y, xlab = p, ylab = response,
           main = paste("The scatter plot between", p, "and", response))
      dev.off()
      plot_paths[paste0("scatter_", p)] <- path
      correlations[[p]] <- cor(x, y, use = "complete.obs")
    } else {
      ## Categorical predictor: boxplot of response by group
      path <- file.path(plot_dir, paste0("boxplot_", p, ".png"))
      png(path, width = 800, height = 600)
      boxplot(y ~ x, xlab = p, ylab = response,
              main = paste("The boxplot of", response, "by", p))
      dev.off()
      plot_paths[paste0("boxplot_", p)] <- path
    }
  }

  list(plot_paths = plot_paths, correlations = correlations, n = nrow(dat))
}
