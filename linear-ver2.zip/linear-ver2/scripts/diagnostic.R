# diagnostic.R
#
# Visual assumption-check code for linear regression, used in Step 3 of SKILL.md
# (before the authoritative fit in scripts/task_code1.R is reported in Step 4). It
# sources task_code1.R so the fit used for assumption-checking is built by the exact
# same prepare_data()/run_test() logic as the final reported model.
#
# Per ISLR (James, Witten, Hastie & Tibshirani, 2021) Sec. 3.3.3, three of the six
# potential problems are assessed VISUALLY here:
#   - residuals_vs_fitted.png: a curved pattern flags non-linearity; a funnel/fan
#     shape flags non-constant variance (heteroscedasticity).
#   - residuals_vs_leverage.png: studentized residuals vs. leverage, with reference
#     lines at +/-3 (outlier threshold) and at the leverage threshold -- points beyond
#     either line are flagged as outliers / high-leverage points respectively.
# Correlation of error terms (independence) is assessed narratively from how the data
# was collected (see references/assumptions.md), not from a plot. Outliers,
# high-leverage points, and collinearity (VIF) get numeric verdicts from
# scripts/task_code1.R's check_assumptions() and are also drawn onto
# residuals_vs_leverage.png here.
#
# Usage (run from the skill's own directory, same as scripts/task_code1.R):
#   source("scripts/task_code1.R")
#   source("scripts/diagnostic.R")
#   run_diagnostics(data, response = "y", predictors = c("x1", "x2"))
#
# This script assumes scripts/task_code1.R has already been sourced (for
# validate_inputs(), prepare_data(), run_test(), check_assumptions()).

run_diagnostics <- function(data, response, predictors, plot_dir = tempdir()) {
  if (is.character(data) && length(data) == 1) {
    data <- read.csv(data, stringsAsFactors = FALSE)
  }
  validate_inputs(data, response, predictors)
  prepped <- prepare_data(data, response, predictors)
  result <- run_test(prepped, response, predictors)
  fit <- result$fit
  assump <- check_assumptions(fit)

  ## Items 1-3 (visual only): non-linearity, correlated errors, heteroscedasticity
  rvf_path <- file.path(plot_dir, "residuals_vs_fitted.png")
  png(rvf_path, width = 800, height = 600)
  plot(fitted(fit), resid(fit),
       xlab = "Fitted values", ylab = "Residuals",
       main = "Residuals vs. Fitted")
  abline(h = 0, col = "red", lty = 2)
  lines(lowess(fitted(fit), resid(fit)), col = "blue")
  dev.off()

  ## Items 4-5: outliers (|studentized residual| > 3) and high-leverage points
  ## (leverage > 2*(p+1)/n), drawn together as in ISLR Fig. 3.13.
  rstud <- rstudent(fit)
  hats <- hatvalues(fit)
  rvl_path <- file.path(plot_dir, "residuals_vs_leverage.png")
  png(rvl_path, width = 800, height = 600)
  plot(hats, rstud,
       xlab = "Leverage", ylab = "Studentized Residuals",
       main = "Studentized Residuals vs. Leverage")
  abline(h = c(-3, 3), col = "red", lty = 2)
  abline(v = assump$leverage$threshold, col = "red", lty = 2)
  dev.off()

  list(
    residuals_vs_fitted_plot = rvf_path,
    residuals_vs_leverage_plot = rvl_path,
    outliers = assump$outliers,
    leverage = assump$leverage,
    vif = assump$vif,
    moderate_vif = assump$moderate_vif,
    severe_vif = assump$severe_vif
  )
}
