# task_code1
#
# Task for this R file: fit an ordinary least squares (OLS) linear regression of a
# continuous response on one or more predictors (numeric and/or categorical). Per
# James, Witten, Hastie & Tibshirani (2021, "An Introduction to Statistical Learning
# with Applications in R", 2nd ed.), Ch. 3, the model is fit and reported in the
# variables' ORIGINAL units -- coefficients are not standardized. Categorical
# predictors are dummy-coded automatically by lm().
#
# Six potential problems from ISLR Sec. 3.3.3 are checked: (1) non-linearity, (2)
# correlation of error terms, (3) non-constant variance of error terms
# (heteroscedasticity), (4) outliers, (5) high-leverage points, (6) collinearity.
# (1)-(3) are visual (see scripts/diagnostic.R); (4)-(6) have a numeric rule here.
#
# Unlike a "drop-and-warn" policy, this skill REJECTS any run where the response or a
# used predictor contains a missing value -- see validate_inputs() below and
# references/guide.md for why.

suppressMessages({
  library(car)
})

# ---- 1. validate_inputs --------------------------------------------------

validate_inputs <- function(data, response, predictors, alpha = 0.05) {
  if (!is.data.frame(data)) stop("`data` must be a data frame.")
  all_cols <- c(response, predictors)
  missing_cols <- setdiff(all_cols, names(data))
  if (length(missing_cols) > 0) {
    stop(sprintf("Column(s) not found in data: %s", paste(missing_cols, collapse = ", ")))
  }

  # Response must be numeric, or coercible to numeric without introducing new NAs.
  y_raw <- data[[response]]
  if (!is.numeric(y_raw)) {
    n_na_before <- sum(is.na(y_raw))
    y_coerced <- suppressWarnings(as.numeric(as.character(y_raw)))
    n_na_after <- sum(is.na(y_coerced))
    if (n_na_after > n_na_before) {
      stop(sprintf(
        "NAs introduced by coercion. Invalid response type: `%s` is not continuous. Linear regression requires a continuous response.",
        response
      ))
    }
  }

  # Predictors: numeric, or categorical with a manageable number of levels (not a
  # free-text/ID-like column).
  for (p in predictors) {
    x <- data[[p]]
    if (!is.numeric(x)) {
      n_levels <- length(unique(x[!is.na(x)]))
      if (n_levels > 20 || n_levels == nrow(data)) {
        stop(sprintf(
          "Predictor `%s` has %d distinct non-numeric values and looks like free text or an identifier, not a categorical predictor.",
          p, n_levels
        ))
      }
    }
  }

  if (!is.numeric(alpha) || alpha <= 0 || alpha >= 1) {
    stop("`alpha` must be a number strictly between 0 and 1.")
  }

  # Reject (do not silently drop) any missing value in a used column.
  na_counts <- vapply(all_cols, function(col) sum(is.na(data[[col]])), integer(1))
  if (any(na_counts > 0)) {
    bad <- na_counts[na_counts > 0]
    stop(sprintf(
      "Missing values found in column(s): %s. This skill rejects runs with missing data in used columns rather than dropping rows silently -- clean the data or exclude the affected column(s) and re-run.",
      paste(sprintf("%s (%d NA)", names(bad), bad), collapse = ", ")
    ))
  }

  # Require strictly more observations than predictor terms + 1, i.e. n > p + 1,
  # so at least one residual degree of freedom remains.
  n <- nrow(data)
  p <- length(predictors)
  if (!(n > p + 1)) {
    stop(sprintf(
      "Sample size too small: n = %d rows but %d predictor(s) require n > %d (at least one residual degree of freedom). Provide more data or fewer predictors.",
      n, p, p + 1
    ))
  }

  invisible(TRUE)
}

# ---- 2. prepare_data: coerce types (no standardization, no row-dropping) ----

prepare_data <- function(data, response, predictors) {
  data[[response]] <- as.numeric(as.character(data[[response]]))
  for (p in predictors) {
    if (!is.numeric(data[[p]])) data[[p]] <- factor(data[[p]])
  }
  list(data = data, n_used = nrow(data))
}

# ---- 3. check_assumptions --------------------------------------------------
# Numeric checks only for outliers, high-leverage points, and collinearity (ISLR
# Sec. 3.3.3, items 4-6). Non-linearity, correlated errors, and heteroscedasticity
# (items 1-3) are visual-only -- see scripts/diagnostic.R and references/guide.md.

check_assumptions <- function(fit) {
  n <- length(resid(fit))
  p <- length(coef(fit)) - 1  # number of predictor terms (excludes intercept)

  # Outliers: |studentized residual| > 3 (ISLR Sec. 3.3.3).
  rstud <- rstudent(fit)
  outlier_idx <- which(abs(rstud) > 3)

  # High leverage: leverage statistic > 2 * (p+1)/n, i.e. twice the average leverage
  # (p+1)/n defined in ISLR eq. 3.37.
  hats <- hatvalues(fit)
  leverage_threshold <- 2 * (p + 1) / n
  leverage_idx <- which(hats > leverage_threshold)

  # Collinearity: VIF, two-tier (5 <= VIF < 10 moderate, VIF >= 10 severe).
  vif <- if (p > 1) tryCatch(suppressMessages(suppressWarnings(car::vif(fit))), error = function(e) NA) else NA
  vif_vec <- if (!identical(vif, NA)) {
    if (is.matrix(vif)) vif[, 1] else vif
  } else NA
  moderate_vif <- if (!identical(vif_vec, NA)) names(vif_vec)[vif_vec >= 5 & vif_vec < 10] else character(0)
  severe_vif <- if (!identical(vif_vec, NA)) names(vif_vec)[vif_vec >= 10] else character(0)

  list(
    outliers = list(idx = outlier_idx, values = rstud[outlier_idx]),
    leverage = list(idx = leverage_idx, values = hats[leverage_idx], threshold = leverage_threshold),
    vif = vif,
    moderate_vif = moderate_vif,
    severe_vif = severe_vif
  )
}

# ---- 4. run_test: build formula and fit ------------------------------------

run_test <- function(prepped, response, predictors) {
  formula_str <- paste(response, "~", paste(predictors, collapse = " + "))
  fit <- lm(as.formula(formula_str), data = prepped$data)
  list(fit = fit, formula = formula_str)
}

# ---- 5. report_conclusion --------------------------------------------------
# Single result type this skill supports: fitted-model / coefficient interpretation
# in original units (R-squared, adjusted R-squared, residual SE always reported).

report_conclusion <- function(result, prepped, response, alpha = 0.05) {
  fit <- result$fit
  s <- summary(fit)
  assump <- check_assumptions(fit)

  cat("=== Linear Regression Result (original units) ===\n")
  cat("Formula:", result$formula, "\n")
  cat("Rows used:", prepped$n_used, "\n\n")

  cat("Coefficients:\n")
  print(s$coefficients)
  cat("\n")

  cat(sprintf("R-squared: %.4f, Adjusted R-squared: %.4f, Residual std. error: %.4f on %d df\n",
              s$r.squared, s$adj.r.squared, s$sigma, s$df[2]))
  fstat <- s$fstatistic
  f_pval <- pf(fstat[1], fstat[2], fstat[3], lower.tail = FALSE)
  cat(sprintf("F-statistic: %.3f on %d and %d DF, p-value: %.4g\n\n", fstat[1], fstat[2], fstat[3], f_pval))

  cat("--- Assumption checks (ISLR Sec. 3.3.3) ---\n")
  cat("Non-linearity, correlation of errors, heteroscedasticity: assessed visually (see scripts/diagnostic.R's residuals_vs_fitted.png) -- no numeric test run for these.\n")

  if (length(assump$outliers$idx) > 0) {
    cat(sprintf("Outliers: %d observation(s) with |studentized residual| > 3, at row(s): %s\n",
                length(assump$outliers$idx), paste(assump$outliers$idx, collapse = ", ")))
  } else {
    cat("Outliers: none (no |studentized residual| > 3)\n")
  }

  if (length(assump$leverage$idx) > 0) {
    cat(sprintf("High-leverage points: %d observation(s) exceed leverage threshold %.4f, at row(s): %s\n",
                length(assump$leverage$idx), assump$leverage$threshold, paste(assump$leverage$idx, collapse = ", ")))
  } else {
    cat(sprintf("High-leverage points: none (threshold %.4f)\n", assump$leverage$threshold))
  }

  if (!identical(assump$vif, NA)) {
    cat("VIF:\n"); print(assump$vif)
    if (length(assump$severe_vif) > 0) {
      cat(sprintf("Collinearity: SEVERE for %s (VIF >= 10)\n", paste(assump$severe_vif, collapse = ", ")))
    }
    if (length(assump$moderate_vif) > 0) {
      cat(sprintf("Collinearity: moderate for %s (5 <= VIF < 10)\n", paste(assump$moderate_vif, collapse = ", ")))
    }
    if (length(assump$severe_vif) == 0 && length(assump$moderate_vif) == 0) {
      cat("Collinearity: OK (all VIF < 5)\n")
    }
  } else {
    cat("VIF: not applicable (fewer than 2 predictor terms)\n")
  }

  n_predictor_terms <- length(coef(fit)) - 1
  n_obs <- prepped$n_used
  df_resid <- s$df[2]
  cat(sprintf("Sample size check: n = %d, predictor terms = %d, residual df = %d\n\n",
              n_obs, n_predictor_terms, df_resid))

  sig_terms <- rownames(s$coefficients)[-1][s$coefficients[-1, "Pr(>|t|)"] < alpha]
  cat("--- Conclusion ---\n")
  if (length(sig_terms) > 0) {
    cat(sprintf(
      "At alpha = %.2f, the following predictor(s) are significantly associated with %s: %s. Model R-squared = %.4f (adjusted %.4f).\n",
      alpha, response, paste(sig_terms, collapse = ", "), s$r.squared, s$adj.r.squared
    ))
  } else {
    cat(sprintf(
      "At alpha = %.2f, no predictor term is significantly associated with %s. Model R-squared = %.4f (adjusted %.4f).\n",
      alpha, response, s$r.squared, s$adj.r.squared
    ))
  }

  invisible(list(fit = fit, summary = s, assumptions = assump))
}

# ---- main -------------------------------------------------------------

main_function1 <- function(data, response, predictors, alpha = 0.05) {
  if (is.character(data) && length(data) == 1) {
    data <- read.csv(data, stringsAsFactors = FALSE)
  }
  validate_inputs(data, response, predictors, alpha)
  prepped <- prepare_data(data, response, predictors)
  result <- run_test(prepped, response, predictors)
  report_conclusion(result, prepped, response, alpha)
}
