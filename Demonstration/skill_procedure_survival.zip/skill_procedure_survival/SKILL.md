---
name: skill-procedure-survival
description: >

  Performs a survival analysis in R given a dataset with variables: time, event,
  categorical group 1, optional categorical group 2, and other vectors which might not be used.
  Automatically selects the log-rank test when the categorical variable has two levels,
  log-rank Bonferroni correction adjusted test for categorical variable with more than 2 levels 
  and when there are two categorical variables thus more interactions. Mention 
  the assumptions of the chosen test, and returns a complete interpretation and conclusion paragraph. 
  Use this SKILL whenever user provides time-to-event / censored data and asks about survival 
  probabilities, median survival, Kaplan-Meier curves, log-rank tests, or comparing survival between groups,
  or anything similar. This skill assumes Proportional Hazard Assumption (for log-rank test), 
  Non-Informative Censoring, and Independent Observations.
---

# Survival Analysis (Kaplan-Meier + Log-Rank Test)

## Non-negotiable rules

- The Kaplan-Meier plot is rendered via
  `show_widget` only in Step 5. It is shown as the first thing in report for any level of response.
  Generate the plot inline using `svglite::svglite()`; the plot shown must be 
  exactly the object returned by `graph_lrt(...)` in the sourced script — nothing else.
- Never show R code in the output (`echo = FALSE` in any exported report).
- Do not add a Notation section — use the standard statistical symbols (X², p, α)
  directly, without an explanatory legend.
- Any `NA` in a quantile or its CI bound must be shown as `NR` (Not Reached), never a
  raw `NA`. If any `NR` appears in the quantile table, print the sentence beneath it:
  **NR = Not Reached. The survival estimate did not decline to the specified percentile
  during the follow-up period.**
- The "Group" column in every table and the plot legend must show the client-provided
  labels — strip any `groups=` / `group=` prefix R's `rownames()`/`summary()` output
  adds (e.g., "groups=Female" → "Female").
- This skill assumes independent observations and non-informative censoring. It is not
  appropriate for interval-censored data or recurrent-event data without adaptation.

## Inputs

The skill accepts input in one of two forms:

**Form A — Dataframe:** a single dataframe with at least 3 columns:

| Column | Type | Description |
|---|---|---|
| `event` | binary (0/1) | Whether the event occurred (1) or was censored (0) |
| `time` | numeric | Time to event or censoring |
| `group1` | categorical | Primary grouping variable |
| `group2` *(optional)* | categorical | Secondary grouping variable |

**Form B — Separate vectors:** three (or four) individual vectors of identical length,
passed in order: `event`, `time`, `group1`, and optionally `group2`.

If more than 4 variables are present, ask the user which two should be used as the
grouping variables.

Optionally, the user may specify a significance level (`threshold`), which defaults to
0.05.

---

## Step 0 — Extract Inputs from Natural Language

If the user provides a dataset, column names, or vectors in a sentence or table,
extract and store `event`, `time`, `group1`, and (if present) `group2`.

**Labelling check:** if `group1` (or `group2`) has exactly two unique values that are
not already self-descriptive (e.g., numeric codes like 0/1, 1/2, TRUE/FALSE), ask the
client which value corresponds to which label before proceeding — skip this if the
values are already descriptive strings (e.g., "Male"/"Female"). Use exact wording such
as: "I see [group1] is coded as 0/1 — which value corresponds to which group (e.g., 0 =
female, 1 = male)?" Build the labelled factor (e.g. `factor(<groups>, levels = c(0,1),
labels = c("Female","Male"))`) using whatever mapping the client gave, and use that
factor — not the raw numeric codes — in every later step, table, and plot.

Do not output anything else at this step; nothing is reported until Step 5.

---

## Step 1 — Validate Inputs

Before running any test, check all of the following. If any check fails, report the
issue clearly and stop.

- `event` contains only 0 and 1 (no `NA`s unless the user confirms listwise deletion)
- `time` is numeric, non-negative, and not infinite
- All vectors/columns have the same number of observations
- At least one event (`event == 1`) exists in the data
- `group1` (and `group2`, if present) has at least 2 unique levels
- If two grouping variables are used, their interaction has at least 2 non-empty cells

**Edge cases:**

| Situation | Behavior |
|---|---|
| All observations censored (`event` all 0) | Abort: "No events observed — survival analysis not possible." |
| A group (or interaction cell) has 0 events | Warn: "Group [X] has no events; quantiles/median will be undefined." |
| Single group (no covariate levels > 1) | Skip the log-rank test; report the KM curve and summary only |
| `NA`s in any column | Warn and apply listwise deletion; report the number of rows removed |
| Tied event times | Handled automatically by `survfit`|

These correspond exactly to the checks performed by `validation_input()` /
`validate_inputs()` in the scripts under `scripts/`.

---

## Step 2 — Exploratory Data Analysis

Per the Non-negotiable rules, this plot is only ever rendered as the element of
Step 5's output, once Step 4 has produced the fitted model — it is scoped here because
it is a descriptive/exploratory artifact of the data, not part of the hypothesis test
itself.

---

## Step 3 — Check Assumptions

Before showing results, briefly verify the assumptions of the log-rank test.

**Implicit assumptions**
- Observations are independent of one another.
- Censoring is non-informative.
- Proportional hazards between groups — the assumption underlying the log-rank test's
  optimality; the test remains a valid omnibus test of curve equality even if hazards
  cross, but loses power in that case.

**Explicit assumptions**
- Each group (or interaction cell) has at least one event, so its survival curve is
  estimable.

See `references/assumptions.md` for the full checklist. For the statistical reasoning
behind why each assumption matters, see `references/guide.md`.

---

## Step 4 — Execute R Code and Extract Results

### Which script to run

| Test type | Script | Function |
|---|---|---|
| One grouping variable (2 or more levels) | `scripts/survival_single_groups.R` | `lrt_test(groups, event, time, threshold = 0.05)` |
| Two grouping variables | `scripts/two_groups_combined.R` | `lrt_test(group_1, group_2, event, time, threshold = 0.05)` |

Use the single-group script when there is one categorical grouping variable (log-rank
test; adds Bonferroni-corrected pairwise comparisons automatically when it has more
than 2 levels). Use the two-group script whenever a second grouping variable is present
(log-rank test on the group interaction, always with Bonferroni-corrected pairwise
comparisons).

### Running the script

Run the R script using the Bash tool. This is the authoritative computation step — do
not calculate the chi-square statistic, p-value, quantiles, or mean survival yourself.
All numerical results in Step 5 must come directly from the output of this command.

From the skill's directory (the folder containing this `SKILL.md`), for one grouping
variable:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/survival_single_groups.R')
lrt_test(groups=<groups>, event=<event>, time=<time>, threshold=0.05)
"
```

For two grouping variables:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/two_groups_combined.R')
lrt_test(group_1=<group1>, group_2=<group2>, event=<event>, time=<time>, threshold=0.05)
"
```

Replace `<groups>`/`<group1>`/`<group2>`, `<event>`, `<time>` with the actual (labelled,
per Step 0) vectors, and `<path-to-skill-directory>` with the actual absolute path to
the folder containing this `SKILL.md`. `threshold` defaults to 0.05; pass it explicitly
if the user specifies a different significance level.

From the returned list, extract:
- `logrank` — chi-square statistic and p-value
- `degrees_of_freedom`
- `result` — the conclusion sentence (and pairwise p-value matrix, when returned)
- `survival_quantile_CI` — median, Q25, Q75 with 95% CI per group
- `survival_mean_CI` — restricted mean survival, SE, 95% CI per group
- `group_summary` (two-group script only) — `n` and events per group
- `graph` — the `graph_lrt(...)` plot object

Use these extracted values verbatim when writing the Step 5 report. Do not recompute or
reword numerical results.

### If the script fails

Surface the R error message verbatim to the user and stop — do not guess at what the
result would have been, and do not silently fall back to a different test. Common
causes worth checking first: a missing R package (`tidyverse`, `survival`, `ggsurvfit`,
`survminer` — tell the user which one to install), inputs that don't match Step 1's
validation (revisit Step 1), or a path issue (confirm `<path-to-skill-directory>` is
correct).

---

## Step 5 — Output

Ask for the response level using the exact wording as below:

> Assuming these vector inputs are correct (time = `<time>`, event = `<event>`, 
categorical group = `<group1>`, and (*optional*) categorical group 2 = `<group2>`),
we will proceed with the analysis. Would you like a **brief** (assumptions, test statistic, 
p-value, graph), **moderate** (adds context and supporting tables), 
or **detailed** (full background, definitions, and step-by-step interpretation) response?

Output **exactly** the above sentence — nothing before it, nothing after except 
waiting for the user's reply. Do not show formulas, intermediate tables, or any other text.

**note: Assuming these vector inputs are correct, do not ask for confirmation.**

Currently echoes raw values like "categorical group = <group1>". Update this 
template to show the client-given labels instead of raw codes once they've been provided.
 
**Order** The order of the output results have to follow the exact order as below.

**Tone:** Professional but accessible. Write for a stakeholder who understands
"statistically significant" but does not need to verify the math. Never show R code in
the output; any exported report must use `echo = FALSE` in its setup chunk.

**Table formatting:** use bold headers, alignment markers, and a section break between
tables.


---

### Brief

Eaxactly one paragraph covering: Kaplan Meier curve, test used (log-rank test and whether Bonferroni 
correction is used), all of the assumptions being checked, key result (chi-square 
statistic + p-value (4 decimal places if ≥ 0.05, otherwise `< 0.05`, `< 0.01`, 
or `< 0.001` with stars)), and decision (reject / fail to reject null hypothesis), 
50th quantile and its confidence interval, mean survival probability and 
confidence interval.

No table or plot displayed.
---


### Moderate

A single cohesive paragraph covering all five elements in exact order:

1. Kaplan-Meier curve as **Kaplan-Meier Plot**
2. **Background** — censoring event, time to event, levels in the group or interactions.
3. **Test chosen and assumptions** — test name, why it was selected, all key assumptions met.
4. **Test result** — test statistic (X²), degrees of freedom, p-value (4 decimal places 
if ≥ 0.05, otherwise `< 0.05`, `< 0.01`, or `< 0.001` with stars), and confidence interval 
and quantiles as **Quantile Table**, mean survival and confidence interval as 
**Mean Survival Table**.
5. **Decision** — reject or fail to reject null hypothesis, and what that means in plain language.

Return **Pairwise Table** only when needed and conditions met.
---

### Detailed

The full **Moderate** paragraph and plot, then:

A short **Plain-language interpretation** section (3–5 sentences) written for 
a non-statistical audience: what does this result mean practically, what can and 
cannot be concluded, and any relevant caveats (e.g., statistical significance ≠ clinical 
or practical significance), the definition of p-value, the correct interpretation 
of confidence interval (We are (1-`<threshold>`)% confident that the true difference 
of probability of response between the two groups falls within `<confint>`. )

- extract the `<confint>` from the output of `Two_sample_proportion_with_multiple_functions.R`, 
and `<threshold>` is the significance level, which is 5% by default, unless specified.

---
Note: All R code chunks must use echo = FALSE (set globally in the setup chunk) so no
R code is visible in the rendered report. Clients should not see the code.

---

Return the following based on the response brief/moderate/detailed level, in order:

**Kaplan-Meier plot.** 
Only shown for `detailed` or `moderate` response levels. This is also built here, 
from `graph_lrt(groups, event, time)` (one grouping variable) or 
`graph_lrt(group_1, group_2, event, time)` (two grouping variables) in the sourced 
script. Rendered inline via `show_widget`. It must show:
- Separate curves per group/strata, with distinct colors (and linetypes when there are
  two grouping variables), plus a legend using the client-provided labels
- Censoring tick marks
- Axis labels: x = "Time", y = "Survival Probability"
- A title indicating the grouping variable(s)
- The log-rank p-value annotated on the plot
- No shaded confidence bands — the legend should contain only the groups and the
  color/linetype used, nothing else
  
**Background**
The context of the problem: 
 This analysis focuses on time-to-event survival: `time` is the follow-up time in days, 
 and `event` indicates whether the event (`event = 1`) occurred or the observation was 
 censored (`event = 0`). Categorical covariate(/covariates) was(were) examined: 
 `group1` and *(optional)* `group2`.
 
**The assumptions held**

Refer to Step 3 and briefly state the assumptions made.

**Hypothesis Test Summary**

```
Null Hypothesis: Survival curves are identical across all groups of [group1] [and group2].
Alternative Hypothesis: At least one survival curve differs.

Chi-square statistic: X.XX
Degrees of freedom:   X
p-value:              X.XXXX [* / ** / *** / (none)]
Decision:             Reject Null Hypothesis / Fail to reject Null Hypothesis at significance level = 0.05
```
Significance stars: `***` p < 0.001, `**` p < 0.01, `*` p < 0.05, none if p ≥ 0.05.

**Quantile Table**

One row per group/strata. Columns: Group | Median (95% CI) | Q25 (95% CI) | Q75 (95%
CI), from `survival_quantile_CI`. Replace any `NA` with `NR` (see Non-negotiable
rules) and print the NR sentence beneath the table if any appear. Strip the
`groups=`/`group=` prefix from the Group column.

**Mean Survival Table**

One row per group/strata. Columns: Group | Mean Survival | SE | 95% CI Lower | 95% CI
Upper, from `survival_mean_CI`. State explicitly that the mean survival time is
restricted to (bounded by) the largest observed time in each stratum. Strip the
`groups=`/`group=` prefix from the Group column.

**Pairwise Table** *(only if more than 2 levels of the single grouping variable, OR two grouping variables, AND the log-rank p-value is below the threshold)*

Pairwise p-value table for levels or interactions, from `fit_pairwise` /
`result[[2]]`. Strip the `groups=`/`group=` prefix from row/column labels.

---

## Notes

- All confidence intervals are 95% by default; the user may specify a different level.

---

## Examples

### Example A — Single grouping variable, two levels

Input: a dataset of 60 subjects with `time`, `event` (0/1), and `groups`
(`Female`/`Male`).

Output level: brief

> We compared survival between Female (n = 30) and Male (n = 30) subjects using the
> log-rank test. The test yielded a chi-square statistic of 0.XX (df = 1) and a p-value
> of 0.XXXX. Because p ≥ 0.05, we fail to reject the null hypothesis that the survival
> curves are identical across groups — there is no statistically significant difference
> in survival between Female and Male subjects at the 0.05 significance level. Median
> survival was X.XX (95% CI: X.XX–XX.XX) for Female and 7.74 (95% CI: X.XX–XX.XX) for
> Male. The Kaplan-Meier plot is shown last, with censoring marks and the log-rank
> p-value annotated.

### Example B — Two grouping variables

Input: a dataset of 80 subjects with `time`, `event` (0/1), `group_1` (`A`/`B`), and
`group_2` (`X`/`Y`).

Output level: brief

> We compared survival across the four combinations of group 1 (A/B) and group 2 (X/Y)
> using the log-rank test with Bonferroni-corrected pairwise comparisons. The test
> yielded a chi-square statistic of XX.XX (df = 3) and a p-value of 0.XXXX. Because p ≥
> 0.05, we fail to reject the null hypothesis that survival curves are identical across
> the four groups — no pairwise table is shown, since the overall test was not
> significant. The Kaplan-Meier plot is shown last, with one curve per A.X/B.X/A.Y/B.Y
> combination.

---

# Validation steps: this step is only for developer, not for SKILL user
**Should be hidden unless explicitly mentioned.**
This step is only disclosed when developer explicitly asks for testing the validity
of the SKILL. This is different from Step 1 Validate Inputs. It is used only for checking
the validity of the entire SKILL.md file. Do not mention anything related to this
step for regular SKILL user.

This is irrelevant to the three hierarchical output levels. We would only need to test
if the key numerical output from expectation matches that from the actual computation.

Refer to `references/validation.md` for the full list of test cases. All ten examples
draw on the same dataset, `data/whas100_12.csv`, stored inside this skill's directory.
Two requirements that apply on top of what that file says:

- **Speed:** run all 10 example inputs through a single batched `Rscript` call (see
  "Running the examples efficiently" in `references/validation.md`) rather than invoking
  the full conversational Steps 0–5 10 separate times. Only fall back to a full
  conversational run for a specific example if the batched script-level check disagrees
  with the expected outcome for that example.
- **Output:** report the correctness rate as a percentage, followed by a 4-column
  markdown table (`Test | Outcome Expected | Outcome Generated | Match`) with one row
  per example.

