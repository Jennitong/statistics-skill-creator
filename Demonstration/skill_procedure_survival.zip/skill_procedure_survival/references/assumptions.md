# Assumptions

This document contains all the assumptions to check before reporting results for the
Kaplan-Meier / log-rank survival analysis.

## Implicit assumptions - all cases

- **Independent observations.** Each subject's event/censoring time is independent of
  every other subject's. 
- **Non-informative censoring.** A subject's reason for being censored must be
  unrelated to their underlying risk of the event. If censoring is driven by the same
  factors that drive the event (e.g., sicker patients drop out of a trial early), the
  Kaplan-Meier estimator is biased.
- **Proportional hazards between groups (used whenever there are 2+ groups, or 2 grouping variables).** 
  The ratio of hazard functions between any two groups is constant over time. This is 
  what gives the log-rank test its optimal power; the test remains a valid (if less 
  powerful) omnibus test of curve equality when hazards cross.

## Explicit, test-specific assumptions (used whenever there are 2+ groups, or 2 grouping variables)

### Log-rank test 

- Each group (or each interaction cell, when two grouping variables are used) has at
  least one observed event, so its survival curve is estimable.

### Bonferroni-corrected pairwise comparisons 

1. Same assumptions as the log-rank test above, applied to each pairwise comparison.
2. The Bonferroni correction assumes the family of pairwise tests is being evaluated
   jointly.

## What is NOT checked by this skill

- Proportional hazards is **not formally tested** - only assumed and stated as a caveat.
- Interval censoring or left censoring — this skill only supports right-censored data
  (`event` = 0 meaning "censored at `time`").
