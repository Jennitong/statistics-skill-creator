# Validation

Checks the validity and correctness of the SKILL. There are ten examples of numerous
inputs and outcomes expected, all drawn from the same real dataset. The actual output
generated using the SKILL is compared with the expected outcomes below, and if the
correctness rate is 100% (10/10), the SKILL is overall valid. Report the exact correctness
rate even if it is below 100%.

Triggered when developer explicitly asks for the validity of the skill, the accuracy and
correctness of the test result, or anything similar.

## Dataset

All ten examples use `data/whas100_12.csv` (Worcester Heart Attack Study, 100
subjects), stored inside this skill's directory so any script run from
`<path-to-skill-directory>` can read it with a relative path. 

**important ** when validating the skill, assume that 0 is `male` and 1 is `female` for `gender` column.

Columns used:

- `lenfol` — follow-up time in days. Used as `time` in every example.
- `fstat` — 1 = event of interest observed, 0 = censored. Used as `event` in every example.
- `gender` — 0/1, not self-descriptive per Step 0's labelling check. Labelled
  `0` for `male` and `1` for `female`.
- `agecat` — age-bracket variable (`[32,60)`, `[60,70)`, `[70,80)`,
  `[80,92]`).
- `bmicat` — BMI-bracket variable (`[14.9,23.5)`, `[23.5,27.2)`,
  `[27.2,30.4)`, `[30.4,39.9]`).
- `losbin` — 0/1, labelled `0` as "Short length of stay in hospital" and `1` as 
  "Long length of stay in hospital".
- `education` - highest-education-level received. Labelled `high school`, `undergraduate`,
  `master`, `phd`. Last line is `NA` on purpose.
- `IQ` - Intelligence quotient received. Labelled `low`, `high` and `NA` on purpose.

## Running the examples efficiently

Do **not** invoke the full conversational skill (Steps 0–5) separately for each of the 10x
examples below — that requires 10 separate `Rscript` process starts plus 10 rounds of
prose/plot generation and is unnecessarily slow. Since Step 4 of `SKILL.md` requires
every numerical result to come verbatim from `scripts/survival_single_groups.R` /
`scripts/two_groups_combined.R`, and Step 3's assumption checks are a direct mirror of
`validation_input()` / `validate_inputs()` in those same scripts, the numerical/decision
path is fully deterministic. To validate it quickly:

1. Write a single `Rscript` file that, from the skill's directory, sources both scripts
   into separate environments (their function names collide), reads
   `data/whas100_12.csv` once, calls `lrt_test()` once per example below.
2. Compare each generated result against the expected outcome for that example.
   Exact wording does not need to match.
3. Only fall back to running the full conversational skill end-to-end (including the
   Kaplan-Meier plot and full report) if this script-level check reveals a discrepancy,
   to determine whether the bug is in the R scripts, in `SKILL.md`'s instructions, or in
   how the assistant is following them.

- Example 1
Input: `time = lenfol`, `event = fstat`, `group1 = gender`
Output expected: Single grouping variable, log-rank test chosen;
chi-square statistic rounds to 3.97 (df = 1); p-value is less than 0.05 (*);
reject the null hypothesis; survival differs significantly between Male and Female.

- Example 2
Input: `time = lenfol`, `event = fstat`, `group1 = agecat`
Output expected: log-rank test with Bonferroni-corrected pairwise comparisons chosen;
chi-square statistic rounds to 15.57 (df = 3); p-value is less than 0.01 (*); 
reject the null hypothesis; survival differs significantly across age categories;
Because p < 0.05, a pairwise table is shown: only `[32,60)` vs `[80,92]` and `[60,70)` vs
`[80,92]` are significant at 0.05; all other pairs are not.

- Example 3
Input: `time = lenfol`, `event = fstat`, `group1 = bmicat` 
Output expected: log-rank test with Bonferroni-corrected pairwise comparisons; 
chi-square statistic rounds to 8.63 (df = 3); p-value is less than 0.05 (*);
reject the null hypothesis; survival differs significantly across BMI categories;
Because p < 0.05, a pairwise table is shown: only `[14.9,23.5)` vs `[27.2,30.4)`
is significant at 0.05; all other pairs are not.

- Example 4
Input: `time = lenfol`, `event = fstat`, `group1 = losbin` 
Output expected: log-rank test chosen; chi-square statistic rounds to 0.23 (df = 1); 
p-value rounds to 0.6344; fail to reject the null hypothesis;
no statistically significant survival difference between Short LOS and Long LOS
patients.

- Example 5 (tests the two-grouping-variable / interaction path)
Input: `time = lenfol`, `event = fstat`, `group1 = gender`, `group2 = losbin`
Output expected: log-rank test on the 4-cell interaction
(Male.Short LOS, Female.Short LOS, Male.Long LOS, Female.Long LOS) with
Bonferroni-corrected pairwise comparisons; chi-square statistic rounds
to 4.43 (df = 3); p-value rounds to 0.2188; fail to reject the null hypothesis; no
statistically significant survival difference across the four gender × LOS
combinations. Because p ≥ 0.05, the pairwise table is **not** shown per Step 5's rule.

- Example 6 (tests the two-grouping-variable / interaction path)
Input: `time = lenfol`, `event = fstat`, `group1 = gender`, `group2 = agecat`
Output expected: log-rank test on the 8 gender × age-category with
Bonferroni-corrected pairwise comparisons; chi-square statistic rounds
to 18.27 (df = 7); p-value is less than 0.5(*); reject the null hypothesis; 
survival differs significantly across gender and age category combined;
pairwise table is shown, with `Female.[80,92]` and `Male.[32,60)` being significantly
different at 5% significance level.

- Example 7 (invalid inputs)
Input: `time = agecat`, `event = fstat`, `group1 = gender`
Output expected: Invalid inputs. Data type not compatible: time must be numeric.

- Example 8 (invalid inputs)
Input: `time = lenfol`, `event = fstat`, `group1 = education`, `group2 = IQ`
Output expected: Missing values detected in one or more variables.

- Example 9 (invalid inputs)
Input: `time = lenfol`, `event = fstat`, `group1 = IQ`
Output expected: Invalid input. Missing values detected in groups, event, or time.

- Example 10 (invalid inputs)
Input: `time = lenfol`, `event = education`, `group1 = gender`
Output expected: Invalid inputs: Missing values detected in groups, event, or time.

---
# Correctness Rate
Generate the actual output using the SKILL (see "Running the examples efficiently"
above for how to do this without 10 separate full skill invocations), then verify if the
key values in the actual output (test type chosen, chi-square statistic, degrees of
freedom, p-value bucket, decision, conclusion direction, and whether a pairwise table is
produced) are equivalent to the expected output shown above — wording does not have to
match exactly, and numerical values can be rounded. Check whether the correctness rate
is 100% (10/10); report the exact rate even if it is lower.

Report:
1. The correctness rate as a percentage (e.g., "10/10 = 100%").
2. A markdown table with exactly these four columns: `Test | Outcome Expected | Outcome
   Generated | Match`, one row per example (10 rows). Keep each cell terse (a short
   phrase per field, e.g. test type + decision), not a full paragraph.
3. If any example does not match, name it and explain the discrepancy in one sentence.
