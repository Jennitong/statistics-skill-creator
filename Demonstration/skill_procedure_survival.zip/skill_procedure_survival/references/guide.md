# Guide — Why Each Assumption Matters

## Independence of observations

If subjects are not independent (e.g., paired organs from the same patient, or
subjects clustered within a site with a shared unmeasured risk factor), the variance
formula the log-rank test uses for its chi-square statistic understates the true
variance, inflating the false-positive rate. 

## Non-informative censoring

The Kaplan-Meier estimator treats every censored subject as "Non-informative",
that is, the reason of drop outs and is unrelated to the event of interest.
This assumption ensures that uncensored events are representative of the whole group.

## Proportional hazards and the log-rank test

The log-rank test statistic weights all time points equally, working the best when
hazard ratio between groups is constant over time. If hazards cross,
the log-rank test will have lower power.

Note: This skill does not run a formal proportional-hazards test — if the Kaplan-Meier plot shows
curves crossing, mention it as a caveat on interpreting a non-significant log-rank
result, rather than treating "fail to reject" as proof the curves are identical.

## How to interpret assumption failures

- If an assumption is violated, name which one and explain in plain language what that
  means for the reliability of the p-value (inflated Type I error for non-independence;
  biased curve for informative censoring; reduced power for non-proportional hazards).
- Do not silently proceed as if the assumption held — state the caveat in the Step 5
  output alongside the numerical result.

## Common pitfalls to avoid

- Choose the log-rank test alone when there are exactly and only 2 groups; add
  Bonferroni-corrected pairwise comparisons only when there are more than 2 levels of a
  single grouping variable, or two grouping variables.
- Do not compute or report a pairwise table when the overall log-rank test is not
  significant — pairwise comparisons are only meaningful as a follow-up to a
  significant result.
- Report the restricted mean survival time (`rmean`) with an explicit note that it is
  bounded by the largest observed time in that stratum.
- Always display `NA` as `NR`.
