## Diagnostic: assumption checks for Kaplan-Meier + log-rank
#
# Usage (from the skill directory):
#   source("scripts/diagnostic.R")
#   run_diagnostics(dat, time = "time", status = "status", group = "sex", plot_dir = "<dir>")
#
# Assumptions 1 (independent subjects) and 2 (non-informative censoring) are implicit and
# judged from the study design; the censoring evidence for #2 is produced by
# scripts/eda_code.R (censoring summary, reverse-KM plot).
#
# Assumption 3 (proportional hazards -> log-rank power) is checked here by:
#   (a) log(-log S(t)) vs log(t) plot  -> loglog_plot.png   (roughly parallel = PH plausible)
#   (b) crossing check of the KM curves (printed)
#   (c) cox.zph global test on a Cox model with group as the only covariate (printed;
#       p < 0.05 flags non-proportional hazards) + Schoenfeld residual plot -> schoenfeld_plot.png
#
# All plots must be displayed inline for the client (one Read call per PNG).

source("scripts/validate.R")
suppressPackageStartupMessages(library(ggplot2))

# Detect whether any pair of KM curves crosses: sign change of S_i(t) - S_j(t) over the
# common time range, ignoring differences smaller than `tol`.
check_crossing <- function(fit, d, tol = 0.02) {
  lv <- levels(d$group)
  grid <- sort(unique(d$time[d$status == 1]))
  s <- summary(fit, times = grid, extend = TRUE)
  S <- split(s$surv, s$strata)
  names(S) <- sub("^group=", "", names(S))
  maxt <- sapply(split(d$time, d$group), max)
  out <- list()
  for (i in seq_along(lv)) for (j in seq_along(lv)) if (i < j) {
    keep <- grid <= min(maxt[lv[i]], maxt[lv[j]])
    diff <- S[[lv[i]]][keep] - S[[lv[j]]][keep]
    sg <- sign(diff[abs(diff) > tol])
    crosses <- length(sg) > 1 && any(sg[-1] != sg[-length(sg)])
    out[[length(out) + 1]] <- data.frame(pair = paste(lv[i], "vs", lv[j]), curves_cross = crosses)
  }
  do.call(rbind, out)
}

check_assumptions <- function(d) {
  fit <- survfit(Surv(time, status) ~ group, data = d)
  crossing <- check_crossing(fit, d)
  zph <- cox.zph(coxph(Surv(time, status) ~ group, data = d))
  zph_p <- zph$table["GLOBAL", "p"]
  list(fit = fit, crossing = crossing, zph = zph, zph_p = zph_p,
       ph_flag = (zph_p < 0.05) || any(crossing$curves_cross))
}

run_diagnostics <- function(dat, time, status, group, plot_dir = ".") {
  d <- validate_inputs(dat, time, status, group)
  dir.create(plot_dir, showWarnings = FALSE, recursive = TRUE)
  a <- check_assumptions(d)

  ## (a) log(-log S(t)) vs log(t)
  s <- summary(a$fit)
  ll <- data.frame(t = s$time, surv = s$surv, group = sub("^group=", "", s$strata))
  ll <- ll[ll$surv > 0 & ll$surv < 1, ]
  p_ll <- ggplot(ll, aes(log(t), log(-log(surv)), colour = group)) +
    geom_step(linewidth = 0.9) + geom_point(size = 1) +
    labs(x = "log(time)", y = "log(-log(S(t)))", colour = group,
         title = sprintf("Log-log survival plot by %s (parallel curves support proportional hazards)", group)) +
    theme_minimal() + theme(legend.position = "bottom")
  ggsave(file.path(plot_dir, "loglog_plot.png"), p_ll, width = 8, height = 5.5, dpi = 150)

  ## (c) Schoenfeld residuals
  png(file.path(plot_dir, "schoenfeld_plot.png"), width = 1200, height = 800, res = 150)
  nterm <- ncol(a$zph$y)
  par(mfrow = c(1, nterm))
  for (k in seq_len(nterm)) {
    plot(a$zph[k], resid = TRUE, se = TRUE, main = sprintf("Schoenfeld residuals: %s", colnames(a$zph$y)[k]))
    abline(h = 0, lty = 3, col = "grey40")
  }
  dev.off()

  cat("\n== Proportional hazards check ==\n")
  cat("KM curve crossing (|difference| > 0.02 changes sign):\n")
  print(a$crossing, row.names = FALSE)
  cat("\ncox.zph test (H0: hazards proportional):\n")
  print(a$zph$table)
  cat(sprintf("\nGlobal cox.zph %s. %s\n", fmt_p(a$zph_p),
              if (a$ph_flag) paste("FLAG: proportional hazards is questionable; the log-rank test",
                                   "remains valid but may have low power. Consider a weighted test",
                                   "(e.g. Peto-Peto, rho = 1, or Fleming-Harrington).")
              else "Proportional hazards looks reasonable; the log-rank test is well suited."))
  cat("\nSaved:", file.path(plot_dir, "loglog_plot.png"), "\n      ",
      file.path(plot_dir, "schoenfeld_plot.png"), "\n")
  invisible(a)
}
