# run_validation.R -- developer-only batched validation (see references/validation.md)
# Run from the skill directory:  Rscript scripts/run_validation.R

suppressWarnings(source("scripts/task_code1.R"))
source("scripts/task_code2.R")

sim2 <- function(n, r1, r2, seed) {
  set.seed(seed); g <- rep(c("A", "B"), each = n)
  t <- rexp(2 * n, ifelse(g == "A", r1, r2)); c <- runif(2 * n, 0, 30)
  data.frame(time = pmin(t, c), status = as.integer(t <= c), group = g)
}
sim_cross <- function() {
  set.seed(2026); n <- 150; g <- rep(c("A", "B"), each = n)
  t <- c(rweibull(n, 0.5, 10), rweibull(n, 3, 10)); c <- runif(2 * n, 0, 30)
  data.frame(time = pmin(t, c), status = as.integer(t <= c), group = g)
}
lung01 <- transform(survival::lung, status = status - 1, sex = factor(sex, 1:2, c("Male", "Female")))

quiet <- function(expr) { out <- NULL; capture.output(out <- tryCatch(expr, error = function(e) e)); out }
lr_txt <- function(r) sprintf("chisq=%.2f, df=%d, p=%.4f, %s", r$chisq, r$df, r$p,
                              ifelse(r$p < 0.05, "sig", "not sig"))

rows <- list()
add <- function(test, expected, generated, match) rows[[length(rows) + 1]] <<-
  data.frame(Test = test, Expected = expected, Generated = generated, Match = ifelse(match, "Yes", "No"))

r <- quiet(main_function1(lung01, "time", "status", "sex"))
add("1 lung by sex", "medians 270 / 426; chisq=10.33, p=0.0013, sig",
    sprintf("medians %s / %s; %s", r$est$median[1], r$est$median[2], lr_txt(r)),
    all(r$est$median == c(270, 426)) && abs(r$chisq - 10.33) < 0.01 && r$p < 0.05)

r <- quiet(main_function1(survival::aml, "time", "status", "x"))
add("2 aml (small n)", "medians 31 / 23, upper CI NR; chisq=3.40, p=0.0653, not sig",
    sprintf("medians %s / %s, UCL NA: %s; %s", r$est$median[1], r$est$median[2], all(is.na(r$est$ucl)), lr_txt(r)),
    all(r$est$median == c(31, 23)) && all(is.na(r$est$ucl)) && abs(r$chisq - 3.40) < 0.01 && r$p >= 0.05)

r <- quiet(main_function1(survival::veteran, "time", "status", "celltype"))
pw <- quiet(main_function2(survival::veteran, "time", "status", "celltype"))
sig <- sort(paste(pw$group_1, pw$group_2)[pw$p_adj < 0.05])
exp_sig <- sort(c("squamous smallcell", "squamous adeno", "smallcell large", "adeno large"))
add("3 veteran celltype", "chisq=25.40, df=3, p<0.001; 4 sig pairs; PH flagged",
    sprintf("%s; %d sig pairs; PH flag=%s", lr_txt(r), length(sig), r$assumptions$ph_flag),
    abs(r$chisq - 25.40) < 0.01 && r$df == 3 && r$p < 0.001 && identical(sig, exp_sig) && r$assumptions$ph_flag)

r <- quiet(main_function1(sim2(100, .1, .1, 2026), "time", "status", "group"))
add("4 sim null", "chisq=0.14, p=0.708, not sig", lr_txt(r), abs(r$chisq - 0.14) < 0.01 && r$p >= 0.05)

r <- quiet(main_function1(sim2(100, .1, .2, 2026), "time", "status", "group"))
add("5 sim HR=2", "chisq=14.79, p<0.001, sig", lr_txt(r), abs(r$chisq - 14.79) < 0.01 && r$p < 0.001)

r <- quiet(main_function1(sim_cross(), "time", "status", "group"))
add("6 sim crossing", "chisq=0.008, p=0.930, not sig; PH flagged",
    sprintf("%s; PH flag=%s (zph p=%.2g)", lr_txt(r), r$assumptions$ph_flag, r$assumptions$zph_p),
    abs(r$chisq - 0.008) < 0.005 && r$p >= 0.05 && r$assumptions$ph_flag)

bad <- data.frame(time = c(5, -1, 8, 12), status = c(1, 0, 1, 1), group = c("A", "A", "B", "B"))
e <- quiet(main_function1(bad, "time", "status", "group"))
add("7 invalid time<=0", "rejected", if (inherits(e, "error")) paste("rejected:", conditionMessage(e)) else "accepted",
    inherits(e, "error"))

e <- quiet(main_function1(transform(survival::lung, sex = factor(sex)), "time", "status", "sex"))
add("8 invalid status 1/2", "rejected", if (inherits(e, "error")) "rejected: status must be 0/1" else "accepted",
    inherits(e, "error"))

res <- do.call(rbind, rows)
cat(sprintf("Correctness rate: %.0f%% (%d/%d)\n\n", 100 * mean(res$Match == "Yes"), sum(res$Match == "Yes"), nrow(res)))
cat("| Test | Outcome Expected | Outcome Generated | Match |\n|---|---|---|---|\n")
cat(sprintf("| %s | %s | %s | %s |\n", res$Test, res$Expected, res$Generated, res$Match), sep = "")
