# task_code2
#
# Task for this R file: pairwise log-rank comparisons between all pairs of groups, with
# multiple-comparison adjustment (default Holm), via survminer::pairwise_survdiff.
# Only meaningful for 3+ groups; with 2 groups the overall log-rank test in
# scripts/task_code1.R already is the single pairwise comparison.
#
# Usage (from the skill directory):
#   source("scripts/task_code2.R")
#   main_function2(dat, time = "time", status = "status", group = "celltype",
#                  alpha = 0.05, p_adjust = "holm")

source("scripts/validate.R")
source("scripts/diagnostic.R")
suppressPackageStartupMessages(library(survminer))

run_pairwise <- function(d, p_adjust) {
  pw <- pairwise_survdiff(Surv(time, status) ~ group, data = d, p.adjust.method = p_adjust, rho = 0)
  m <- pw$p.value
  rn <- sub("^group=", "", rownames(m)); cn <- sub("^group=", "", colnames(m))
  out <- list()
  for (i in seq_len(nrow(m))) for (j in seq_len(ncol(m))) if (!is.na(m[i, j]))
    out[[length(out) + 1]] <- data.frame(group_1 = cn[j], group_2 = rn[i], p_adj = m[i, j])
  do.call(rbind, out)
}

report_pairwise <- function(pw, alpha, p_adjust, a, labels) {
  pw$significant <- pw$p_adj < alpha
  cat(sprintf("\n== Pairwise log-rank tests (%s-adjusted, two-sided) ==\n", p_adjust))
  print(data.frame(Comparison = paste(pw$group_1, "vs", pw$group_2),
                   `Adjusted p` = sapply(pw$p_adj, fmt_p),
                   Decision = ifelse(pw$significant, "SIGNIFICANT", "NOT SIGNIFICANT"),
                   check.names = FALSE), row.names = FALSE)
  sig <- pw[pw$significant, ]
  cat("\n== Conclusion ==\n")
  cat(sprintf(paste0(
    "Pairwise two-sided log-rank tests were run for all %d pairs of `%s` levels with %s adjustment ",
    "for multiple comparisons (alpha = %.2f). %s%s\n"),
    nrow(pw), labels$group, p_adjust, alpha,
    if (nrow(sig)) sprintf("Survival differed significantly for: %s. All other pairs were not significantly different.",
                           paste(paste(sig$group_1, "vs", sig$group_2), collapse = "; "))
    else "No pair of groups differed significantly after adjustment.",
    if (a$ph_flag) " Note: the proportional-hazards check was flagged, so pairwise log-rank tests may have reduced power." else ""))
  invisible(pw)
}

main_function2 <- function(dat, time, status, group, alpha = 0.05, p_adjust = "holm") {
  d <- validate_inputs(dat, time, status, group)
  if (!p_adjust %in% p.adjust.methods)
    stop("`p_adjust` must be one of: ", paste(p.adjust.methods, collapse = ", "), call. = FALSE)
  if (nlevels(d$group) < 3) {
    cat(sprintf(paste("\nPairwise comparisons skipped: `%s` has only 2 levels, so the overall log-rank",
                      "test (task_code1.R) already is the single pairwise comparison.\n"), group))
    return(invisible(NULL))
  }
  a <- check_assumptions(d)
  pw <- run_pairwise(d, p_adjust)
  report_pairwise(pw, alpha, p_adjust, a, attr(d, "labels"))
}
