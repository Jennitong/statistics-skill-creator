# task_code1
#
# Task for this R file: Kaplan-Meier survival estimates by group (n, events, censored,
# median survival with 95% CI, optional survival probabilities at chosen timepoints) and
# the overall two-sided log-rank test (survival::survdiff, rho = 0). Always run.
#
# Usage (from the skill directory):
#   source("scripts/task_code1.R")
#   main_function1(dat, time = "time", status = "status", group = "sex",
#                  alpha = 0.05, timepoints = c(180, 365), plot_dir = "<dir>")

source("scripts/validate.R")
source("scripts/diagnostic.R")

run_test <- function(d, alpha, timepoints) {
  fit <- survfit(Surv(time, status) ~ group, data = d)
  tab <- summary(fit)$table
  if (is.null(dim(tab))) tab <- t(as.matrix(tab))
  est <- data.frame(group = sub("^group=", "", rownames(tab)),
                    n = tab[, "records"], events = tab[, "events"],
                    censored = tab[, "records"] - tab[, "events"],
                    median = tab[, "median"], lcl = tab[, "0.95LCL"], ucl = tab[, "0.95UCL"],
                    row.names = NULL)

  tp <- NULL
  if (length(timepoints) > 0) {
    s <- summary(fit, times = timepoints, extend = TRUE)
    tp <- data.frame(group = sub("^group=", "", s$strata), time = s$time, n_risk = s$n.risk,
                     surv = s$surv, lower = s$lower, upper = s$upper)
  }

  lr <- survdiff(Surv(time, status) ~ group, data = d, rho = 0)
  df <- length(lr$n) - 1
  p <- pchisq(lr$chisq, df, lower.tail = FALSE)
  list(fit = fit, est = est, tp = tp, chisq = lr$chisq, df = df, p = p, alpha = alpha,
       obs = lr$obs, exp = lr$exp)
}

report_conclusion <- function(r, a, labels) {
  cat("\n== Kaplan-Meier estimates by", labels$group, "==\n")
  e <- r$est
  print(data.frame(Group = e$group, N = e$n, Events = e$events, Censored = e$censored,
                   Median = fmt_num(e$median), `95% CI` = sprintf("%s to %s", fmt_num(e$lcl), fmt_num(e$ucl)),
                   check.names = FALSE), row.names = FALSE)

  if (!is.null(r$tp)) {
    cat("\n== Survival probability at requested timepoints ==\n")
    t <- r$tp
    print(data.frame(Group = t$group, Time = t$time, `At risk` = t$n_risk,
                     `S(t)` = sprintf("%.3f", t$surv),
                     `95% CI` = sprintf("%.3f to %.3f", t$lower, t$upper), check.names = FALSE),
          row.names = FALSE)
  }

  cat("\n== Overall log-rank test (two-sided) ==\n")
  print(data.frame(Group = e$group, Observed = r$obs, Expected = round(r$exp, 2)), row.names = FALSE)
  cat(sprintf("Chi-square = %.3f, df = %d, %s, alpha = %.2f\n", r$chisq, r$df, fmt_p(r$p), r$alpha))

  reject <- r$p < r$alpha
  med_txt <- paste(sprintf("%s: %s (95%% CI %s to %s)", e$group, fmt_num(e$median), fmt_num(e$lcl), fmt_num(e$ucl)),
                   collapse = "; ")
  nr <- e$group[is.na(e$median)]
  ph_txt <- if (a$ph_flag)
    sprintf(paste(" The proportional-hazards check was flagged (cox.zph global %s%s), so the log-rank",
                  "test may have reduced power; a non-significant result should not be read as evidence",
                  "of equal survival, and a weighted test (e.g. Peto-Peto) may be considered."),
            fmt_p(a$zph_p), if (any(a$crossing$curves_cross)) "; KM curves cross" else "")
  else sprintf(" The proportional-hazards check raised no concern (cox.zph global %s).", fmt_p(a$zph_p))

  cat("\n== Conclusion ==\n")
  cat(sprintf(paste0(
    "Kaplan-Meier survival was estimated for %d subjects (%d events, %d censored) across %d levels of `%s`. ",
    "Median survival was %s.%s ",
    "The two-sided log-rank test gave chi-square = %.3f on %d df, %s. At alpha = %.2f we %s the null ",
    "hypothesis that survival is the same in all groups%s.%s\n"),
    sum(e$n), sum(e$events), sum(e$censored), nrow(e), labels$group, med_txt,
    if (length(nr)) sprintf(" Median survival was not reached in: %s.", paste(nr, collapse = ", ")) else "",
    r$chisq, r$df, fmt_p(r$p), r$alpha,
    if (reject) "reject" else "fail to reject",
    if (reject) "; there is statistically significant evidence that survival differs between groups"
    else "; there is not sufficient evidence that survival differs between groups",
    ph_txt))
  cat(sprintf("DECISION: %s\n", if (reject) "SIGNIFICANT" else "NOT SIGNIFICANT"))
  invisible(r)
}

# Results figure: KM curves with median-survival reference line and log-rank p annotation
save_result_plot <- function(d, r, group, plot_dir, time_unit) {
  suppressPackageStartupMessages({library(ggplot2); library(ggsurvfit)})
  dir.create(plot_dir, showWarnings = FALSE, recursive = TRUE)
  fit <- survfit2(Surv(time, status) ~ group, data = d)
  p <- ggsurvfit(fit, linewidth = 0.9) +
    add_confidence_interval() + add_censor_mark(size = 2) +
    add_quantile(y_value = 0.5, linetype = "dashed", colour = "grey40") +
    add_risktable() +
    annotate("text", x = Inf, y = 1, hjust = 1.05, vjust = 1,
             label = sprintf("Log-rank chi-sq = %.2f, df = %d, %s", r$chisq, r$df, fmt_p(r$p))) +
    labs(x = sprintf("Time (%s)", time_unit), y = "Survival probability",
         title = sprintf("Kaplan-Meier survival by %s with log-rank test", group)) +
    theme(legend.position = "bottom")
  f <- file.path(plot_dir, "km_result.png")
  ggsave(f, p, width = 8, height = 6.5, dpi = 150)
  cat("\nSaved:", f, "\n")
}

main_function1 <- function(dat, time, status, group, alpha = 0.05, timepoints = NULL,
                           plot_dir = NULL, time_unit = "time units") {
  d <- validate_inputs(dat, time, status, group)
  a <- check_assumptions(d)
  r <- run_test(d, alpha, timepoints)
  report_conclusion(r, a, attr(d, "labels"))
  if (!is.null(plot_dir)) save_result_plot(d, r, group, plot_dir, time_unit)
  r$assumptions <- a
  invisible(r)
}
