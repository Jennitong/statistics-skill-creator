## EDA code for Kaplan-Meier + log-rank
#
# Usage (from the skill directory):
#   source("scripts/eda_code.R")
#   run_eda(dat, time = "time", status = "status", group = "sex", plot_dir = "<dir>")
#
# Produces (all PNG, in plot_dir):
#   summary_table.png    gtsummary descriptive table by group
#   km_curve.png         Kaplan-Meier curves by group with number-at-risk table
#   followup_km.png      reverse Kaplan-Meier (follow-up / censoring distribution) by group
#   time_hist.png        histogram of observed times, events vs censored, by group
# and prints a censoring summary table to stdout.
#
# All the relevant plots should be shown for the client to review, one Read call per PNG.
# Do not hand-type counts or redraw plots with another charting library.

source("scripts/validate.R")
suppressPackageStartupMessages({
  library(ggplot2); library(ggsurvfit); library(gtsummary); library(flextable)
})

run_eda <- function(dat, time, status, group, plot_dir = ".", time_unit = "time units") {
  d <- validate_inputs(dat, time, status, group)
  dir.create(plot_dir, showWarnings = FALSE, recursive = TRUE)

  ## Data quality / censoring summary (printed)
  cat("\n== Censoring summary by group ==\n")
  cs <- do.call(rbind, lapply(split(d, d$group), function(x) data.frame(
    n = nrow(x), events = sum(x$status), censored = sum(x$status == 0),
    pct_censored = round(100 * mean(x$status == 0), 1),
    min_time = min(x$time), max_time = max(x$time))))
  print(cs)
  cat(sprintf("Overall: n = %d, events = %d, censored = %d (%.1f%%)\n",
              nrow(d), sum(d$status), sum(d$status == 0), 100 * mean(d$status == 0)))

  ## Reverse KM median follow-up (censoring treated as the "event")
  rev_fit <- survfit(Surv(time, 1 - status) ~ group, data = d)
  cat("\n== Median follow-up (reverse Kaplan-Meier) by group ==\n")
  print(summary(rev_fit)$table[, c("records", "median", "0.95LCL", "0.95UCL"), drop = FALSE])

  ## Summary statistics table
  tab_dat <- data.frame(Time = d$time,
                        Status = factor(d$status, 0:1, c("Censored", "Event")),
                        Group = d$group)
  names(tab_dat)[3] <- group
  tbl <- tbl_summary(tab_dat, by = all_of(group),
                     statistic = list(all_continuous() ~ "{median} ({p25}, {p75}); range {min}-{max}")) |>
    add_overall() |>
    modify_caption(sprintf("**Summary of `%s` and `%s` by `%s`**", time, status, group))
  save_as_image(as_flex_table(tbl), path = file.path(plot_dir, "summary_table.png"))

  ## Kaplan-Meier curve with risk table
  fit <- survfit2(Surv(time, status) ~ group, data = d)
  p_km <- ggsurvfit(fit, linewidth = 0.9) +
    add_confidence_interval() +
    add_censor_mark(size = 2) +
    add_risktable() +
    labs(x = sprintf("Time (%s)", time_unit), y = "Survival probability",
         title = sprintf("Kaplan-Meier survival curves by %s", group)) +
    theme(legend.position = "bottom")
  ggsave(file.path(plot_dir, "km_curve.png"), p_km, width = 8, height = 6.5, dpi = 150)

  ## Reverse KM (follow-up) plot
  rfit <- survfit2(Surv(time, 1 - status) ~ group, data = d)
  p_rev <- ggsurvfit(rfit, linewidth = 0.9) +
    labs(x = sprintf("Time (%s)", time_unit), y = "Probability still under follow-up",
         title = sprintf("Reverse Kaplan-Meier (censoring pattern) by %s", group)) +
    theme(legend.position = "bottom")
  ggsave(file.path(plot_dir, "followup_km.png"), p_rev, width = 8, height = 5, dpi = 150)

  ## Histogram of observed times
  hd <- data.frame(time = d$time, Outcome = factor(d$status, 0:1, c("Censored", "Event")), group = d$group)
  p_hist <- ggplot(hd, aes(time, fill = Outcome)) +
    geom_histogram(bins = 25, colour = "white", position = "stack") +
    facet_wrap(~group, ncol = 1) +
    labs(x = sprintf("Observed time (%s)", time_unit), y = "Count",
         title = sprintf("Observed times by %s: events vs censored", group)) +
    theme_minimal()
  ggsave(file.path(plot_dir, "time_hist.png"), p_hist, width = 8, height = 2 + 1.8 * nlevels(d$group), dpi = 150)

  cat("\nSaved:", paste(file.path(plot_dir, c("summary_table.png", "km_curve.png",
                                                "followup_km.png", "time_hist.png")), collapse = "\n       "), "\n")
  invisible(d)
}
