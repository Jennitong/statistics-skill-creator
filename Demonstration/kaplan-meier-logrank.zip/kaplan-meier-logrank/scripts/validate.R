# validate.R
#
# Shared input validation for every script in this skill (EDA, diagnostics, task codes).
# Mirrors SKILL.md Step 1 exactly. Sourced by the other scripts; run from the skill dir.
#
# Rules:
#   - `time`, `status`, `group` must be existing columns of `dat`
#   - rows with NA in time/status/group are reported, then excluded
#   - time must be numeric and strictly > 0
#   - status must be coded 0/1 (1 = event, 0 = censored) or TRUE/FALSE; anything else
#     (e.g. the 1/2 coding of survival::lung) is rejected, never silently recoded
#   - group must have at least 2 levels after NA removal
#   - censored rows are never dropped or treated as events

suppressPackageStartupMessages(library(survival))

validate_inputs <- function(dat, time, status, group, quiet = FALSE) {
  if (!is.data.frame(dat)) stop("Input `dat` must be a data frame.", call. = FALSE)
  missing_cols <- setdiff(c(time, status, group), names(dat))
  if (length(missing_cols) > 0)
    stop("Column(s) not found in data: ", paste(missing_cols, collapse = ", "), call. = FALSE)

  d <- data.frame(time = dat[[time]], status = dat[[status]], group = dat[[group]])

  na_rows <- !complete.cases(d)
  n_na <- sum(na_rows)
  if (n_na > 0 && !quiet)
    cat(sprintf("NOTE: %d row(s) with NA in `%s`, `%s` or `%s` were excluded (n = %d -> %d).\n",
                n_na, time, status, group, nrow(d), nrow(d) - n_na))
  d <- d[!na_rows, , drop = FALSE]
  if (nrow(d) == 0) stop("No complete rows remain after excluding NAs.", call. = FALSE)

  if (!is.numeric(d$time))
    stop(sprintf("Time column `%s` must be numeric.", time), call. = FALSE)
  if (any(d$time <= 0))
    stop(sprintf("Time column `%s` contains %d value(s) <= 0; survival times must be strictly positive.",
                 time, sum(d$time <= 0)), call. = FALSE)

  if (is.logical(d$status)) {
    d$status <- as.integer(d$status)
  } else if (is.numeric(d$status) && all(d$status %in% c(0, 1))) {
    d$status <- as.integer(d$status)
  } else {
    vals <- paste(sort(unique(d$status)), collapse = ", ")
    stop(sprintf(paste0("Status column `%s` must be coded 0/1 (1 = event, 0 = censored) or TRUE/FALSE; ",
                        "found values: %s. Please recode it explicitly before running."), status, vals),
         call. = FALSE)
  }

  d$group <- droplevels(factor(d$group))
  if (nlevels(d$group) < 2)
    stop(sprintf("Group column `%s` must have at least 2 levels; found %d.", group, nlevels(d$group)),
         call. = FALSE)

  attr(d, "labels") <- list(time = time, status = status, group = group, n_na = n_na)
  d
}

# p-value formatting convention from SKILL.md Step 5
fmt_p <- function(p) {
  if (is.na(p)) return("NA")
  if (p < 0.001) return("p < 0.001 (***)")
  if (p < 0.01)  return("p < 0.01 (**)")
  if (p < 0.05)  return("p < 0.05 (*)")
  sprintf("p = %.4f", p)
}

fmt_num <- function(x, digits = 2) ifelse(is.na(x), "not reached", formatC(x, format = "f", digits = digits))
