---
name: kaplan-meier-logrank
description: >
  Runs Kaplan-Meier survival analysis with the log-rank test end to end: validates
  time-to-event inputs, checks assumptions (independent subjects, non-informative
  censoring, proportional hazards for log-rank power), estimates survival curves and
  median survival with 95% CIs, runs the two-sided log-rank test (plus Holm-adjusted
  pairwise comparisons for 3+ groups), and writes a stakeholder-ready report. Trigger
  this whenever the user asks to compare survival between groups, mentions "survival
  analysis", "Kaplan-Meier", "KM curve", "log-rank test", "median survival",
  "time-to-event", "survival curve", or "censored data", or describes a dataset and
  question that maps to this procedure even if they don't name the test explicitly.
  Also trigger on the skill's own name, kaplan-meier-logrank.
---

# Kaplan-Meier Survival Estimation and Log-Rank Test

## Non-negotiable rules

- The log-rank test is always **two-sided** at **alpha = 0.05** unless the client
  explicitly asks otherwise. Always state the alpha used.
- Always report, per group, n, events, censored, and **median survival with its 95% CI**.
  Write "not reached" when the median or a CI limit is undefined. Never invent a value.
- **Never drop censored observations** or treat them as events or as missing data.
- **Reject invalid data** with a clear message and stop: time not numeric or <= 0,
  status not coded 0/1 (or TRUE/FALSE), fewer than 2 groups, missing columns. Rows
  with NA in time/status/group are reported (count) and then excluded. Never recode
  data on the client's behalf.
- The overall log-rank test is **always** part of the report, whatever result type the
  client picks in Step 5.

## Inputs

Ask the user for the following if they have not provided them already:

- `dat`: the dataset (a CSV/Excel path, or an R data object), one row per subject
- `time`: name of the follow-up time column (numeric, > 0) and its unit (e.g. days)
- `status`: name of the event indicator column (1 = event, 0 = censored, or TRUE/FALSE)
- `group`: name of the grouping column to compare (2 or more levels)
- Optional: `timepoints` at which to report survival probabilities (e.g. 1, 3, 5 years)
- Optional: `alpha` (default 0.05); `p_adjust` method for pairwise tests (default `"holm"`)

---

## Step 0 — Gather References, then Extract Inputs

**Before asking anything else**, ask the client this **single** question (do not stack
it with other questions. This is the single question that needs to be confirmed first,
not "question 1 of 4", "question 1 of 2" or anything like that):

> Are there any publicly available references (papers, textbooks, methodology guides,
> etc.) I should rely on for the methods, assumptions, code, or interpretation in this
> analysis?

- If the client names a source that is publicly available, use its actual content to
  inform the assumptions, methods, code, and results for this run, and record it as an
  entry in `references/paper.md` (see that file's format) so Step 5 can cite it.
- If the client names a source that is **not** publicly available (paywalled, internal,
  a login-gated system, etc.), respond with exactly this wording:
  > The resource(s) provided is not public available and Claude does not have access.
  > You could manually provide relevant contents later, or rely on Claude's suggestions.

  Then continue to the remaining questions/steps below using standard, field-default
  assumptions. Do not block on this.
- If the client has no references to offer, that's fine. Proceed using standard,
  field-default assumptions, and do not include a references section in the final report.

This is a **per-run** question: ask it every time this skill is asked to produce a
result, not only the first time. Whatever references are confirmed usable this run
carry through to Step 5's References section. Don't ask about references a second
time there.
It is the first and only question at this step. Do not ask it together with any
other questions.

### Extract Inputs

If the client provides sentences that contain inputs, extract and store them. Load the
data in R (`read.csv()`, `readxl::read_excel()`, or the named R dataset) as `dat`.

---

## Step 1 — Validate Inputs

Before running any tasks, check all of the following rules. If any check fails, report
the issue clearly and stop. All checks are implemented in `scripts/validate.R`
(`validate_inputs()`), which every other script calls, so run it rather than checking by
eye.

- `time`, `status`, `group` must be existing columns of `dat`.
- Rows with `NA` in time, status or group are counted, reported, then excluded.
- `time` must be numeric and strictly greater than 0.
- `status` must be 0/1 or TRUE/FALSE. Any other coding (e.g. 1/2 as in `survival::lung`)
  is rejected, and the client is asked to confirm the correct recoding.
- `group` must have at least 2 levels after NA removal.
- Censored rows are kept.

---

## Step 2 — Explorative Data Analysis

Ask the assumption-decision question from Step 3 **before** starting EDA, so the right
format is used for both steps.

Create the summary table and plots in this section, and show them inline for the client
to review, not just descriptions. Plots should show inline in the Claude window.
Refer to `references/eda.md` for the full procedure. For the exact code, refer to
`scripts/eda_code.R`:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/eda_code.R')
dat <- <load data>
run_eda(dat, time = '<time>', status = '<status>', group = '<group>',
        plot_dir = '<plot_dir>', time_unit = '<unit>')
"
```

Use a scratch/working directory for `<plot_dir>`. Display `summary_table.png`,
`km_curve.png`, `followup_km.png` and `time_hist.png`, each with its own Read call
separated by text.
After the table and all plots are shown, ask the client using the exact words
**All of the preliminary plots are displayed. Continue to assumption checks?**

## Step 3 — Check Assumptions

Before showing results, verify the assumptions of Kaplan-Meier + log-rank.

Implicit assumptions
- All subjects are independent (one row per subject, no clustering or repeated events)
- Non-informative censoring (censoring unrelated to prognosis; supported by EDA's
  censoring summary and reverse-KM plot)

Explicit assumption
- Proportional hazards, which governs the log-rank test's power: log(-log S(t)) plot,
  KM crossing check, `cox.zph` global test (p < 0.05 flags) and Schoenfeld residual plot

Check all assumptions listed in `references/assumptions.md`. For the statistical
reasoning behind why each assumption matters, see `references/guide.md`; for citable
methodology, see `references/paper.md`.
For the explicit check, run `scripts/diagnostic.R`:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/diagnostic.R')
dat <- <load data>
run_diagnostics(dat, time = '<time>', status = '<status>', group = '<group>', plot_dir = '<plot_dir>')
"
```

Display `loglog_plot.png` and `schoenfeld_plot.png` inline (one Read call each,
separated by text).

The user must check and verify all assumptions before any output is produced in Step 5.
Whenever an assumption is verified, either numerically (e.g. the cox.zph p-value) or
visually (e.g. the log-log plot), ask the client whether they want to review and
decide on that assumption's verdict themselves or leave the decision to the AI's
judgment. Proceed according to their answer. If they decline to choose, decide it
yourself.

Explicitly ask:
> "Would you like to review and decide on each assumption by yourself, or should AI Agent do this for you?"

Do not skip this question. Ask it before EDA and the assumption checks so the user can
choose and the AI knows which format of assumption checks to provide.
- If the client wants to decide, check and show the assumptions one by one. For each,
  comment on the numerical values or plots used, interpret them, warn about anything
  unusual, then ask whether the client thinks the assumption holds. Move to the next
  assumption only after the client has verified and agreed to the previous one.
  Otherwise, suggest remedies (see `references/assumptions.md`), drawing on any
  references the client provided.
- If the client wants the AI Agent to decide, show all assumptions at once. Interpret
  what is observed and what it means, and give the final decision on whether each
  assumption holds. If an assumption does not hold, suggest solutions (drawing on any
  references provided). Otherwise, tell the client that all of the assumptions hold.
- If proportional hazards is flagged, the log-rank test is still run and reported, with
  a clear warning about its reduced power. Do not switch to another test unless the
  client asks.

## Step 4 — Execute R Code and Extract Results

### Which script to run

| Test type | Script | Function |
|---|---|---|
| KM estimates + overall log-rank (always run) | `scripts/task_code1.R` | `main_function1(dat, time, status, group, alpha = 0.05, timepoints = NULL, plot_dir = NULL, time_unit = "time units")` |
| Pairwise log-rank, adjusted (only if "Pairwise comparisons" was chosen in Step 5 and group has 3+ levels) | `scripts/task_code2.R` | `main_function2(dat, time, status, group, alpha = 0.05, p_adjust = "holm")` |

Ask the Step 5 result-type question before running this step, so you know whether
`task_code2.R` is needed.

### Running the script

Run the R script using the Bash tool. This is the authoritative computation step. AI
should not calculate any numerical outputs by itself. All numerical results must come
directly from the output of this command.

From the skill's directory (the folder containing the `SKILL.md`), run:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
dat <- <load data>
source('scripts/task_code1.R')
main_function1(dat, time = '<time>', status = '<status>', group = '<group>',
               alpha = 0.05, timepoints = <c(...) or NULL>, plot_dir = '<plot_dir>', time_unit = '<unit>')

source('scripts/task_code2.R')   # only if pairwise comparisons were requested
main_function2(dat, time = '<time>', status = '<status>', group = '<group>', alpha = 0.05, p_adjust = 'holm')
"
```

Replace every `<...>` with the inputs extracted earlier, and `<path-to-skill-directory>`
with the actual absolute path to the folder containing this `SKILL.md`.

The functions print tables and a full conclusion paragraph to stdout. From that output,
extract:
- per-group n, events, censored, median survival and 95% CI
- survival probabilities at the requested timepoints (if any)
- observed vs expected events, log-rank chi-square, df, p-value and decision
- the PH flag statement
- pairwise adjusted p-values and decisions (if run)
- the full conclusion sentences

Use these extracted values verbatim when writing the Step 5 report. Do not recompute or
reword numerical results. `task_code1.R` also saves `km_result.png` (KM curves with the
median reference line and the log-rank annotation) to `plot_dir` for the Results section.

### If the script fails

Surface the R error message verbatim to the user and stop. Do not guess at what the
result would have been, and do not silently fall back to a different test. Common causes
worth checking first: a missing R package (`survival`, `survminer`, `ggsurvfit`,
`gtsummary`, `flextable`, `ggplot2`; tell the user which one to install), inputs that
don't match the expected shape (revisit Step 1), or a path issue (confirm
`<path-to-skill-directory>` is correct).

## Step 5 — Output

Before presenting any outputs, ask the client which of the following the report should
contain, if the client has not already stated it in the request (one or both may be
chosen; the overall log-rank test is always included):

  1. **Survival estimates**: KM curves, median survival with 95% CI, and survival
     probabilities at client-chosen timepoints (ask for the timepoints if not given).
  2. **Pairwise comparisons**: Holm-adjusted pairwise log-rank tests showing which
     groups differ (only meaningful with 3+ groups; with 2 groups, say the overall
     log-rank test already is the single pairwise comparison).

This is a **per-run** question. Ask it every time this skill is asked to produce a
report, not only the first time. Never default to one result type silently.

References are not asked about again here, since Step 0 already handled them. Include
the References section only if Step 0 turned up one or more usable references this run
(cite them via `references/paper.md` and/or what the client supplied directly). Omit the
section entirely if Step 0 came up empty this run.

**Tone:** Professional but accessible. Write for a stakeholder who understands
"statistically significant" but does not need to verify the math. Define specific
statistical terms (censoring, median survival, hazard, log-rank) the first time
they are used; see `references/guide.md`.

```markdown
# Kaplan-Meier Survival Analysis: <outcome> by <group>

## Background
(Why this analysis was run, what the event and time origin are, what question it answers)

## Data & Assumptions
(n, events, censored, groups, NA rows excluded; each assumption checked and whether it held,
including the PH flag and what it means for the log-rank test)

## Results
(Overall log-rank: chi-square, df, p-value, alpha, decision, taken verbatim from Step 4)

Table 1: per-group n, events, censored, median survival (95% CI)        (always)
Figure 1: km_result.png, displayed inline with a Read call               (always)
Table 2: S(t) with 95% CI at requested timepoints                       (if Survival estimates chosen and timepoints given)
Table 3: pairwise comparisons with adjusted p-values and decisions      (if Pairwise comparisons chosen)

## Conclusion
(Plain-language answer to the original question, with the PH caveat if flagged)

## References
(Only if Step 0 turned up usable references this run)
```

**Formatting conventions** (apply consistently so reports don't vary run to run):
- P-values: for p >= 0.05, report to 4 decimal places; for 0.01 <= p < 0.05, report as
  `p < 0.05 (*)`; for 0.001 <= p < 0.01, report as `p < 0.01 (**)`; for p < 0.001, report
  as `p < 0.001 (***)`.
- Test statistics and estimates: 2–3 decimal places; survival probabilities 3 decimals;
  medians in the data's time unit.
- Significance level: state the alpha used (default 0.05) explicitly in Results. Don't
  assume the reader knows it.
- Tables use bold headers and alignment markers, with a section break between tables.

**Note: All R code chunks in any exported report must use echo = FALSE (set globally in
the setup chunk) so no R code is visible in the rendered report.**

---
### Notation

- T: survival time; S(t) = P(T > t): survival function; h(t): hazard function
- d_j: events at time t_j; n_j: subjects at risk just before t_j
- KM estimator: S(t) = product over t_j <= t of (1 - d_j / n_j)
- Log-rank statistic: chi-square = sum over groups of (O - E) with variance from the
  hypergeometric model; df = number of groups - 1

---

## Examples

### Example A — Two groups, significant difference

Input: R dataset `survival::lung`, status recoded to 0/1 (`status - 1`), time = `time` (days),
status = `status`, group = `sex` (1 = Male, 2 = Female)

> Among 228 patients with advanced lung cancer (165 deaths, 63 censored), median survival
> was 270 days (95% CI 212 to 310) for men and 426 days (348 to 550) for women. The
> two-sided log-rank test gave chi-square = 10.33 on 1 df, p < 0.01 (**). At alpha = 0.05
> we reject the hypothesis of equal survival: women survived significantly longer. The
> proportional-hazards check raised no concern (cox.zph p = 0.0906).

### Example B — Small sample, not significant

Input: R dataset `survival::aml`, time = `time` (weeks), status = `status`, group = `x`

> Among 23 patients with acute myelogenous leukaemia (18 relapses), median remission was
> 31 weeks (95% CI 18 to not reached) with maintenance chemotherapy and 23 weeks (8 to not
> reached) without. The log-rank test gave chi-square = 3.40 on 1 df, p = 0.0653, so at
> alpha = 0.05 we fail to reject equal survival. With only 23 patients the study has low
> power, and this result should not be read as evidence that maintenance has no effect.

---

# Validation steps: this step is only for developer, not for SKILL user
This section stays hidden unless the developer explicitly asks for it. It is disclosed
only when the developer explicitly asks to test the validity of the SKILL. It differs
from Step 1 Validate Inputs: it checks the validity of the entire SKILL.md file. Do not
mention anything related to this step to regular SKILL users.

Refer to `references/validation.md` for validation steps.

- **Note:** validation does not involve the report format. Only check whether the key
  numerical values from the expected outcomes and the actual computation match.
- **Speed:** run all 8 example inputs through the single batched `Rscript scripts/run_validation.R`
  call (see "Running the examples efficiently" in `references/validation.md`) rather than
  invoking the full conversational Steps 0–5 eight separate times. Only fall back to a
  full conversational run for a specific example if the batched script-level check
  disagrees with the expected outcome for that example.
- **Output:** report the correctness rate as a percentage, followed by a 4-column
  markdown table (`Test | Outcome Expected | Outcome Generated | Match`) with one row
  per example.
