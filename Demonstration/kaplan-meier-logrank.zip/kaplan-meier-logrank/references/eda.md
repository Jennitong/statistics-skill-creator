# Exploratory Data Analysis (EDA)

**Rule**: The relevant plots need to be displayed inline for the client to review,
with brief interpretations. The plots should show inline directly.

**Rule**: The exact R code should be run by the AI Agent. Any plots or tables should be
generated using the R code directly. Refer to `scripts/eda_code.R` for the code
(function `run_eda(dat, time, status, group, plot_dir, time_unit)`).

**Rule**: Every plot below is the literal PNG file R rendered, displayed inline
with its own Read tool call immediately after it is generated. Never redraw it with a
charting library from re-extracted data points. All relevant plots should be shown
for the client to review. **Do not** just write interpretations/descriptions; the client
should be able to see the plots themselves. Plots should be inline in the chat window.

**Rule**: Display each plot/table with the Read tool only, directly in the chat
window: one large inline image per plot, readable without clicking. Issue Read calls
**one at a time**, each with a sentence of text immediately before or after it. Never
make two or more Read calls back to back with nothing in between, since the client
collapses consecutive Read calls into a hidden "Read N files" accordion that hides the
images. Do not also send the file via `SendUserFile`, and never publish plots/tables as
a separate Artifact/hosted page. Everything must render inline in the chat window itself.


## 1. Establish Context

Before touching code, determine and state:
- What one row represents (should be one subject).
- What the event is (death, relapse, failure, churn...) and what censoring means here.
- The time origin and unit (e.g. days since randomisation).
- The grouping variable being compared.
- The provenance and collection method of the data, and the period covered, if known.
- The question the analysis is meant to answer.

If this context is not available from the user or accompanying documentation, note the
gap explicitly rather than assuming.

## 2. Data Quality Checks

Report as findings, not just output:
- Rows excluded for NA in time/status/group (printed by `validate_inputs()`), and
  whether missingness seems concentrated in one group.
- Duplicated subject IDs, if an ID column exists.
- Group labels that look like typos or should be collapsed (e.g. "Male" / "male").
- Implausible times (extremely large values, all times identical).
- Very small groups or groups with few events. Note them, since medians may be
  "not reached" and CIs wide.

## 3. Initial Inspection

- **Summary statistics table**: `summary_table.png`, made by `gtsummary::tbl_summary()`
  (time median/IQR/range and event vs censored counts, by group plus overall). Do not
  hand-type medians or counts. Display the PNG inline under the "Summary Statistics"
  heading. If `flextable` fails to render, surface the R error verbatim and stop. Do
  not fall back to a hand-typed table.
- **Censoring summary** (printed): n, events, censored, % censored, min/max time per
  group, and median follow-up from the reverse Kaplan-Meier.

## 4. Visual Inspection (Plots)

From `scripts/eda_code.R`, each displayed with its own Read call:
1. `km_curve.png`: Kaplan-Meier curves by group, with 95% CI bands, censoring ticks
   and a number-at-risk/events table. Comment on separation, crossing, and where the
   number at risk gets small (tail estimates unreliable).
2. `followup_km.png`: reverse Kaplan-Meier (censoring pattern) by group. Comment on
   whether follow-up is similar across groups. This is evidence for assumption 2.
3. `time_hist.png`: histogram of observed times, events vs censored, by group. Comment
   on early heavy censoring or event clustering.

## 5. Pitfalls to Avoid

- Never drop censored observations or treat them as missing; they carry information.
- Do not read the tail of a KM curve with few subjects at risk as precise.
- Do not report association as causation (groups are often not randomised).
- Do not perform cleaning, recoding or imputation that the client has not confirmed.

# Format: the table and plots should be shown in the format below

```markdown

# Exploratory Data Analysis

## Context
(context bullets from section 1)

## Data Quality Checks
(findings from section 2, including the censoring summary)

## Summary Statistics Table
(summary_table.png displayed inline)

## Plots
(km_curve.png, followup_km.png, time_hist.png, each displayed inline with a 1-2 sentence interpretation)

```
