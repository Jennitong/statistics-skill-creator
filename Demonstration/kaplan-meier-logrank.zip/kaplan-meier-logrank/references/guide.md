# Guide

Guidelines and conventions for running Kaplan-Meier + log-rank in this skill. This file
covers the "why" and "how to interpret" behind the checks in `assumptions.md`, not the
checks themselves.

## Key terms (define for the reader when used)

- **Event**: the outcome of interest (e.g. death); status = 1.
- **Censored**: the subject's event time is unknown beyond their last follow-up;
  status = 0. They were event-free *at least* until that time.
- **Survival function S(t)**: probability of remaining event-free beyond time t.
- **Kaplan-Meier estimator**: a step-function estimate of S(t) that uses censored
  subjects for as long as they were observed.
- **Median survival**: the first time at which S(t) drops to 0.5 or below. It is
  "not reached" if the curve never falls to 0.5. Never invent a value then.
- **Hazard**: the instantaneous event rate among those still at risk.
- **Log-rank test**: compares observed and expected numbers of events in each group
  under H0 that all groups share the same survival curve. Its statistic is
  chi-square with (number of groups - 1) df.

## How to interpret results

- The log-rank test answers *whether* the curves differ, not *by how much*. For
  magnitude, use the medians and the survival probabilities at timepoints.
- With 3+ groups, a significant overall test says at least one group differs. Use the
  pairwise comparisons (if the client asked for them) to say which.
- Overlapping median CIs do **not** imply a non-significant log-rank test, and vice
  versa. Report both and do not infer one from the other.
- An upper CI limit of "not reached" (NA) means the curve's upper confidence band never
  fell to 0.5. Say so plainly.

## How to interpret assumption failures

- **Independence violated**: CIs and p-values are too small. The analysis should not
  be reported as-is.
- **Informative censoring suspected**: KM estimates are biased, usually upward if
  sicker subjects drop out. Say the direction is uncertain unless the reason for
  censoring makes it clear.
- **Non-proportional hazards / crossing curves**: the log-rank test is still valid
  but loses power. A non-significant result must not be read as "no difference".
  Suggest Peto-Peto (`rho = 1`), Fleming-Harrington weights, landmark or fixed-timepoint
  comparisons, or RMST. Do not run these unless the client asks.

## Common pitfalls to avoid

- Do not report a log-rank p-value without the per-group medians (with 95% CI), n,
  events and censored counts.
- Do not run one-sided log-rank tests unless the client explicitly asks.
- Do not recode the status variable on the client's behalf (e.g. 1/2 to 0/1). Stop and
  ask them to confirm the coding.
- Do not run pairwise tests without multiple-comparison adjustment (default Holm).
- Do not over-interpret the right tail of KM curves where few subjects remain at risk.
- Do not use language implying causation for non-randomised groups.
