# Check Assumptions

This document lists every assumption to check for Kaplan-Meier estimation and the
log-rank test.

**Note**: AI Agent should run all the **exact** R code for assumption checks and output.
AI should not generate the plots or calculate any values using its own method.
For code that verifies each explicit assumption, refer to `scripts/diagnostic.R`
(function `run_diagnostics()`); the censoring evidence used for assumption 2 comes from
`scripts/eda_code.R` (function `run_eda()`).

## All Assumptions:
1. Independent subjects (implicit)
2. Non-informative censoring (implicit)
3. Proportional hazards, which affects the log-rank test's power (explicit)

Then step through each assumption one at a time.

### 1. Independent subjects (Implicit)
Each row is a distinct subject, and one subject's survival time tells us nothing about
another's. Repeated or recurrent events for the same subject, clustered data (e.g. both
eyes of one patient, patients within hospitals) or matched pairs violate this.

How to check: ask the client how the data were collected if this is not already clear
(one row per subject? any clustering?). If an ID column exists, confirm it has no
duplicates.

If violated: stop and explain that standard KM confidence intervals and the log-rank
test will be over-confident. Suggest keeping only the first event per subject, or a
method that handles clustering (e.g. a Cox model with `cluster()` robust variance,
or a frailty model). These are outside the scope of this skill.

### 2. Non-informative censoring (Implicit)
Subjects who are censored (lost to follow-up, withdrawn, study ended) must have the
same future risk of the event as subjects still under observation. Censoring should be
unrelated to prognosis, e.g. patients who drop out are not sicker.

How to check: this cannot be tested from the data alone and is judged from the study
design. Ask the client why subjects were censored (administrative end of study is
reassuring; dropout due to worsening health is not). Use the EDA evidence as support:
- censoring summary (percent censored per group), from `scripts/eda_code.R`
- reverse Kaplan-Meier follow-up plot `followup_km.png`. Clearly different follow-up
  patterns between groups suggest censoring may differ by group and deserve comment.
- histogram `time_hist.png`. Look for censoring concentrated early in one group.

If violated or doubtful: warn that KM estimates may be biased (usually too optimistic
if sicker subjects drop out) and that the log-rank comparison may be distorted. Suggest
sensitivity analyses (e.g. treating dropouts as events for a worst-case bound). Do not
drop or alter censored rows.

### 3. Proportional hazards / log-rank power (Explicit)
The log-rank test is valid without proportional hazards (PH), but it is most powerful
when the hazard ratio between groups is constant over time. When hazards are
non-proportional, and especially when the survival curves cross, early and late
differences cancel out and the test can miss a real difference.

Refer to `scripts/diagnostic.R` for the actual verification. It produces:
- `loglog_plot.png`: log(-log S(t)) against log(t) per group. Roughly parallel,
  non-crossing curves support PH.
- a KM crossing check (printed): flags any pair of curves whose difference changes sign
  by more than 0.02.
- the `cox.zph` test (printed), using a Cox model with group as the only covariate.
  Global p < 0.05 flags non-proportional hazards.
- `schoenfeld_plot.png`: scaled Schoenfeld residuals over time. A flat smooth around a
  horizontal line supports PH.

Decision rule (AI-decided mode): PH is flagged if the cox.zph global p < 0.05 **or** any
pair of KM curves crosses.

If violated: still report the log-rank result, but state clearly that it may have low
power and that a non-significant result is not evidence of equal survival. Suggest a
weighted alternative: the Peto-Peto test (`survdiff(..., rho = 1)`), which weights early
differences, or a Fleming-Harrington test. Also suggest comparing survival at specific
clinically relevant timepoints, or restricted mean survival time (RMST). Do not switch
tests silently. Only run an alternative if the client asks.

## Note:

All the relevant plots for assumptions should be shown for
the client to review. **Do not** just write interpretations/descriptions; the client
should be able to see the plots themselves. Plots should be inline in the chat window.
