# Paper

This file lists methodology sources backing the procedure in this skill. Cite these
in Step 5's "References" section when they inform how a test or assumption check was run.

No references were supplied when this skill was built. Each run, Step 0 asks the client
for publicly available references; record any usable ones below for that run, in this
format:

```markdown
## Short name (e.g. "Kaplan & Meier (1958)")
Citation: full citation, formatted in the style the client prefers
```
