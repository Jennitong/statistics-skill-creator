# Assumptions

This document contains all the assumptions to check before reporting results for the
two-sample proportion test.

## Implicit assumptions (both tests)

- The two groups (treatment and control) are **independent** random samples — e.g., a
  parallel-arm design. Not valid for paired, matched, or crossover designs.
- Each observation is **binary** (response / no response); responses within a group are
  independent of each other.
- Group sizes (`n.tx`, `n.ctrl`) and response counts (`resp.tx`, `resp.ctrl`) are fixed
  in advance of computing the test, not chosen after peeking at the result.

## Explicit, test-specific assumptions

### Chi-square test (`chisq.test`, used when all expected cell counts ≥ 5)

1. All four expected cell counts in the 2×2 contingency table are ≥ 5. This is verified
   automatically in Step 3 of `SKILL.md` and determines whether the chi-square test or
   Fisher's exact test is used.
2. The sample size is large enough for the chi-square approximation to the true sampling
   distribution to be reliable.

### Fisher's exact test (`fisher.test`, used when any expected cell count < 5)

1. Row and column totals (marginal totals) of the contingency table are treated as
   fixed.
2. No large-sample approximation is made — this is why Fisher's exact test remains
   valid when expected counts are small, unlike the chi-square test.

