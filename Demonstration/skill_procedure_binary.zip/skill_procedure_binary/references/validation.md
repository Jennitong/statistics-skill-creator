# Validation

Checks the validity and correctness of the SKILL. There will be examples of numerous inputs
and outcomes expected. The actual output that will be generated using the SKILL would be compared
with expected outcomes, and if the correctness rate is over 100% (i.e., no more than zero of
the 20 examples below may be incorrect), the SKILL is overall valid. Report the exact correctness.

Triggered when developer explicitly asks for the validity of the skill, the accuracy and correctness
of the test result, or anything similar.

- `n.tx` is number of participants in treatment group
- `n.ctrl` is number of participants in control group
- `resp.tx` is number of people who responded in treatment group
- `resp.ctrl` is number of people who responded in control group

## Running the examples efficiently

Do **not** invoke the full conversational skill (Steps 0–5) separately for each of the 20
examples below — that requires 20 separate `Rscript` process starts plus 20 rounds of prose
generation, and is unnecessarily slow. Since Step 4 of `SKILL.md` requires every numerical
result to come verbatim from `scripts/Two_sample_proportion_with_multiple_functions.R`, and
Step 3's test-selection rule is a direct mirror of `choose_test()` in that same script, the
numerical/decision path is fully deterministic. To validate it quickly:

1. Write a single `Rscript -e` call (or a small `.R` file) that loops over all 20 input sets
   below, calls `two_sample_proportion_test()` once per case (wrapping calls that are expected
   to error in `tryCatch`), and prints each result. This runs in one R process instead of 20.
2. Compare each generated result against the expected outcome for that example (test type,
   rounded statistic, p-value bucket, decision, and conclusion direction — exact wording does
   not need to match, but the substance must).
3. Only fall back to running the full conversational skill end-to-end if this script-level
   check reveals a discrepancy, to determine whether the bug is in the R script, in `SKILL.md`'s
   instructions, or in how the assistant is following them.

  - Example 1
Input: n.tx = 10, n.ctrl = NA, resp.tx = 1.2, resp.ctrl = 3
Output expected: The result is invalid. n.ctrl cannot be missing, and responder
  counts must be natural numbers.

  - Example 2
Input: n.tx = 50, n.ctrl = 40, resp.tx = 30, resp.ctrl = 10
Output expected: Chi-square test will be chosen; test statistic rounds up to 11.03;
  p-value is less than 0.001 (***); reject the null hypothesis of independence;
  receiving treatment is associated with response.

  - Example 3
Input: n.tx = 10, n.ctrl = 20, resp.tx = 2, resp.ctrl = -3
Output expected: The result is invalid. Responder counts in control must be positive.

  - Example 4
Input: n.tx = 10, n.ctrl = 30, resp.tx = 12, resp.ctrl = 3
Output expected: The result is invalid. The responder counts in treatment should
not exceed the number of participants in treatment group.

  - Example 5
Input: n.tx = 50, n.ctrl = 40, resp.tx = 26, resp.ctrl = 19
Output expected: Chi-square test will be chosen; test statistic rounds up to 0.18;
  p-value rounds to 0.67; do not reject the null hypothesis of independence;
  receiving treatment is not associated with response.

  - Example 6
Input: n.tx = 20, n.ctrl = 10, resp.tx = 5, resp.ctrl = 2
Output expected: Fisher's Exact test will be chosen; odds ratio is 1.33;
  p-value is 1.0; do not reject the null hypothesis of independence;
  receiving treatment is not associated with response.

  - Example 7
Input: n.tx = 10, n.ctrl = 15, resp.tx = 10, resp.ctrl = 1
Output expected: Fisher's Exact test will be chosen; odds ratio is not defined (infinite);
  p-value is smaller than 0.001 (***); reject the null hypothesis of independence;
  receiving treatment is associated with response.

  - Example 8
Input: n.tx = 1000, n.ctrl = 1000, resp.tx = 300, resp.ctrl = 700
Output expected: Chi-squared test will be chosen; test statistic is 320;
  p-value is less than 0.001 (***); reject the null hypothesis of independence;
  Thus receiving treatment or not is associated with the response.

  - Example 9
Input: n.tx = 2388, n.ctrl = 2844, resp.tx = 1000, resp.ctrl = 1200
Output expected: Chi-squared test test will be chosen; test statistic is  0.0539;
  p-value is 0.8164; fail to reject the null hypothesis of independence;
  receiving treatment is not associated with response.

  - Example 10
Input: n.tx = 23, n.ctrl = 34, resp.tx = 12, resp.ctrl = 11
Output expected: Chi squared test will be chosen; test statistic is 2.2394;
  p-value is 0.1345; fail to reject the null hypothesis of independence;
  receiving treatment is not associated with response.

  - Example 11
Input: n.tx = 23, n.ctrl = 34, resp.tx = 5, resp.ctrl = 5
Output expected: Fisher's Exact test will be chosen; odds ratio is 1.6111;
  p-value is 0.5036; fail to reject the null hypothesis of independence;
  receiving treatment is not associated with response.

  - Example 12
Input: n.tx = 23, n.ctrl = 34, resp.tx = 5, resp.ctrl = 20
Output expected: Chi squared test will be chosen; test statistic is 7.6626;
  p-value is less than 0.01 (**); reject the null hypothesis of independence;
  receiving treatment is associated with response.

  - Example 13
Input: n.tx = 0, n.ctrl = 34, resp.tx = 0, resp.ctrl = 5
Output expected: Input invalid. Please check numerical values. Treatment participant
total should be greater than 0.

  - Example 14
Input: n.tx = 1000, n.ctrl = 3400, resp.tx = 0, resp.ctrl = 50
Output expected: Chi squared test will be chosen; test statistic is 14.87;
  p-value is less than 0.001 (***); reject the null hypothesis of independence;
  receiving treatment is associated with response.

  - Example 15
Input: n.tx = 1000, n.ctrl = 3400, resp.tx = 2, resp.ctrl = 5
Output expected: Fisher's Exact test will be chosen; odds ratio is 1.3607;
  p-value is 0.6612; fail to reject the null hypothesis of independence;
  thus receiving treatment or not is not associated with the response.

  - Example 16
Input: n.tx = 10, n.ctrl = 20, resp.tx = 3, resp.ctrl = 5
Output expected: Fisher's Exact test will be chosen; odds ratio is 1.2857;
  p-value is close to 1.0 ; fail to reject the null hypothesis of independence;
  receiving treatment is not associated with response.

  - Example 17
Input: n.tx = 34924, n.ctrl = 29432, resp.tx = 492, resp.ctrl = 2393
Output expected: Chi squared test will be chosen; test statistic is 1685.36;
  p-value is less than 0.001 (***); reject the null hypothesis of independence;
  receiving treatment is associated with response.

  - Example 18
Input: n.tx = 34924, n.ctrl = 29432, resp.tx = 492, resp.ctrl = 0
Output expected: Chi squared test will be chosen; test statistic is 417.8244;
  p-value is less than 0.001 (***); reject the null hypothesis of independence;
  receiving treatment is associated with response.

  - Example 19
Input: n.tx = 15, n.ctrl = 15, resp.tx = 1, resp.ctrl = 1
Output expected: Fisher's Exact test will be chosen; odds ratio is 1;
  p-value is 1.0; fail to reject the null hypothesis of independence;
  receiving treatment is not associated with response.

  - Example 20 (tests the optional `threshold` argument, not just the default 0.05)
Input: n.tx = 100, n.ctrl = 100, resp.tx = 30, resp.ctrl = 16, threshold = 0.01
Output expected: Chi squared test will be chosen; test statistic is 5.5336;
  p-value is less than 0.05 (*) ; fail to reject the null hypothesis of independence;
  receiving treatment is not associated with response at the 0.01 level.

---
# Correctness Rate
Generate the actual output using the SKILL (see "Running the examples efficiently" above
for how to do this without 20 separate full skill invocations), then verify if the key
values in the actual output (test type chosen, statistic, p-value bucket, decision, and
conclusion direction) are equivalent to the expected output shown above — wording does not
have to match exactly, and numerical values can be rounded. Check whether the correctness
rate is over 100% (i.e., no more than zero of the 20 examples may be incorrect).

Report:
1. The correctness rate as a percentage (e.g., "20/20 = 100%").
2. A markdown table with exactly these four columns: `Test | Outcome Expected | Outcome
   Generated | Match`, one row per example (20 rows). Keep each cell terse (a short phrase
   per field, e.g. test type + decision), not a full paragraph.
3. If any example does not match, name it and explain the discrepancy in one sentence.
