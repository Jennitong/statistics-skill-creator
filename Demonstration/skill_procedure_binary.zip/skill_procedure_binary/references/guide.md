# Guide — Why Each Assumption Matters

## Independence of the two groups

If treatment and control observations are not independent (e.g., the same subject
appears in both arms, or subjects are matched pairs), the variance formulas used by
both the chi-square and Fisher's exact test are wrong, and the resulting p-value is not
trustworthy in either direction.

## Binary outcome

Both tests are built on the binomial model for each arm. If the outcome is not truly
binary (e.g., an ordinal or continuous response was dichotomized), the dichotomization
threshold should be chosen and reported independently of the observed data, or the test
decision becomes a hidden researcher degree of freedom.

## Expected cell count ≥ 5 (the chi-square vs. Fisher's exact switch)

The chi-square statistic is only approximately chi-square distributed; the
approximation degrades when any expected cell count is small, inflating the false
positive rate. Fisher's exact test computes the exact hypergeometric probability of the
observed table (and more extreme tables) conditional on the fixed margins, so it remains
valid at any sample size — the tradeoff is lower power, which is why it isn't used by
default when the chi-square approximation is safe.

## Fixed margins in Fisher's exact test

Fisher's exact test conditions on both the row totals (`n.tx`, `n.ctrl`) and column
totals (total responders, total non-responders) being fixed. In a real two-arm trial
the row totals are fixed by design, but the column totals are not truly fixed. These
totals are fixed background, and should not be changed.

## Confidence interval methods

- **Clopper-Pearson (exact)** for each arm's response rate: guarantees the interval has
  at least the nominal coverage for any sample size, at the cost of being somewhat
  conservative (wider than necessary) for large samples.
- **Newcombe (score-based)** for the difference in response rates: avoids the boundary
  problems of a simple Wald interval on a difference of two proportions (which can
  produce intervals that extend past [-1, 1] or that have poor coverage near 0 or 1).
