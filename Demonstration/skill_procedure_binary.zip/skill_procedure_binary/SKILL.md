---
name: skill-procedure-binary
description: >
  Performs a two proportion test in R given four numbers: treatment total,
  control total, treatment responses, and control responses. Automatically selects
  between a chi-square test and Fisher's exact test based on expected cell count
  criteria (≥ 5 rule), explains the assumptions of the chosen test, and returns
  a complete interpretation and conclusion paragraph. Use this skill whenever the
  user provides counts from a two-group experiment and wants to compare proportions
  or test for a significant difference — even if they don't use the words "proportion
  test" or "A/B test". Trigger on phrases like "is this significant?", "did the
  treatment work?", "compare two groups", "conversion rate test", "statistical tests",
  "summary statistics", "I have a study with X patients in the treatment arm", or
  whenever four numeric inputs represent group sizes and success/response counts.
  This skill assumes the two groups are independent. Do not use for crossover or
  within-subject designs. Also trigger on the skill's own name.
---

# Two-Sample Proportion Test (Hypothesis Testing)

## Non-negotiable rules

- Do not display anything to the user until Step 5. No formulas,
  intermediate tables, expected-cell-count numbers, or test-decision text may appear
  before that point.
- All numerical results (statistic, p-value, confidence intervals) must come verbatim
  from the R script's output in Step 4 — never calculated or rounded by hand.
- Never display raw R code, or variable notation (`n.tx`, `n.ctrl`, `resp.tx`,
  `resp.ctrl`) in any client-facing text. State the hypothesis and results in words.
- This skill assumes the two groups are **independent** random samples (e.g., a
  parallel-arm trial). It is not appropriate for paired, matched, or crossover designs.
- Use `*` only to annotate p-value significance bands (see Notation). No other symbol
  substitutes for that purpose.

## Inputs

Ask the user for exactly four numbers if they have not already provided them:

| Variable | Symbol | Meaning |
|---|---|---|
| Treatment total | n.tx | Number of subjects in the treatment group |
| Control total | n.ctrl | Number of subjects in the control group |
| Treatment responses | resp.tx | Number of successes/responses in the treatment group/arm |
| Control responses | resp.ctrl | Number of successes/responses in the control group/arm |

Optionally, the user may specify a significance level (`threshold`), which defaults to 0.05.

---

## Step 0 — Extract Inputs from Natural Language

If the user provides a sentence such as:

> "I have a study with X patients in the treatment arm, X patients in the control arm,
> X responders in the treatment group, and X responders in the control group."

Extract the four numbers:

| Phrase | Variable |
|---|---|
| "X patients in the treatment arm" | `n.tx` |
| "X patients in the control arm" | `n.ctrl` |
| "X responders in the treatment group" | `resp.tx` |
| "X responders in the control group" | `resp.ctrl` |

Do not output anything — assume the extracted values are correct. Nothing is reported
until Step 5.

---

## Step 1 — Validate Inputs

Before running any test, check all of the following. If any check fails, report the
issue clearly and stop.

- All four values are **positive integers** (`n.tx`, `n.ctrl` are ≥ 1; responses are ≥ 0)
- `resp.tx ≤ n.tx` and `resp.ctrl ≤ n.ctrl` (responses cannot exceed totals)
- All four variables are not `NA`

These correspond exactly to the checks performed by `validate_inputs()` in
`scripts/Two_sample_proportion_with_multiple_functions.R`.

---

## Step 2 — Exploratory Data Analysis

Build a 2×2 contingency table and an inline bar plot from the four inputs. Both are
computed here but only displayed to the user starting at Step 5, who chooses 
"detailed" level of response.

**Contingency table**

|           | Response   | No Response         |
|-----------|------------|---------------------|
| Treatment | resp.tx    | n.tx − resp.tx      |
| Control   | resp.ctrl  | n.ctrl − resp.ctrl  |

**Bar plot**

Display the response rates as a side-by-side horizontal bar chart rendered directly in
the chat window using an inline HTML/SVG widget. Show Treatment (`<resp.tx>/<n.tx>`%)
and Control (`<resp.ctrl>/<n.ctrl>`%) as styled bars with percentage labels inside each
bar, a title "RESPONSE RATES", and use a blue bar for Treatment and a gray bar for
Control. Make it visually polished with clean typography and rounded bars. The
percentages should be written in **black**, and each bar's length should scale
proportionally to its response rate (e.g. `length: <percentage>%`) so bar length
visually encodes the rate.

Extract `<resp.tx>/<n.tx>` and `<resp.ctrl>/<n.ctrl>` from the inputs, and round to two
decimal places for display.

---

## Step 3 — Check Assumptions

### Choosing the test (internal — not displayed)

Compute the **expected cell counts** under the null hypothesis using row sums, column
sums, and total participants:

```
E(treatment, response)    = (resp.tx + resp.ctrl) * n.tx / (n.tx + n.ctrl)
E(treatment, no response) = (n.tx - resp.tx + n.ctrl - resp.ctrl) * n.tx / (n.tx + n.ctrl)
E(control, response)      = (resp.tx + resp.ctrl) * n.ctrl / (n.tx + n.ctrl)
E(control, no response)   = (n.tx - resp.tx + n.ctrl - resp.ctrl) * n.ctrl / (n.tx + n.ctrl)
```

**Decision rule** (mirrors `choose_test()` in the R script):
- If **all four expected counts ≥ 5** → use **Chi-square test** (`chisq.test`)
- If **any expected count < 5** → use **Fisher's exact test** (`fisher.test`)

Compute these values internally only. Do **not** display the expected cell counts, the
formulas, or the test decision at this step. The only number ever surfaced to the user
is the single minimum expected cell count, used in one sentence, shown in the paragraph in Step 5.

### Assumptions of the chosen test

See `references/assumptions.md` for the full checklist. In brief:

**Chi-square test**
1. The two groups are independent random samples.
2. Each observation is binary (success or failure).
3. Expected cell counts ≥ 5 in all cells (verified above).
4. Sample size is large enough for the chi-square approximation to be reliable.

**Fisher's exact test**
1. The two groups are independent random samples.
2. Each observation is binary (success or failure).
3. Row and column totals are treated as fixed — no large-sample approximation is made,
   which is why this test is preferred when expected counts are small.

For the statistical reasoning behind why each assumption matters, see
`references/guide.md`.

---

## Step 4 — Execute R Code and Extract Results

### Which script to run

| Test type | Script | Function |
|---|---|---|
| Two-sample proportion test (auto-selects chi-square or Fisher's exact) | `scripts/Two_sample_proportion_with_multiple_functions.R` | `two_sample_proportion_test(n.tx, n.ctrl, resp.tx, resp.ctrl, threshold = 0.05)` |

### Running the script

Run the R script using the Bash tool. This is the authoritative computation step — do
not calculate p-values, test statistics, confidence intervals, or odds ratios yourself.
All numerical results in Step 5 must come directly from the output of this command.

From the skill's directory (the folder containing this `SKILL.md`), run:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/Two_sample_proportion_with_multiple_functions.R')
two_sample_proportion_test(n.tx=<n.tx>, n.ctrl=<n.ctrl>, resp.tx=<resp.tx>, resp.ctrl=<resp.ctrl>)
"
```

Replace `<n.tx>`, `<n.ctrl>`, `<resp.tx>`, `<resp.ctrl>` with the actual numbers, and
`<path-to-skill-directory>` with the actual absolute path to the folder containing this
`SKILL.md`. The `threshold` argument defaults to 0.05; if the user specifies a different
significance level, pass it explicitly (e.g., `threshold = 0.01`).

The function prints its return value to stdout. From that output, extract:
- The test name (Chi-square or Fisher's exact)
- The test statistic value and its label (`test statistic` or `sample odds ratio`)
- The p-value (exact formatted string as printed, e.g. "less than 0.001 (***)" or "0.0312")
- The decision ("reject" or "fail to reject") and conclusion sentence

Use these extracted values verbatim when writing the Step 5 report. Do not recompute or
reword numerical results.

### If the script fails

Surface the R error message verbatim to the user and stop — do not guess at what the
result would have been, and do not silently fall back to a different test. Common
causes worth checking first: a missing R package  — tell the user
which one to install, inputs that don't match Step 1's validation (revisit Step 1), or
a path issue (confirm `<path-to-skill-directory>` is correct).

---


## Step 5 — Output and Response Hierarchy

Output **exactly** the following block — nothing before it, nothing after except 
waiting for the user's reply. Do not show formulas, intermediate tables, or any 
other text. Do not return any output or text until step 5.

> Assuming these numerical inputs are correct (treatment group = `<n.tx>`, 
control group = `<n.ctrl>`, treatment response = `<resp.tx>`, and control 
response = `<resp.ctrl>`), we will proceed with the analysis. Would you like 
a **brief** (test statistic, p-value, and one-line conclusion), **moderate** 
(adds assumption checks and supporting tables), or **detailed** (full background, 
definitions, and step-by-step interpretation) response?

Replace each placeholder with its computed value. `<min_expected>` is a single 
rounded number (no formula, no table). The user can answer both questions at 
once (e.g., "detailed, and yes please export to HTML"). Wait for the user's 
answer before generating any output.

**Note**: Ignore any detail-level preference (brief/moderate/detailed) that 
arrives together with the initial data — always output the Step 5 question and 
wait for a reply in the next turn, even if one was mentioned upfront.

**Tone for all levels:**  Professional but accessible. Write for a stakeholder who 
understands "statistically significant" but does not need to verify the math. Define 
definitions for specific statistical terminologies.

**Note:** Do not show anything with `tx` or `ctrl` notation directly — state the
hypothesis and results using plain words. That notation is for code only.

**Note:** All R code chunks in any exported report must use `echo = FALSE` (set
globally in the setup chunk) so no R code is visible in the rendered output.

---

### Brief
**Excatly one** paragraph covering: test used(chi-square or Fisher's exact test with minimum 
expected cell value). All of the assumptions checked (refer to Step 3 for all assumption details).
Key result (statistic + p-value (4 decimal places if ≥ 0.05, 
otherwise `< 0.05`, `< 0.01`, or `< 0.001` with stars)), and decision (reject / fail 
to reject null hypothesis). Confidence interval of the binary proportion (stored 
as `confint` in the function `two_sample_proportion_test` output).

No table displayed.
---

### Moderate

A single cohesive paragraph covering all four elements in order:

1. **Background** — group sizes, observed responses, response rates, null and alternative hypothesis.
2. **Test chosen and assumptions** — test name, why it was selected (minimum expected counts), key assumptions met.
3. **Test result** — test statistic (X² or odds ratio), degrees of freedom if chi-square, 
p-value (4 decimal places if ≥ 0.05, otherwise `< 0.05`, `< 0.01`, or `< 0.001` with stars), 
and confidence interval.
4. **Decision** — reject or fail to reject null hypothesis, and what that means in plain language.

Then the **summary table** below.

### Summary table (for moderate and detailed levels only, after the paragraph, rendered via knitr::kable()):

| Metric | Treatment | Control |
|---|---|---|
| Total | n.tx | n.ctrl |
| Response rate | resp.tx / n.tx % (`two_sample_proportion_test(n.tx, n.ctrl, resp.tx, resp.ctrl)$ci_tx[, c("Lower","Upper")]*100`) % | resp.ctrl / n.ctrl % (`two_sample_proportion_test(n.tx, n.ctrl, resp.tx, resp.ctrl)$ci_ctrl[, c("Lower","Upper")]*100`) %|
| Risk difference | Δ = \|resp.tx/n.tx − resp.ctrl/n.ctrl\| (`two_sample_proportion_test(n.tx, n.ctrl, resp.tx, resp.ctrl)$ci_rd[, c("Lower","Upper")]*100`) % |

Show this line of sentence underneath the table: **The confidence intervals for response rates are computed using Clopper-Pearson, and the confidence interval for the response rate difference is computed using Newcombe method.**

---

### Detailed

Output in this exact order:

1. **Bar plot** — the inline HTML/SVG widget described in Step 2 (rendered once,
   at the very start of the report — before any text or tables).
2. **Contingency table** — the 2×2 table described in Step 2.
3. **Paragraph** — the full **Moderate** paragraph (background, test chosen and
   assumptions, test result, decision).
4. **Summary table** — the summary table defined below, including the
   Clopper-Pearson/Newcombe sentence underneath it.


**Formatting conventions** (apply consistently so reports don't vary run to run):
- P-values: report as `p = 0.0004` down to 3 significant figures; below that, report as
  `p < .001` rather than more decimal places.
- Test statistics and estimates: 2–3 decimal places unless the input data's precision
  warrants more.
- Significance level: state the alpha used (default 0.05) explicitly in Results, don't
  assume the reader knows it.
  
---

### Notation

Throughout the analysis, use `*` only for p-values. Do not use any other symbol.
- p-value < 0.001 (***)
- p-value < 0.01 (**)
- p-value < 0.05 (*)
- p-value ≥ 0.05: rounded to 4 decimal places, no stars

---

## Examples

The report follows the procedure in Step 5, and should look similar to the examples below.

### Example A — Chi-square (large samples)

Input: n.tx = 2000, n.ctrl = 2000, resp.tx = 340, resp.ctrl = 280

Response level: moderate

> In this experiment, 2,000 subjects were assigned to the treatment group and 2,000 to
> the control group. The treatment group showed 340 successes (17.0% rate) versus 280
> successes (14.0%) in the control group, an absolute difference of 3.0 percentage
> points. All four expected cell counts exceeded 5 (minimum ≈ 293), so the chi-square
> test of equal proportions was applied; we assume that the two groups are independent 
> random samples, each observation is binary (success or failure), expected cell 
> counts ≥ 5 in all cells, thus the sample size is large enough for the chi-square 
> approximation to be reliable. The test yielded X² = 6.87 (df = 1) and a p-value of 0.0088 —
> the probability of observing a 3-point gap or larger by chance alone if there were
> truly no effect. Because p < 0.05, we reject the null hypothesis that the two
> proportions are equal. The treatment is associated with a statistically significant
> increase in the success rate; the evidence supports a real difference rather than
> sampling variation. The 95% confidence interval of binary proportion is (0.0076, 0.0525).

| Metric | Treatment | Control |
|---|---|---|
| Total | 2000 | 2000 |
| Response rate | 17.0 %  (15.38 %, 18.72 %) | 14.0 % (12.51 %, 15.60 %)|
| Risk difference | Δ = 3.0 %  (0.76 % , 5.25 %) |

**The confidence intervals for response rates are computed using Clopper-Pearson, and the confidence interval for the response rate difference is computed using Newcombe method.**



### Example B — Fisher's exact (small samples)

Input: n.tx = 30, n.ctrl = 25, resp.tx = 3, resp.ctrl = 1

Response level: brief

> We use Fisher's exact test (expected count < 5). For Fisher's exact test, 
> we assume that the two groups are independent random samples, each observation 
> is binary (success or failure), and row and column totals are treated as fixed — no
> large-sample approximation is made, which is why this test is preferred  when expected
> counts are small. Fisher's exact test returned a sample odds ratio of 2.67, a 
> p-value of 0.6174. Because p > 0.05, we fail to reject the null hypothesis that 
> the two proportions are equal. There is insufficient statistical evidence to 
> conclude the treatment had a real effect. The 95% confidence interval of binary
> proportion is (-11.05 % , 22.55 %)


### Example C - Chi-square (large samples)

Input: n.tx = 3009, n.ctrl = 1506, resp.tx = 107, resp.ctrl = 500

Response level: moderate

> In this experiment, 3009 subjects were assigned to the treatment group and 107 to
> the control group. The treatment group showed 107 successes (3.56% rate) versus 500
> successes (33.20%) in the control group, an absolute difference of 29.64 percentage
> points. All four expected cell counts under the null hypothesis exceeded 5 (the smallest 
> was approximately 202), so a chi-square test of independence was used rather than 
> Fisher's exact test. For Chi-square test, we assume that the two groups are 
> independent random samples, each observation is binary (success or failure), 
> expected cell counts ≥ 5 in all cells, thus the sample size is large enough for 
> the chi-square approximation to be reliable. The test statistic is 757.97 (1 degree of freedom) 
> and the p-value is less than 0.001 (***). Because this is far below the 0.05 
> significance threshold, we reject the null hypothesis: there is strong statistical 
> evidence that response is associated with treatment assignment, i.e., the two 
> groups do not have equal response rates. The 95% confidence interval for binary
> proportion is (-32.15 %, -27.21%)

| Metric | Treatment | Control |
|---|---|---|
| Total | 3009 | 1506 |
| Response rate | 3.56 % (2.92 %, 4.28 %) | 33.2 % (30.82 %, 35.64 %)|
| Risk difference | Δ = -29.64 % ( -32.15 %, -27.21 %) |

**The confidence intervals for response rates are computed using Clopper-Pearson, and the confidence interval for the response rate difference is computed using Newcombe method.**


---

# Validation steps: this step is only for developer, not for SKILL user
**Should be hidden unless explicitly mentioned.**
This step is only disclosed when developer explicitly asks for testing the validity
of the SKILL. This is different from Step 1 Validate Inputs. It is used only for checking
the validity of the entire SKILL.md file. Do not mention anything related to this 
step for regular SKILL user.

Refer to `references/validation.md` for the full list of test cases. Two requirements
that apply on top of what that file says:


- **Note:** ignore the three response hierarchies for validation. Only check if the key 
  numerical values from expectation and actual computation matches. 
- **Speed:** run all 20 example inputs through a single batched `Rscript` call (see
  "Running the examples efficiently" in `references/validation.md`) rather than invoking
  the full conversational Steps 0–5 20 separate times. Only fall back to a full
  conversational run for a specific example if the batched script-level check disagrees
  with the expected outcome for that example.
- **Output:** report the correctness rate as a percentage, followed by a 4-column
  markdown table (`Test | Outcome Expected | Outcome Generated | Match`) with one row
  per example.


