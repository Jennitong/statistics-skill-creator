---
name: poisson-regression
description: >
  Runs Poisson regression end to end: validates inputs, checks assumptions
  (Poisson response, independence, mean=variance, linearity in the log rate),
  fits the authoritative R model (standard Poisson, or quasi-Poisson/negative
  binomial when overdispersion is detected), and writes a stakeholder-ready
  report with rate ratios. Trigger this whenever the user asks to model,
  predict, or explain a count outcome, mentions "Poisson regression",
  "count data model", "rate ratio", "log-linear model for counts",
  "overdispersion", "count outcome", or describes a dataset and question that
  maps to this procedure even if they don't name the test explicitly. Also
  trigger on the skill's own name, poisson-regression.
---

# Poisson Regression

## Non-negotiable rules

- Always check for overdispersion (the dispersion statistic phi_hat from
  `scripts/diagnostic.R`) before finalizing results. If phi_hat indicates
  overdispersion, do not report standard-Poisson standard errors as reliable — switch
  to quasi-Poisson or negative binomial instead.
- Always report rate ratios (exp(coefficient)) together with their confidence
  intervals alongside the raw log-rate coefficients — never report one without the
  other.
- Use two-sided tests and alpha = 0.05 by default, unless the user states otherwise;
  always state the alpha used in Results.
- If the response looks like a rate observed over varying exposure (time, area,
  population size, etc.) rather than a plain count, flag that an offset/exposure
  variable should be used, and ask the user to confirm one if it wasn't already
  provided.

## Inputs

- `dat`: a data frame (or file path, e.g. `data/spam_detection_dataset.csv`)
  containing the response and predictor variables.
- `y`: name of the count response variable in `dat` (must be non-negative integers).
- `x`: character vector of predictor variable names in `dat` (continuous and/or
  categorical). Interaction terms may be included using `"x1:x2"` notation.
- `offset`: (optional) name of an exposure/offset variable in `dat` (must be strictly
  positive numeric, e.g. population, area, or time at risk) — used as
  `offset(log(offset))` when the response is really a rate rather than a raw count.
- `alpha`: significance level, default `0.05`.
- `newdata`: (optional) a data frame of predictor values (and offset value, if used)
  to produce predicted counts/rates for, if the client asks for predictions.

---

## Step 0 — Gather References, then Extract Inputs

**Before asking anything else**, ask the client this **single** question (do not stack
it with other questions — it is the sole first question, not "question 1 of N"):

> Are there any publicly available references (papers, textbooks, methodology guides, websites, PDFs,
> etc.) I should rely on for the methods, assumptions, code, or interpretation in this
> analysis?

- If the client names a source that is publicly available, use its actual content to
  inform the assumptions, methods, code, and results for this run, and record it as an
  entry in `references/paper.md` (see that file's format) so Step 5 can cite it.
- If the client names a source that is **not** publicly available (paywalled, internal,
  a login-gated system, etc.), respond with exactly this wording:
  > The resource(s) provided is not public available and Claude does not have access.
  > You could manually provide relevant contents later, or rely on Claude's suggestions.

  Then continue with the remaining steps using this skill's built-in methodology
  (Roback & Legler, 2021, Ch. 4 — see `references/paper.md`) — do not block on this.
- If the client has no references to offer, proceed using this skill's built-in
  methodology (Roback & Legler, 2021, Ch. 4).

This is a **per-run** question: ask it every time this skill is asked to produce a
result, not only the first time. Whatever references are confirmed usable this run
carry through to Step 5's References section — don't ask about references a second
time there.

### Extract Inputs

If the client provides sentences that describe the data and question instead of the
`dat`/`y`/`x`/`offset`/`alpha` arguments directly, extract and store them:
- The dataset or file the user is referring to as `dat`.
- The count outcome they want to explain/predict as `y`.
- The variable(s) they want to use to explain it as `x`.
- Any exposure/time/population variable as `offset` (ask if the response looks like a
  rate but no offset was mentioned — see the non-negotiable rule above).
- Any stated significance level as `alpha` (otherwise use the 0.05 default).
- Any specific predictor values they want predictions for, as `newdata`.

---

## Step 1 — Validate Inputs

Before running any tasks, check all of the following rules. If any check fails,
report the issue clearly and stop.

- `dat` must be a data frame with at least 2 rows.
- `y` must exist in `dat`, be numeric, non-negative, and integer-valued (a proportion,
  rate, or continuous variable is not valid here).
- Every base variable referenced in `x` (including each side of an interaction term)
  must exist in `dat`.
- If `offset` is given, it must exist in `dat`, be numeric, and strictly positive.
- `alpha` must be strictly between 0 and 1.
- Rows with a missing value in `y`, `x`, or `offset` are dropped (listwise deletion);
  report how many rows were dropped and the resulting sample size.
- After cleaning, fewer than 10 complete observations stops the run outright; fewer
  than 10 observations per model parameter (10 x (number of predictors + 1)) is
  allowed but triggers a small-sample warning that must be surfaced in the report.

---

## Step 2 — Explorative Data Analysis

Create any plots, tables or numerical summarization in this section. Show the plots
inline for the client to view. The actual plots should be shown inline for the client
to review, not just descriptions. Plots should show inline in the Claude window.
Refer to `references/eda.md` for the full procedure. For the exact code to generate the
table and plots, refer to `scripts/eda_code.R`.
After the table and all plots are shown, ask the client using the exact words
**All of the preliminary plots are displayed. Continue to assumption checks?**

## Step 3 — Check Assumptions

Before showing results, briefly verify the assumptions of the chosen test.

Implicit assumptions
- Poisson response: the response is a count per unit of time/space, plausibly
  Poisson-distributed.
- Independence: all observations are independent of one another.

Explicit assumptions
- Mean = Variance: the group mean and group variance of the response should match;
  checked numerically via the dispersion statistic phi_hat.
- Linearity in the log rate: log(mean rate) must be a linear function of each
  continuous predictor.

Full details are in `references/assumptions.md`. For the statistical reasoning behind
why each assumption matters and how to interpret a violation, see `references/guide.md`;
for citable methodology backing the chosen test, see `references/paper.md`.
For the formal numeric assumption check (dispersion, goodness-of-fit), refer to
`scripts/diagnostic.R`.

All of the assumptions should be checked and verified by the user before any actual
output in Step 5. Whenever an assumption is verified — numerically (e.g. the dispersion
statistic) or visually (e.g. the mean/variance or log-linearity plots) — ask the client
whether they want to review and decide on that assumption's verdict themselves, or
would rather leave the decision to the AI's judgment; proceed according to their
answer, and default to deciding it yourself if they decline to choose.

Explicitly ask:
> "Would you like to review and decide on each assumption by yourself, or should AI Agent do this for you?"

Do not skip this question — ask this question before EDA and assumption checks so
the user could choose and AI knows what format of assumption checks should be provided.
- If the client wants to decide by themselves, check and show assumptions one by one,
  comment on each numerical value or plot used for assumption checks, interpret and warn
  anything unusual, then ask for the client's opinion of whether the assumption
  seems to hold for **each** assumption. Proceed to the next assumption only
  when the previous assumption is verified and agreed by the client. Otherwise,
  provide some suggestions such as transformation that could make the assumption hold
  (refer to `references/guide.md`).
- If the client wants to let AI Agent decide, then show all assumptions each time,
  interpret what is observed and what that means, and the final decisions about whether
  the assumptions hold. All assumptions could show up at once. If assumptions do not
  hold, suggest solutions (refer to `references/guide.md`), otherwise just tell the
  client that all of the assumptions hold.

The mean=variance check (via `scripts/diagnostic.R`'s phi_hat) determines which script
to run in Step 4 — see the routing table there.

## Step 4 — Execute R Code and Extract Results

### Which script to run

First run `scripts/diagnostic.R`'s `check_poisson_dispersion()` to get phi_hat, then
match to the script below:

| Test type | When to use | Script | Function |
|---|---|---|---|
| Standard Poisson | phi_hat not appreciably > 1 (no overdispersion; the default) | `scripts/task_code1.R` | `main_function1(dat, y, x, offset, alpha, newdata, plot_dir)` |
| Quasi-Poisson | phi_hat > ~1.5 (overdispersion); same coefficients as standard Poisson, inflated SEs | `scripts/task_code2.R` | `main_function2(dat, y, x, offset, alpha, newdata, plot_dir)` |
| Negative binomial | phi_hat > ~1.5 (overdispersion); alternative to quasi-Poisson with an explicit likelihood/AIC | `scripts/task_code3.R` | `main_function3(dat, y, x, offset, alpha, newdata, plot_dir)` |

If overdispersion is detected, run **both** quasi-Poisson and negative binomial and
present both to the client (per `references/guide.md`), rather than silently picking
one — they usually agree in direction/significance but the client may have a reason to
prefer one (e.g. wanting an AIC, which only negative binomial provides).

### Running the script

Run the R script using the Bash tool. This is the authoritative computation
step — AI should not calculate any numerical outputs by itself. All numerical results
must come directly from the output of this command.

From the skill's directory (the folder containing this `SKILL.md`), run:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/diagnostic.R')
dat <- read.csv('<dat_path>')
check_poisson_dispersion(dat, '<y_extracted>', c(<x_extracted>), offset=<offset_extracted_or_NULL>)

source('scripts/task_code1.R')
main_function1(dat, y='<y_extracted>', x=c(<x_extracted>), offset=<offset_extracted_or_NULL>,
               alpha=<alpha_extracted>, newdata=<newdata_extracted_or_NULL>, plot_dir='<plot_dir>')
"
```

Replace `<dat_path>`, `<y_extracted>`, `<x_extracted>`, `<offset_extracted_or_NULL>`,
`<alpha_extracted>`, `<newdata_extracted_or_NULL>` with the inputs extracted earlier
(pass R `NULL` when offset/newdata were not given), and `<plot_dir>` with a writable
directory for the generated PNGs (reuse the same directory used for the EDA plots in
Step 2). Replace `<path-to-skill-directory>` with the actual absolute path to the
folder containing this `SKILL.md`. If routing to quasi-Poisson/negative binomial
instead, source `scripts/task_code2.R`/`scripts/task_code3.R` and call
`main_function2`/`main_function3` with the same arguments in place of/in addition to
`main_function1`.

The function prints a full conclusion paragraph to stdout, and saves a rate-ratio
table PNG in `plot_dir`. From that output, extract:
- The model name (standard Poisson / quasi-Poisson / negative binomial) and formula
- The dispersion statistic and whether overdispersion was flagged
- For each predictor: the log-rate coefficient, rate ratio, confidence interval,
  p-value, and decision
- The overall drop-in-deviance (or F-) test result
- Null/residual deviance, degrees of freedom, and AIC (if applicable)
- The file path of the saved rate-ratio table
- Predicted counts/rates, if `newdata` was supplied

Use these extracted values verbatim when writing the Step 5 report. Do not recompute
or reword numerical results.

### If the script fails

Surface the R error message verbatim to the user and stop — do not guess at what the
result would have been, and do not silently fall back to a different test. Common causes
worth checking first: a missing R package (tell the user which one to install — this
skill needs `gtsummary`, `flextable`, and `MASS`), inputs that don't match the function's
expected shape (revisit Step 1), or a path issue (confirm `<path-to-skill-directory>`
and `<plot_dir>` are correct).

## Step 5 — Output

Before presenting any outputs, ask the client which of the following the report should
contain, if the client has not already stated it in the request:

  1. Fitted model with rate-ratio interpretation (log-rate coefficients, rate ratios,
     confidence intervals, per-predictor decisions).
  2. Hypothesis testing of whether the predictor(s) are associated with the count
     outcome (per-predictor Wald test and/or the overall drop-in-deviance/F-test
     against the intercept-only model).
  3. Predicted counts/rates at specified predictor values (requires `newdata`; ask for
     the predictor values if not already given).

This is a **per-run** question — ask it every time this skill is asked to produce a
report, not only the first time. Different users of this same skill may want different
things from the same procedure; never default to one result type silently. The client
may select more than one.

References are not asked about again here — Step 0 already asked. Always include the
References section below: list the built-in Roback & Legler (2021) citation from
`references/paper.md` (this skill's methods are based on it), followed by any additional
references the client supplied in Step 0 this run (including ones Claude could not
access), in APA 7th edition format.

**Tone for all levels:** Professional but accessible. Write for a stakeholder who
understands "statistically significant" but does not need to verify the math. Define
definitions for specific statistical terminology.

If we have any figures and tables that we want for the output, we should include it in
Step 5, under Results.

```markdown
# [Analysis title]

## Background
[Why this analysis was run, what question it answers]

## Data & Assumptions
[Input summary + which assumptions were checked and whether they held]

## Results
[Model used, dispersion statistic, coefficients/rate ratios, hypothesis tests, and/or
predicted values — taken verbatim from Step 4's output, matching the result type(s)
the client asked for]

**optional** tables and figures:
The rate-ratio table (`rr_table_poisson.png` / `rr_table_quasipoisson.png` /
`rr_table_negbin.png`, depending on which model was run) from Step 4, and any EDA plots relevant to the
requested result type, shown inline via the Read tool.

## Conclusion
[Plain-language answer to the original question]

## References
Roback, P., & Legler, J. (2021). Beyond multiple linear regression: Applied
generalized linear models and multilevel models in R (Chapter 4: Poisson Regression).
CRC Press. https://bookdown.org/roback/bookdown-BeyondMLR/ch-poissonreg.html
[+ any additional references the client supplied in Step 0 this run]
```

**Formatting conventions** (apply consistently so reports don't vary run to run):
- P-values: report and keep 4 decimal places for p > 0.05; for 0.01 <= p < 0.05, report
  as `p < 0.05 (*)`; for 0.001 <= p < 0.01, report as `p < 0.01 (**)`; for p < 0.001,
  report as `p < 0.001 (***)`.
- Log-rate coefficients: 3-4 decimal places. Rate ratios: 3 decimal places, with the CI
  shown as `(lower, upper)`.
- Significance level: state the alpha used (default 0.05) explicitly in Results, don't
  assume the reader knows it.

**Note: All R code chunks must use echo = FALSE (set globally in the setup chunk) so no R code is visible in the rendered report.**

---

## Examples

### Example A — Typical/valid case

Input: `data/spam_detection_dataset.csv`, `y = "num_links"`,
`x = c("num_words","has_offer","sender_score","all_caps")`, no offset, `alpha = 0.05`.

> In this project, we modeled the number of links in an email (`num_links`, n = 20,000)
> using message length (`num_words`), whether it contained an offer (`has_offer`),
> sender reputation score (`sender_score`), and whether it used all-caps text
> (`all_caps`). The mean=variance check found no overdispersion (phi_hat = 0.995), so a
> standard Poisson model was used. None of the four predictors were significantly
> associated with the number of links at alpha = 0.05 (all p > 0.59; rate ratios all
> approximately 1.00), and the overall drop-in-deviance test against the intercept-only
> model was not significant (p = 0.957) — in this dataset, `num_links` behaves
> essentially like noise with respect to these four predictors.

### Example B — Edge case (small sample)

Input: a random 15-row subsample of `data/spam_detection_dataset.csv`
(`set.seed(1); dat[sample(nrow(dat), 15), ]`), `y = "num_links"`, `x = c("has_offer")`.

> With only 15 observations for 2 model parameters, the skill flags a small-sample
> warning per Step 1. `has_offer` is not significantly associated with `num_links`
> (rate ratio = 1.179, 95% CI: 0.453-3.067, p = 0.736) — we fail to reject H0, but the
> very wide confidence interval reflects the small sample size and should not be
> over-interpreted.

### Example C — Deliberately invalid input

Input: `data/spam_detection_dataset.csv`, `y = "sender_score"` (a continuous 0-1
proportion, not a count), `x = c("num_words")`.

> `sender_score` takes non-integer values (e.g. 0.7186), so Step 1 rejects the input
> immediately with "Response 'sender_score' must be integer counts; found non-integer
> value(s)..." — no model is fit. Poisson regression requires a genuine count response;
> a bounded proportion like this would call for a different method (e.g. beta or
> logistic regression), not this skill.

---

# Validation steps: this step is only for developer, not for SKILL user
Should be hidden unless explicitly mentioned.
This step is only disclosed when developer explicitly asks for testing the validity
of the SKILL. This is different from Step 1 Validate Inputs. It is used only for checking
the validity of the entire SKILL.md file. Do not mention anything related to this
step for regular SKILL user.

Refer to `references/validation.md` for validation steps.

- **Note:** ignore the three response hierarchies for validation. Only check if the key
  numerical values from expectation and actual computation match.
- **Speed:** run all 5 example inputs through a single batched `Rscript` call (see
  "Running the examples efficiently" in `references/validation.md`) rather than invoking
  the full conversational Steps 0-5 5 separate times. Only fall back to a full
  conversational run for a specific example if the batched script-level check disagrees
  with the expected outcome for that example.
- **Output:** report the correctness rate as a percentage, followed by a 4-column
  markdown table (`Test | Outcome Expected | Outcome Generated | Match`) with one row
  per example.
