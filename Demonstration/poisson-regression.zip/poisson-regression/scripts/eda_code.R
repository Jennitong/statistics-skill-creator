## EDA code for Poisson regression
# Inputs: `dat` (data frame), `y` (name of count response variable),
# `x_cont` (character vector of continuous predictor names),
# `x_cat` (character vector of categorical/binary predictor names), `plot_dir`
#
# Produces:
#   summary_table.png            - descriptive table for y and all predictors
#   hist_<y>.png                 - histogram of the count response
#   scatter_<v>_<y>.png          - response vs. each continuous predictor, one per v
#   boxplot_<v>_<y>.png          - response vs. each categorical predictor, one per v
#   meanvar_<v>.png              - group mean vs. group variance of y by each predictor
#                                   (mean=variance assumption check, Roback & Legler ch.4)
#   loglinearity_<v>.png         - log(group mean of y) vs. predictor with a loess smooth
#                                   (linearity-in-log-rate assumption check), continuous only

run_eda <- function(dat, y, x_cont = character(0), x_cat = character(0), plot_dir = ".") {
  if (!dir.exists(plot_dir)) dir.create(plot_dir, recursive = TRUE)

  ## Summary statistics table
  cols <- c(y, x_cont, x_cat)
  tbl <- gtsummary::tbl_summary(dat[, cols, drop = FALSE], missing = "no")
  gt_flex <- gtsummary::as_flex_table(tbl)
  flextable::save_as_image(gt_flex, path = file.path(plot_dir, "summary_table.png"))

  ## Histogram of the count response
  hist_path <- file.path(plot_dir, sprintf("hist_%s.png", y))
  grDevices::png(hist_path)
  graphics::hist(dat[[y]], breaks = seq(min(dat[[y]]) - 0.5, max(dat[[y]]) + 0.5, by = 1),
                 xlab = y, main = sprintf("Distribution of %s", y), col = "steelblue")
  grDevices::dev.off()

  ## Continuous predictors: scatterplot of response vs predictor
  for (v in x_cont) {
    fp <- file.path(plot_dir, sprintf("scatter_%s_%s.png", v, y))
    grDevices::png(fp)
    graphics::plot(dat[[v]], dat[[y]], xlab = v, ylab = y,
                    main = sprintf("%s by %s", y, v), pch = 16,
                    col = grDevices::adjustcolor("steelblue", alpha.f = 0.3))
    grDevices::dev.off()
  }

  ## Categorical predictors: boxplot of response by group
  for (v in x_cat) {
    fp <- file.path(plot_dir, sprintf("boxplot_%s_%s.png", v, y))
    grDevices::png(fp)
    graphics::boxplot(dat[[y]] ~ dat[[v]], xlab = v, ylab = y,
                       main = sprintf("%s by %s", y, v))
    grDevices::dev.off()
  }

  ## Mean = Variance assumption check: for every predictor (binned into quartile
  ## groups if continuous), compare group mean and group variance of y.
  meanvar_tables <- list()
  for (v in c(x_cont, x_cat)) {
    grp <- if (v %in% x_cont) {
      cut(dat[[v]], breaks = unique(stats::quantile(dat[[v]], probs = seq(0, 1, 0.25), na.rm = TRUE)),
          include.lowest = TRUE)
    } else {
      factor(dat[[v]])
    }
    m <- tapply(dat[[y]], grp, mean, na.rm = TRUE)
    va <- tapply(dat[[y]], grp, stats::var, na.rm = TRUE)
    n <- tapply(dat[[y]], grp, length)
    tab <- data.frame(group = names(m), n = as.integer(n), mean = round(m, 3), variance = round(va, 3))
    meanvar_tables[[v]] <- tab

    fp <- file.path(plot_dir, sprintf("meanvar_%s.png", v))
    grDevices::png(fp)
    ylim <- range(c(tab$mean, tab$variance), na.rm = TRUE)
    graphics::plot(seq_len(nrow(tab)), tab$mean, type = "b", pch = 16, col = "steelblue",
                    ylim = ylim, xaxt = "n", xlab = v, ylab = y,
                    main = sprintf("Group mean vs. variance of %s by %s", y, v))
    graphics::lines(seq_len(nrow(tab)), tab$variance, type = "b", pch = 17, col = "firebrick")
    graphics::axis(1, at = seq_len(nrow(tab)), labels = tab$group, cex.axis = 0.7)
    graphics::legend("topright", legend = c("mean", "variance"), col = c("steelblue", "firebrick"),
                      pch = c(16, 17), bty = "n")
    grDevices::dev.off()
  }

  ## Linearity-in-log-rate check (continuous predictors only): log(group mean of y)
  ## vs. predictor value, with a loess smoother.
  for (v in x_cont) {
    grp <- cut(dat[[v]], breaks = unique(stats::quantile(dat[[v]], probs = seq(0, 1, 0.1), na.rm = TRUE)),
               include.lowest = TRUE)
    mid_x <- tapply(dat[[v]], grp, mean, na.rm = TRUE)
    log_mean_y <- log(tapply(dat[[y]], grp, mean, na.rm = TRUE))
    keep <- is.finite(log_mean_y)

    fp <- file.path(plot_dir, sprintf("loglinearity_%s.png", v))
    grDevices::png(fp)
    graphics::plot(mid_x[keep], log_mean_y[keep], xlab = v, ylab = sprintf("log(mean %s)", y),
                    main = sprintf("Linearity check: log(mean %s) vs. %s", y, v), pch = 16)
    if (sum(keep) >= 4) {
      lo <- stats::loess(log_mean_y[keep] ~ mid_x[keep])
      ord <- order(mid_x[keep])
      graphics::lines(mid_x[keep][ord], stats::predict(lo)[ord], col = "firebrick", lwd = 2)
    }
    grDevices::dev.off()
  }

  invisible(list(plot_dir = plot_dir, meanvar_tables = meanvar_tables))
}
