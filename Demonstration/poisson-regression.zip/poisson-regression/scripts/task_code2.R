# task_code2
#
# Task for this R file: quasi-Poisson regression (glm(family = quasipoisson), log link).
# Use when scripts/diagnostic.R found overdispersion (phi_hat appreciably > 1): this
# keeps the same coefficient estimates as standard Poisson but inflates standard
# errors by sqrt(phi_hat), per Roback & Legler (2021) ch. 4.
#
# main_function2():
#   1. validates its arguments (mirrors the checks in SKILL.md Step 1)
#   2. fits the quasi-Poisson model and reports the estimated dispersion
#   3. computes rate ratios + 95% CIs, per-term t-tests (quasi-likelihood uses a
#      t-distribution, not z, per the reference), and an overall F-test against the
#      intercept-only model
#   4. saves a rate-ratio table PNG, and (if `newdata` is supplied) predicted counts
#   5. prints a full conclusion paragraph to stdout, so Step 4 can extract it verbatim
#
# Note: AIC is not reported for quasi-Poisson models (quasi-likelihood has no proper
# likelihood, so AIC is undefined) — this mirrors the source chapter.
#
# NOTE: every helper below is suffixed `_pois2` because scripts/task_code1.R and
# scripts/task_code3.R define same-shaped helpers with different bodies (different
# glm family, different report text) — SKILL.md's Step 4 can source more than one of
# these task_codeN.R files in the same Rscript call (e.g. to run quasi-Poisson and
# negative binomial side by side), and unsuffixed same-named functions would silently
# overwrite each other in that shared R session.

x_base_names_pois2 <- function(x) unique(unlist(strsplit(x, ":")))

validate_inputs_pois2 <- function(dat, y, x, offset = NULL, alpha = 0.05) {
  if (!is.data.frame(dat)) stop("`dat` must be a data frame.")
  if (nrow(dat) < 2) stop("`dat` must have at least 2 rows.")
  if (!(y %in% names(dat))) stop(sprintf("Response variable '%s' not found in `dat`.", y))

  base_x <- x_base_names_pois2(x)
  missing_x <- setdiff(base_x, names(dat))
  if (length(missing_x) > 0) {
    stop(sprintf("Predictor(s) not found in `dat`: %s", paste(missing_x, collapse = ", ")))
  }
  if (!is.null(offset) && !(offset %in% names(dat))) {
    stop(sprintf("Offset variable '%s' not found in `dat`.", offset))
  }
  if (!is.numeric(alpha) || length(alpha) != 1 || alpha <= 0 || alpha >= 1) {
    stop("`alpha` must be a single number strictly between 0 and 1.")
  }

  yvec <- dat[[y]]
  if (!is.numeric(yvec)) stop(sprintf("Response '%s' must be numeric (a count).", y))
  yvec_nonmiss <- yvec[!is.na(yvec)]
  if (any(yvec_nonmiss < 0)) {
    stop(sprintf("Response '%s' must be non-negative counts; found negative value(s).", y))
  }
  if (any(abs(yvec_nonmiss - round(yvec_nonmiss)) > 1e-8)) {
    stop(sprintf(
      "Response '%s' must be integer counts; found non-integer value(s) (e.g. a proportion or rate is not valid here).",
      y
    ))
  }

  if (!is.null(offset)) {
    ov <- dat[[offset]]
    if (!is.numeric(ov)) stop(sprintf("Offset '%s' must be numeric.", offset))
    if (any(ov[!is.na(ov)] <= 0)) {
      stop(sprintf("Offset '%s' must be strictly positive (log(offset) is used).", offset))
    }
  }

  vars_used <- unique(c(y, base_x, offset))
  n_before <- nrow(dat)
  dat_clean <- dat[stats::complete.cases(dat[, vars_used, drop = FALSE]), , drop = FALSE]
  n_dropped <- n_before - nrow(dat_clean)
  if (n_dropped > 0) {
    message(sprintf(
      "Dropped %d row(s) with missing values in %s (listwise deletion). %d rows remain.",
      n_dropped, paste(vars_used, collapse = ", "), nrow(dat_clean)
    ))
  }

  n_params <- length(base_x) + 1
  if (nrow(dat_clean) < 10) {
    stop("Fewer than 10 complete observations remain after removing missing data; cannot fit a reliable model.")
  }
  if (nrow(dat_clean) < 10 * n_params) {
    message(sprintf(
      "WARNING: only %d complete observations for %d model parameters (rule of thumb: >= %d recommended). Estimates and CIs may be unstable.",
      nrow(dat_clean), n_params, 10 * n_params
    ))
  }

  dat_clean
}

build_formula_pois2 <- function(y, x, offset = NULL) {
  f <- sprintf("%s ~ %s", y, paste(x, collapse = " + "))
  if (!is.null(offset)) f <- sprintf("%s + offset(log(%s))", f, offset)
  f
}

check_assumptions_pois2 <- function(dat, y, x, offset = NULL) {
  fit <- stats::glm(stats::as.formula(build_formula_pois2(y, x, offset)), data = dat, family = stats::poisson())
  phi_hat <- sum(stats::residuals(fit, type = "pearson")^2) / fit$df.residual
  list(phi_hat_poisson = phi_hat)
}

run_test_pois2 <- function(dat, y, x, offset = NULL, alpha = 0.05) {
  formula_str <- build_formula_pois2(y, x, offset)
  fit <- stats::glm(stats::as.formula(formula_str), data = dat, family = stats::quasipoisson())
  null_fit <- stats::update(fit, . ~ 1)

  s <- summary(fit)
  co <- s$coefficients
  ci <- stats::confint.default(fit, level = 1 - alpha)
  rr <- exp(co[, "Estimate"])
  rr_ci <- exp(ci)

  ft <- stats::anova(null_fit, fit, test = "F")

  list(
    fit = fit, formula = formula_str, n = nrow(dat), coef_table = co,
    rr = rr, rr_ci = rr_ci, alpha = alpha, dispersion = s$dispersion,
    null_deviance = stats::deviance(null_fit), resid_deviance = stats::deviance(fit),
    df_resid = fit$df.residual,
    overall_f = ft[2, "F"], overall_df1 = ft[2, "Df"], overall_df2 = fit$df.residual, overall_p = ft[2, "Pr(>F)"]
  )
}

make_rr_table_pois2 <- function(fit, alpha, table_path) {
  tbl <- suppressWarnings(gtsummary::tbl_regression(fit, exponentiate = TRUE, conf.level = 1 - alpha))
  gt_flex <- gtsummary::as_flex_table(tbl)
  flextable::save_as_image(gt_flex, path = table_path)
  invisible(table_path)
}

predict_counts_pois2 <- function(fit, newdata, alpha = 0.05) {
  pr <- stats::predict(fit, newdata = newdata, type = "link", se.fit = TRUE)
  z <- stats::qnorm(1 - alpha / 2)
  data.frame(
    newdata,
    predicted_count = exp(pr$fit),
    lower = exp(pr$fit - z * pr$se.fit),
    upper = exp(pr$fit + z * pr$se.fit)
  )
}

report_conclusion_pois2 <- function(result, assump, rr_table_path, pred_df = NULL) {
  co <- result$coef_table
  terms <- rownames(co)[rownames(co) != "(Intercept)"]
  p_col <- if ("Pr(>|t|)" %in% colnames(co)) "Pr(>|t|)" else "Pr(>|z|)"

  lines <- c(sprintf("Quasi-Poisson regression (glm, log link): %s, n = %d.", result$formula, result$n))
  lines <- c(lines, sprintf(
    "Overdispersion motivating this model: initial standard-Poisson phi_hat = %.4f. Estimated quasi-Poisson dispersion = %.4f (standard errors inflated by sqrt(dispersion) relative to standard Poisson).",
    assump$phi_hat_poisson, result$dispersion
  ))

  for (term in terms) {
    est <- co[term, "Estimate"]
    p <- co[term, p_col]
    r <- result$rr[term]
    lo <- result$rr_ci[term, 1]
    hi <- result$rr_ci[term, 2]
    decision <- if (p < result$alpha) "reject H0 (statistically significant)" else "fail to reject H0 (not statistically significant)"
    p_str <- if (p < 0.001) "< .001" else sprintf("%.3g", p)
    lines <- c(lines, sprintf(
      "For %s: log-rate coefficient = %.4f, rate ratio = %.3f (%.0f%% CI: %.3f-%.3f), p = %s -> %s at alpha = %.2f.",
      term, est, r, 100 * (1 - result$alpha), lo, hi, p_str, decision, result$alpha
    ))
  }

  overall_p_str <- if (result$overall_p < 0.001) "< .001" else sprintf("%.3g", result$overall_p)
  lines <- c(lines, sprintf(
    "Overall F-test vs. intercept-only model: F(%d, %d) = %.3f, p = %s.",
    result$overall_df1, result$overall_df2, result$overall_f, overall_p_str
  ))
  lines <- c(lines, sprintf(
    "Null deviance = %.2f, residual deviance = %.2f (df = %d). AIC is not reported for quasi-Poisson models (no proper likelihood).",
    result$null_deviance, result$resid_deviance, result$df_resid
  ))
  lines <- c(lines, sprintf("Rate-ratio table saved to: %s", rr_table_path))

  if (!is.null(pred_df)) {
    lines <- c(lines, "Predicted counts for requested newdata rows:")
    for (i in seq_len(nrow(pred_df))) {
      lines <- c(lines, sprintf(
        "  row %d: predicted count = %.3f (%.0f%% CI: %.3f-%.3f)",
        i, pred_df$predicted_count[i], 100 * (1 - result$alpha), pred_df$lower[i], pred_df$upper[i]
      ))
    }
  }

  cat(paste(lines, collapse = "\n"), "\n")
  invisible(paste(lines, collapse = "\n"))
}

main_function2 <- function(dat, y, x, offset = NULL, alpha = 0.05, newdata = NULL, plot_dir = ".") {
  if (!dir.exists(plot_dir)) dir.create(plot_dir, recursive = TRUE)

  dat_clean <- validate_inputs_pois2(dat, y, x, offset, alpha)
  assump <- check_assumptions_pois2(dat_clean, y, x, offset)
  result <- run_test_pois2(dat_clean, y, x, offset, alpha)

  rr_table_path <- file.path(plot_dir, "rr_table_quasipoisson.png")
  make_rr_table_pois2(result$fit, alpha, rr_table_path)

  pred_df <- if (!is.null(newdata)) predict_counts_pois2(result$fit, newdata, alpha) else NULL

  report_conclusion_pois2(result, assump, rr_table_path, pred_df)
}
