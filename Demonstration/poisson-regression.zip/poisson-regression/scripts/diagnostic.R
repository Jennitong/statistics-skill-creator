## Diagnostic: formal checks for the Poisson-regression assumptions
#
# Fits an initial glm(family = poisson) and reports:
#   - the dispersion statistic phi_hat = sum(Pearson resid^2) / residual df
#     (Roback & Legler 2021, ch. 4: "should be close to one" under no overdispersion,
#     "larger than one in the presence of overdispersion")
#   - a Pearson chi-square goodness-of-fit p-value
#   - a residual-deviance goodness-of-fit p-value
#   - a routing recommendation: standard Poisson / quasi-Poisson / negative binomial
#
# This is the numeric assumption check referenced by SKILL.md Step 3 and
# references/assumptions.md. It does not fit the final reported model — that
# happens in scripts/task_code1.R / task_code2.R / task_code3.R depending on
# which family this diagnostic recommends.

check_poisson_dispersion <- function(dat, y, x, offset = NULL, overdispersion_threshold = 1.5) {
  base_x <- unique(unlist(strsplit(x, ":")))
  vars_used <- unique(c(y, base_x, offset))
  missing_v <- setdiff(vars_used, names(dat))
  if (length(missing_v) > 0) {
    stop(sprintf("Variable(s) not found in data: %s", paste(missing_v, collapse = ", ")))
  }

  dat_clean <- dat[stats::complete.cases(dat[, vars_used, drop = FALSE]), , drop = FALSE]

  formula_str <- sprintf("%s ~ %s", y, paste(x, collapse = " + "))
  if (!is.null(offset)) {
    formula_str <- sprintf("%s + offset(log(%s))", formula_str, offset)
  }

  fit <- stats::glm(stats::as.formula(formula_str), data = dat_clean, family = stats::poisson())

  pearson_resid <- stats::residuals(fit, type = "pearson")
  df_resid <- fit$df.residual
  pearson_x2 <- sum(pearson_resid^2)
  phi_hat <- pearson_x2 / df_resid

  pearson_gof_p <- stats::pchisq(pearson_x2, df = df_resid, lower.tail = FALSE)
  deviance_gof_p <- stats::pchisq(stats::deviance(fit), df = df_resid, lower.tail = FALSE)

  overdispersed <- phi_hat > overdispersion_threshold
  recommendation <- if (overdispersed) {
    "Overdispersion detected: use quasi-Poisson (scripts/task_code2.R) or negative binomial (scripts/task_code3.R) instead of standard Poisson SEs."
  } else {
    "No evidence of overdispersion: standard Poisson (scripts/task_code1.R) is appropriate."
  }

  out <- list(
    n = nrow(dat_clean),
    formula = formula_str,
    mean_y = mean(dat_clean[[y]]),
    var_y = stats::var(dat_clean[[y]]),
    df_resid = df_resid,
    pearson_x2 = pearson_x2,
    phi_hat = phi_hat,
    pearson_gof_p = pearson_gof_p,
    deviance_gof_p = deviance_gof_p,
    overdispersed = overdispersed,
    recommendation = recommendation
  )

  cat(sprintf(
    paste(
      "Poisson dispersion check for %s (n = %d):",
      "  Mean(%s) = %.4f, Var(%s) = %.4f",
      "  Dispersion phi_hat = %.4f (Pearson X^2 = %.2f, df = %d)",
      "  Pearson GOF p-value = %s, Deviance GOF p-value = %s",
      "  %s",
      sep = "\n"
    ),
    formula_str, out$n, y, out$mean_y, y, out$var_y,
    out$phi_hat, out$pearson_x2, out$df_resid,
    format.pval(out$pearson_gof_p, digits = 4), format.pval(out$deviance_gof_p, digits = 4),
    out$recommendation
  ), "\n")

  invisible(out)
}
