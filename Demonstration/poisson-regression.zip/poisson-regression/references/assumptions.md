# Check Assumptions

This document contains all the necessary assumptions to check for Poisson regression,
per Roback & Legler (2021), ch. 4 (see `references/paper.md`).

**Note**: AI Agent should run all the **exact** R code for assumption checks and
output. AI should not generate the plots or calculate any values using its own method.
For code that verifies each assumption, refer to `scripts/diagnostic.R` (formal checks)
and `scripts/eda_code.R` (the mean/variance table and log-linearity plots, generated
in Step 2).

## All Assumptions

1. Poisson response (Implicit)
2. Independence (Implicit)
3. Mean = Variance (Explicit)
4. Linearity in the log rate (Explicit)

Then step through each assumption one at a time.

### 1. Poisson Response (Implicit)

The response variable must be a count per unit of time or space, plausibly described
by a Poisson distribution (non-negative integers, no natural upper bound). This is
checked visually from the histogram of the response produced in Step 2 (EDA) — a
right-skewed count histogram is consistent with this assumption; a response that is
actually continuous, a proportion, or bounded by a hard maximum (making it more
binomial-like) violates it. If it doesn't hold, this is not a Poisson regression
problem — consider logistic regression (bounded/binary), linear regression
(continuous), or binomial regression (bounded counts) instead.

### 2. Independence (Implicit)

Observations must be independent of one another. This is assessed through knowledge of
the study design and data collection process, not a numerical test — ask the client
how the data were collected (e.g. repeated measurements on the same unit, clustered
sampling) and flag if independence looks doubtful. If it doesn't hold (e.g. repeated
counts per subject, or spatial/temporal clustering), point estimates from standard
Poisson regression stay valid but standard errors are unreliable; a mixed-effects or
clustered/robust-SE extension would be needed (out of scope for this skill — flag it as
a caveat rather than attempting to fix it).

### 3. Mean = Variance (Explicit)

By definition, the mean of a Poisson random variable must equal its variance. This is
checked two ways:
- Descriptively in Step 2 (EDA): compare the group mean and group variance of the
  response within levels of each predictor (binned into quartiles if continuous), shown
  as `meanvar_<predictor>.png`. Variances "greatly higher than the mean counts" signal
  overdispersion.
- Formally in Step 3, via `scripts/diagnostic.R`: the dispersion statistic
  phi_hat = sum(Pearson residuals^2) / residual df from an initial standard-Poisson fit.
  phi_hat close to 1 supports the assumption; phi_hat notably greater than 1
  (this skill uses a rule-of-thumb threshold of 1.5) indicates overdispersion.

If it doesn't hold (overdispersion), do not report standard-Poisson standard errors as
if they were reliable — route to quasi-Poisson (`scripts/task_code2.R`) or negative
binomial (`scripts/task_code3.R`) instead, per the non-negotiable rule in `SKILL.md`.
Underdispersion (phi_hat notably below 1) is rarer; note it if seen, but this skill does
not have a dedicated underdispersion remedy — flag it as a caveat.

### 4. Linearity in the Log Rate (Explicit)

The log of the mean rate, log(lambda), must be a linear function of each continuous
predictor. Checked visually in Step 2 (EDA) via `loglinearity_<predictor>.png`: the
empirical log(group mean of the response) plotted against the predictor (using finer
bins than the mean=variance check), with a loess smoother overlaid. A loess curve that
tracks a straight line supports linearity; a curved or non-monotonic loess pattern
suggests non-linearity.

If it doesn't hold, suggest a transformation of the predictor (e.g. adding a quadratic
term, or a log transform of the predictor itself if it's skewed and strictly positive)
— see `references/guide.md`.

## Note

All the relevant plots for assumptions should show for the client to review. **Do not**
just write interpretations/descriptions; the client should be able to see the plots
themselves. Plots should be inline in the chat window.
