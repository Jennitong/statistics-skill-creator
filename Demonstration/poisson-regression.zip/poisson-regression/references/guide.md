# Guide

This file contains guidelines and conventions the model should follow when running
Poisson regression in this skill — the "why" and "how to interpret" behind the checks
in `assumptions.md`, not the checks themselves. Source: Roback & Legler (2021), ch. 4
(see `references/paper.md`).

## How to interpret assumption failures

- **Overdispersion (mean != variance, phi_hat > 1.5):** standard Poisson standard
  errors are too small, inflating apparent significance. Switch to quasi-Poisson
  (`scripts/task_code2.R`) — same coefficients, SEs inflated by sqrt(dispersion) — or
  negative binomial (`scripts/task_code3.R`) — an explicit likelihood with its own
  dispersion parameter theta (smaller theta = more overdispersion), which also yields
  an AIC for model comparison, unlike quasi-Poisson. State which one was used and why.
- **Non-linearity in the log rate:** suggest a transformation (e.g. adding a quadratic
  term for that predictor, or a log-transform of a skewed strictly-positive predictor)
  and note that the current model's coefficient for that predictor should be interpreted
  cautiously until refit.
- **Independence in doubt:** point estimates are still valid, but reported p-values and
  CIs may be too narrow (if positively correlated) or too wide (if negatively
  correlated). Flag this explicitly rather than silently trusting the reported CI.

## Common pitfalls to avoid

- Don't use the deviance-based goodness-of-fit p-value (`scripts/diagnostic.R`'s
  `deviance_gof_p`) as the primary decision rule for overdispersion when there are
  continuous predictors or many unique covariate patterns — the chi-square
  approximation for this test degrades as the number of distinct covariate patterns
  grows relative to n, and it can show a "significant" lack of fit even when phi_hat is
  close to 1. Treat phi_hat as the primary criterion; report the deviance/Pearson GOF
  p-values as supplementary context, and say so explicitly if they disagree with phi_hat.
- Don't report a raw log-rate coefficient without also exponentiating it to a rate
  ratio — log-rate coefficients are not interpretable on their own to a stakeholder.
- Don't drop observations with unusually large counts without flagging it and
  investigating why (data entry error vs. a genuinely high-count unit) — don't treat
  them as errors by default.
- When an offset/exposure variable is present, always state that coefficients describe
  the *rate* per unit of exposure, not the raw count — conflating the two is a common
  misinterpretation.
- AIC is undefined for quasi-Poisson models; don't report or compare it there. Use
  negative binomial if an AIC-based model comparison is specifically needed.
