# Validation

Checks the validity and correctness of the SKILL. There are 5 examples of inputs and
outcomes expected. The actual output that will be generated using Claude would be
compared with expected outcomes, and if the correctness rate is equal to 100%, the
SKILL is overall valid. Report the exact correctness.

Triggered when developer explicitly asks for the validity of the skill, the accuracy
and correctness of the test result, or anything similar.

## Input

Examples 1-3 use the real data file supplied at creation time:
`data/spam_detection_dataset.csv` (n = 20,000), with response `num_links` and
predictors `num_words`, `has_offer`, `sender_score`, `all_caps`.

Examples 4-5 use synthetic data generated inline within the validation R script (the
real CSV has no overdispersion and no offset variable, so it cannot exercise those two
code paths) — see the exact generating code in each example below.

## Running the examples efficiently

Do **not** invoke the full conversational skill (Steps 0-5) separately for each of the
examples below — that requires 5 separate `Rscript` process starts plus 5 rounds of
prose/plot generation and is unnecessarily slow. Since Step 4 of `SKILL.md` requires
every numerical result to come verbatim from `scripts/task_code1.R` /
`scripts/task_code2.R` / `scripts/task_code3.R` / `scripts/diagnostic.R`, the
numerical/decision path is fully deterministic. To validate it quickly:

1. Write a single `Rscript` file for all examples.
2. Compare each generated result against the expected outcome for that example.
   Exact wording does not need to match.
3. Only fall back to running the full conversational skill end-to-end with necessary
   plots, tables, or paragraphs if this script-level check reveals a discrepancy, to
   determine whether the bug is in the R scripts, in `SKILL.md`'s instructions, or in
   how the assistant is following them.

- Example 1 (Valid, typical case)
Input: `data/spam_detection_dataset.csv`, `y = "num_links"`,
`x = c("num_words","has_offer","sender_score","all_caps")`, no offset, alpha = 0.05.
Output expected: n = 20,000; dispersion phi_hat = 0.995 (no overdispersion, standard
Poisson via `task_code1.R` is appropriate); none of the 4 predictors significant at
alpha = 0.05 (all p > 0.59, rate ratios approximately 1); overall drop-in-deviance test
not significant (p = 0.957).

- Example 2 (Edge case — small sample)
Input: a random subsample of `data/spam_detection_dataset.csv` with n = 15
(`set.seed(1); dat[sample(nrow(dat), 15), ]`), `y = "num_links"`, `x = c("has_offer")`.
Output expected: a small-sample warning (15 observations for 2 parameters, below the
20-observation rule-of-thumb threshold); `has_offer` not significant (p = 0.736, rate
ratio = 1.179, 95% CI 0.453-3.067); decision = fail to reject H0.

- Example 3 (Deliberately invalid input)
Input: `data/spam_detection_dataset.csv`, `y = "sender_score"` (a continuous 0-1
proportion, not a count), `x = c("num_words")`.
Output expected: Step 1 validation rejects with an error stating the response must be
integer counts (non-integer values found); no model is fit.

- Example 4 (Overdispersion routing to quasi-Poisson / negative binomial)
Input (generated inline):
```r
set.seed(42)
n <- 500
x <- runif(n, 0, 10)
mu <- exp(0.3 + 0.15 * x)
y <- MASS::rnegbin(n, mu = mu, theta = 1.2)
dat <- data.frame(y = y, x = x)
```
Output expected: `scripts/diagnostic.R` on `dat` with `y ~ x` finds phi_hat = 3.666
(overdispersion detected, recommends quasi-Poisson or negative binomial). Quasi-Poisson
(`task_code2.R`): dispersion approximately 3.666, `x` significant (p < .001, rate ratio
= 1.156, 95% CI 1.116-1.196). Negative binomial (`task_code3.R`): theta approximately
1.108, `x` significant (p < .001, rate ratio = 1.157, 95% CI 1.118-1.197). Both agree in
direction and significance; standard Poisson (`task_code1.R`) should not be used as the
final reported model here.

- Example 5 (Offset / exposure variable)
Input (generated inline):
```r
set.seed(7)
n <- 300
exposure <- round(runif(n, 50, 500))
group <- rbinom(n, 1, 0.5)
rate <- exp(-3 + 0.5 * group)
y <- rpois(n, lambda = rate * exposure)
dat <- data.frame(y = y, group = group, exposure = exposure)
```
Output expected: `task_code1.R` with `y = "y"`, `x = c("group")`, `offset = "exposure"`
fits `y ~ group + offset(log(exposure))`; `group` significant (p < .001, rate ratio =
1.665, 95% CI 1.579-1.756), close to the true simulated rate ratio of exp(0.5) = 1.649;
dispersion phi_hat approximately 0.974 (no overdispersion).

---
# Correctness Rate
Generate the actual output using the SKILL (see "Running the examples efficiently"
above for how to do this without separate full skill invocations), then verify if the
key values in the actual output are equivalent to the expected output shown above —
wording does not have to match exactly, and numerical values can be rounded.
Check whether the correctness rate is 100%; report the exact rate even if it is lower.

Report:
1. The correctness rate as a percentage
2. A markdown table with exactly these four columns: `Test | Outcome Expected | Outcome
   Generated | Match`, one row per example. Keep each cell terse, not a full paragraph.
3. If any example does not match, name it and explain the discrepancy in one sentence.
