# Paper

This file lists the methodology sources backing the procedure in this skill. Cite them
in Step 5's "References" section whenever a report is produced.

- The built-in source below was supplied when this skill was created; it is always cited.
- Any additional references the end user supplies in Step 0 of a run are appended here
  (one entry each, same format) and cited in that run's report.

**Citation format:** APA (7th edition)

## Built-in references

### Roback & Legler (2021)
Citation: Roback, P., & Legler, J. (2021). *Beyond multiple linear regression: Applied generalized linear models and multilevel models in R* (Chapter 4: Poisson Regression). CRC Press. https://bookdown.org/roback/bookdown-BeyondMLR/ch-poissonreg.html

## Run-supplied references

(None yet — add entries here as end users supply them in Step 0.)
