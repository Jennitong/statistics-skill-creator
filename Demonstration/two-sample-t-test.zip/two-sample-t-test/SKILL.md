---
name: two-sample-t-test
description: >
  Runs a two-sample (independent-samples) t-test end to end using Welch's
  unequal-variance t-test: validates inputs, checks assumptions (independence,
  normality per group, equal variance for information), runs the authoritative R
  computation, and writes a stakeholder-ready brief/moderate/detailed report with
  the mean difference, its confidence interval, Cohen's d, and the test decision.
  Trigger this whenever the user asks to test, compare, or evaluate the
  "difference in means between two groups", "compare two group means", mentions
  "two-sample t-test", "independent samples t-test", "Welch t-test", or describes a
  dataset and question that maps to comparing a numeric outcome across two
  independent groups even if they don't name the test explicitly. Also trigger on
  the skill's own name, two-sample-t-test.
---

# Two-Sample t-Test (Welch) — Hypothesis Testing and Effect Estimation

## Non-negotiable rules

- **Always use Welch's t-test** (`t.test(..., var.equal = FALSE)`). The equal-variance
  check is reported for information only and never switches the test to the pooled
  Student t-test.
- **Two-sided test with alpha = 0.05 unless the user explicitly states otherwise**
  (a one-sided alternative or a different alpha).
- **Always report the confidence interval for the mean difference and Cohen's d
  (pooled SD)** alongside the p-value, never a p-value alone.
- The two groups must be **independent**. For paired / before–after / matched data,
  stop and tell the user this skill does not apply (a paired t-test is needed).
- Never switch to a different test (e.g. Wilcoxon) silently. If normality fails, warn
  and suggest alternatives, but report the Welch result unless the user asks otherwise.

## Inputs

Ask the user for the data if not already provided. Either form is accepted:

- **Two numeric vectors** — the values for group 1 (`g1`) and group 2 (`g2`), with
  optional group names (`labels`).
- **A data frame or CSV file** (`data`) plus the name of the numeric **response**
  column (`response`) and the **grouping** column with exactly two levels (`group`).
  Optionally `levels` sets which group is "group 1" (difference = group 1 − group 2).

Optional: `alternative` (`"two.sided"` default, `"less"`, `"greater"`) and `alpha`
(default 0.05).

---

## Step 0 — Gather References, then Extract Inputs

**Before asking anything else**, ask the client this **single** question (do not stack
it with other questions. This is the single question that needs to be confirmed first,
not "question 1 of 4", "questions 1 of 2" or anything like that):

> Are there any publicly available references (papers, textbooks, methodology guides, websites, PDFs,
> etc.) I should rely on for the methods, assumptions, code, or interpretation in this
> analysis?

- If the client names a source that is publicly available, use its actual content to
  inform the assumptions, methods, code, and results for this run, and record it as an
  entry in `references/paper.md` (see that file's format) so Step 5 can cite it.
- If the client names a source that is **not** publicly available (paywalled, internal,
  a login-gated system, etc.), respond with exactly this wording:
  > The resource(s) provided is not public available and Claude does not have access.
  > You could manually provide relevant contents later, or rely on Claude's suggestions.

  Then continue to the remaining steps using standard, field-default assumptions — do
  not block on this.
- If the client has no references to offer, proceed using standard, field-default
  assumptions. Do not include a References section in the final report in this case.

This is a **per-run** question: ask it every time this skill is asked to produce a
result, not only the first time. Whatever references are confirmed usable this run
carry through to Step 5's References section — don't ask about references a second
time there. It is the first and only question at this point; it does not arrive with
other questions.

### Extract Inputs

If the client provides sentences that contain inputs (values, file path, column names,
group names, one-sided direction, alpha), extract and store them. Ask only for what is
still missing.

---

## Step 1 — Validate Inputs

Before running any tasks, check all of the following rules. Every rule is enforced by
`prepare_data()` in `scripts/utils.R` (used by all scripts). If any check fails, report
the error message clearly and stop.

- The response must be **numeric**; otherwise reject.
- The grouping variable must have **exactly 2 groups**; otherwise reject.
- Rows with `NA` in the response or group are **dropped**, and the number dropped is
  reported to the user.
- Each group must have **at least 2** non-missing observations; otherwise reject.
- Neither group may have **zero variance** (all values identical); otherwise reject.
- `alternative` must be one of `two.sided`, `less`, `greater`; `alpha` must be in (0, 1).
- Confirm from the user's description that the groups are independent (not paired).

---

## Step 2 — Explorative Data Analysis

Refer to `references/eda.md` for the full procedure. For the exact code to generate the
table and plots, refer to `scripts/eda_code.R`. Run from the skill directory:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/eda_code.R')
run_eda(<inputs_extracted>, plot_dir = '<plot_dir>')
"
```

`<inputs_extracted>` is either `g1 = c(...), g2 = c(...), labels = c('A','B')` or
`data = '<file.csv>', response = '<col>', group = '<col>'`. Use a scratch directory
for `<plot_dir>`.

Show, inline in the chat window, each with its own Read call and a sentence of
interpretation: `summary_table.png`, `eda_boxplot.png`, `eda_histogram.png`. Also
report the data-quality lines printed by the script (rows dropped, values beyond
1.5×IQR per group). The actual plots must be shown, not just described.

After the table and all plots are shown, ask the client using the exact words
**All of the preliminary plots are displayed. Continue to assumption checks?**

## Step 3 — Check Assumptions

Implicit assumptions
- Observations are independent within each group.
- The two groups are independent of each other (not paired or matched).

Explicit assumptions
- The response is approximately normally distributed within each group (Shapiro–Wilk
  + Q–Q plot; with n ≥ 30 in a group, the Central Limit Theorem relaxes this).
- Equal variances (F-test via `var.test()` and SD ratio) — **informational only**,
  because Welch's t-test does not require it.

See `references/assumptions.md` for the full checklist and what to do on failure; see
`references/guide.md` for why each assumption matters and how to interpret failures;
for citable methodology, see `references/paper.md`. For the actual checks, run
`scripts/diagnostic.R`:

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/diagnostic.R')
run_diagnostics(<inputs_extracted>, plot_dir = '<plot_dir>', alpha = <alpha>)
"
```

**The AI Agent decides each assumption's verdict** (do not ask the client to decide).
Show `diag_qq.png` inline with its own Read call, then present all assumptions at once:
for each, state what was observed (numbers verbatim from the script), what it means,
and the verdict. If an assumption does not hold, say so and suggest remedies (for
normality violated in a group with n < 30: Wilcoxon rank-sum test or a log
transformation; for dependence: a paired t-test or a mixed model). Otherwise state that
all assumptions hold. Then proceed — the Welch test is still run and reported unless the
client asks to change the analysis.

## Step 4 — Execute R Code and Extract Results

### Which script to run

| Test type | Script | Function |
|---|---|---|
| Welch two-sample t-test (always) | `scripts/task_code1.R` | `main_function1(g1, g2, data, response, group, labels, levels, alternative, alpha, plot_dir)` |

### Running the script

Run the R script using the Bash tool. This is the authoritative computation step — AI
should not calculate any numerical outputs by itself. All numerical results must come
directly from the output of this command.

```bash
cd "<path-to-skill-directory>" && Rscript -e "
source('scripts/task_code1.R')
main_function1(<inputs_extracted>, alternative = '<alternative>', alpha = <alpha>, plot_dir = '<plot_dir>')
"
```

Replace `<inputs_extracted>`, `<alternative>`, `<alpha>`, `<plot_dir>` with the values
from Step 0, and `<path-to-skill-directory>` with the absolute path of the folder that
contains this `SKILL.md`.

The function prints a `=== RESULT ===` block, a full `Conclusion:` paragraph, and a
`=== RESULTS TABLE ===` markdown table, and saves `result_ci_plot.png`. From that output
extract:
- Test name (Welch two-sample t-test), alternative, alpha
- n, mean, SD per group; mean difference (group 1 − group 2) and its CI
- Welch t, df, formatted p-value
- Cohen's d and its magnitude label
- Normality and equal-variance lines, the decision, and the full conclusion sentence

Use these values verbatim in Step 5. Do not recompute or reword numerical results.

### If the script fails

Surface the R error message verbatim to the user and stop — do not guess at the result
and do not silently fall back to a different test. Common causes: a missing R package
(`ggplot2`, `gtsummary`, `flextable`, `knitr`, `dplyr` — tell the user which to
install), inputs that don't match the expected shape (revisit Step 1), or a path issue
(confirm `<path-to-skill-directory>`).

# Step 5 - Output

First, ask the client which result type the report should contain, if the client has not
already stated it in the request:

  1. **Hypothesis-testing decision** — H0: μ₁ = μ₂; Welch t, df, p-value, and reject /
     fail to reject at alpha.
  2. **Effect estimate interpretation** — mean difference, its confidence interval, and
     Cohen's d with its practical magnitude.
  3. **Both** — the decision and the effect estimate together.

This is a **per-run** question — ask it every time this skill produces a report. Never
default to one result type silently. The CI and Cohen's d are reported in every option
(non-negotiable rule); option 1 simply centres the narrative on the decision and option
2 on the size of the effect.

Then ask for the response level using the exact wording as below:

> Would you like a **brief** (key result, assumptions, numerical values),
> **moderate** (adds context and supporting tables and plots), or **detailed**
> (full background, definitions, and step-by-step interpretation) response?

Output **exactly** the above sentence — nothing before it, nothing after except
waiting for the user's reply. Do not show formulas, intermediate tables, or any other text.

**Tone:** Professional but accessible. Write for a stakeholder who understands
"statistically significant" but does not need to verify the math. Never show R code in
the output; any exported report must use `echo = FALSE` in its setup chunk.

**Table formatting:** use bold headers, alignment markers, and a section break between
tables.

**Formatting conventions:**
- P-values: 4 decimal places for p ≥ 0.05; `p < 0.05 (*)` for 0.01 ≤ p < 0.05;
  `p < 0.01 (**)` for 0.001 ≤ p < 0.01; `p < 0.001 (***)` for p < 0.001 (the script
  already formats them this way).
- Test statistics and estimates: 2–3 decimal places.
- State the alpha used explicitly in the results.

---

### Brief

Exactly one paragraph covering: the method (Welch two-sample t-test, two-sided unless
stated), all assumptions checked and their verdicts (independence, normality per group,
equal variance — informational), the numerical outputs (group means, mean difference
with CI, Welch t, df, p-value, Cohen's d), the key result, and the decision, weighted
toward the chosen result type.

No table or plot displayed.

---

### Moderate

A single cohesive paragraph covering all elements in exact order:

1. **Background** — number of observations per group (and any dropped NAs), the
   response variable, the two groups, and the question being asked.
2. **Method chosen and assumptions** — Welch two-sample t-test; chosen because it
   compares two independent means without assuming equal variances; verdict for each
   assumption.
3. **Key result and numerical outputs supporting it** — mean difference and CI, Welch
   t, df, p-value, Cohen's d.
4. **Decision** — reject / fail to reject H0 at alpha, and what that means for the
   question.

Then show **plot 1**, **table 1**, **plot 2**, **table 2** below, followed by
References if applicable.

---

### Detailed

The full **Moderate** paragraph, tables and plots, then a short **Plain-language
interpretation** for a non-statistical audience:
- What the result means practically (how big the difference is in the response's
  units, and whether Cohen's d calls it negligible/small/medium/large).
- What can and cannot be concluded: "fail to reject" is not proof of no difference;
  statistical significance is not practical importance; association, not causation,
  unless groups were randomly assigned.
- Caveats raised in Step 3 (e.g. non-normality with small n, very small groups).
- Definitions of key terms: null hypothesis, p-value, confidence interval, Welch's
  t-test (and why it doesn't need equal variances), degrees of freedom, Cohen's d.

---

Return the following based on the brief/moderate/detailed level, in order:

**Background**
The context of the problem: what the response measures, what the two groups are, how
many observations each has, and the question (is there a difference in mean response,
or in a stated direction for a one-sided test).

**The assumptions held**

Refer to Step 3 and briefly state the verdict for independence, normality per group,
and equal variance (noting that Welch does not require it).

**Key result**

Refer to Step 4: mean difference (group 1 − group 2) with CI, Welch t, df, p-value,
Cohen's d.

**Decision**

Refer to Step 4: reject / fail to reject H0 at the stated alpha, with the conclusion
sentence verbatim.

**plot 1** (in EDA)

Only shown for `detailed` or `moderate` response levels. Show `eda_boxplot.png` inline
with the Read tool and interpret the spread and centre of each group.

**table 1** (in EDA)

Only shown for `detailed` or `moderate` response levels. Show `summary_table.png`
inline with the Read tool (mean (SD), median (Q1, Q3), min/max by group and overall).

**plot 2** (not in EDA)

Only shown for `detailed` or `moderate` response levels. Show `result_ci_plot.png`
(saved by `main_function1` when `plot_dir` is given) inline with the Read tool. It
shows:
- Top panel: each group's mean with its confidence interval; bottom panel: the mean
  difference with its Welch confidence interval and a dashed reference line at 0
- Axis labels: x = the response name, y = group / comparison
- A title naming the response, and a subtitle with Welch t, df, and p-value
- Point estimates annotated with their values; CI bars in blue

**table 2** (not in EDA)

Only shown for `detailed` or `moderate` response levels. Reproduce verbatim the 8 by 2
table printed under `=== RESULTS TABLE ===` (`**Quantity** | **Value**`): n / mean
(SD) for each group, mean difference, CI, Welch t (df), p-value, Cohen's d (magnitude),
and the decision.

**References**

Only shown for `detailed` or `moderate` response levels, and only if Step 0 turned up
one or more usable references this run (cite via `references/paper.md` and/or what the
client supplied directly); omit it entirely if Step 0 came up empty this run. Do not ask
about references again here.

---

### Notation

- μ₁, μ₂: population means of group 1 and group 2; H0: μ₁ = μ₂ (two-sided H1: μ₁ ≠ μ₂).
- x̄₁, x̄₂, s₁, s₂, n₁, n₂: sample means, standard deviations, and sizes.
- Welch t = (x̄₁ − x̄₂) / √(s₁²/n₁ + s₂²/n₂), with Welch–Satterthwaite degrees of freedom.
- Cohen's d = (x̄₁ − x̄₂) / s_p, where s_p = √(((n₁−1)s₁² + (n₂−1)s₂²)/(n₁+n₂−2));
  |d| < 0.2 negligible, < 0.5 small, < 0.8 medium, ≥ 0.8 large.

---

## Examples

### Example A — No true difference (simulated, seed 1)

Input: `set.seed(1); g1 <- rnorm(40, 10, 2); g2 <- rnorm(40, 10, 2)`; two-sided,
alpha = 0.05. Result type: both. Response level: brief.

> A two-sided Welch two-sample t-test was used to compare Group 1 (n = 40, mean =
> 10.184, SD = 1.773) and Group 2 (n = 40, mean = 10.241, SD = 1.852). The groups were
> assumed independent by design; Shapiro–Wilk showed no evidence against normality in
> either group (p = 0.2039 and p = 0.3865), and the F-test showed no evidence of unequal
> variances (p = 0.7886), although Welch's test does not require equal variances. The
> estimated mean difference was −0.056 (95% CI [−0.864, 0.751]), Welch t = −0.139 on
> 77.85 df, p = 0.8896, Cohen's d = −0.031 (negligible). At alpha = 0.05 we fail to
> reject the null hypothesis: there is no statistically significant evidence that the
> two group means differ.

### Example B — Injected effect (simulated, seed 2)

Input: `set.seed(2); g1 <- rnorm(40, 10, 2); g2 <- rnorm(40, 12, 2)`, labels Control /
Treatment; two-sided, alpha = 0.05. Result type: both. Response level: moderate.

> We compared the mean response of 40 Control and 40 Treatment observations (no
> missing values). A Welch two-sample t-test was used because it compares two
> independent means without assuming equal variances; independence holds by design,
> both groups look normal (Shapiro–Wilk p = 0.7122 and p = 0.2152), and variances are
> similar (F-test p = 0.7966, SD ratio 1.04). Control averaged 10.195 (SD 2.222) and
> Treatment 11.923 (SD 2.317); the mean difference (Control − Treatment) was −1.728
> (95% CI [−2.738, −0.717]), Welch t = −3.404 on 77.87 df, p < 0.01 (**), Cohen's
> d = −0.761 (medium). At alpha = 0.05 we reject the null hypothesis: Treatment has a
> significantly higher mean response than Control.

Followed by the boxplot, summary table, CI plot, and results table.

---

# Validation steps: this step is only for developer, not for SKILL user

Should be hidden unless explicitly mentioned. This step is only disclosed when the
developer explicitly asks for testing the validity of the SKILL. It is different from
Step 1 Validate Inputs: it checks the validity of the entire SKILL. Do not mention
anything related to this step to regular SKILL users.

Refer to `references/validation.md` for validation steps.

- **Note:** ignore the three response levels for validation. Only check that the key
  numerical values and decisions from expectation and actual computation match.
- **Speed:** run all 8 cases through the single batched script
  `scripts/validation_run.R` (see "Running the examples efficiently" in
  `references/validation.md`) rather than invoking the full conversational Steps 0–5
  8 separate times. Only fall back to a full conversational run for a specific case if
  the batched check disagrees with its expected outcome.
- **Output:** report the correctness rate as a percentage, followed by a 4-column
  markdown table (`Test | Outcome Expected | Outcome Generated | Match`) with one row
  per case.
