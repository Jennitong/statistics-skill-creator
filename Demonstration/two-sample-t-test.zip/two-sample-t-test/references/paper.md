# Paper

This file lists methodology sources backing the procedure in this skill — cite these in
Step 5's "References" section when they inform how a test or assumption check was run.

No references were supplied when this skill was created. References are gathered per
run in Step 0. When an end user supplies a usable, publicly available source, add one
entry per source below, using the citation style the end user asks for (APA by default):

```markdown
## Short name, e.g. "Author (Year)"
Citation: full citation, formatted in the chosen style
```
