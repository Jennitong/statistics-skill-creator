# Guide — Two-Sample t-Test (Welch)

The "why" and "how to interpret" behind the checks in `assumptions.md`.

## Why Welch, always
Welch's t-test keeps close to the nominal type I error whether or not the variances are
equal, and loses very little power when they are equal. Pre-testing variances and then
choosing between Student and Welch distorts error rates, so this skill always uses
Welch and reports the variance check for information only. Never show both a Student
and a Welch result.

## How to interpret assumption failures
- **Non-independence**: the most serious violation; no adjustment inside this test fixes
  it. Name it, explain that the p-value is likely too small, and recommend the right
  design-based analysis (paired t-test, mixed model).
- **Non-normality**: matters mainly for small groups (n < 30), especially with skew or
  heavy tails, and with unequal group sizes. Suggest a log transformation (for positive,
  right-skewed data — note that conclusions then concern geometric means) or the Wilcoxon
  rank-sum test (which compares distributions/location, not means).
- **Unequal variances**: already handled by Welch; mention that the groups differ in
  spread, which can be practically important.

## Interpreting the results
- The CI for the mean difference gives the plausible range of the true difference;
  if it excludes 0 the two-sided test rejects at the same alpha.
- Cohen's d expresses the difference in pooled-SD units: |d| < 0.2 negligible,
  0.2–0.5 small, 0.5–0.8 medium, ≥ 0.8 large. These are conventions; the practical
  meaning depends on the field.
- "Fail to reject" ≠ "no difference": point to the CI width to show what differences
  remain plausible.
- With a one-sided alternative, the CI is one-sided (one bound is infinite).

## Common pitfalls to avoid
- Running the test on paired data.
- Reporting only the p-value without the CI and effect size.
- Silently switching to a non-parametric test.
- Dropping outliers without flagging and explaining it.
- Causal language for non-randomised groups.
