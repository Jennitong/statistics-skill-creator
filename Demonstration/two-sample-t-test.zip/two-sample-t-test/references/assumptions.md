# Check Assumptions — Welch Two-Sample t-Test

**Note**: The AI Agent runs the **exact** R code in `scripts/diagnostic.R`
(`run_diagnostics()`) for the explicit checks. Do not compute values or draw plots any
other way. The AI Agent decides each verdict (the client chose this at skill creation)
and presents all assumptions together.

## All Assumptions
1. Independence within groups (implicit)
2. Independence between groups (implicit)
3. Normality of the response within each group (explicit)
4. Equal variances (explicit, informational only)

### 1. Independence within groups (Implicit)
Each observation is independent of the others in its group (no clustering, repeated
measurements of the same unit, or time-series dependence). Not testable from the data —
confirm from the study design. If violated (e.g. repeated measures or clusters), the
standard errors are too small and the p-value too optimistic; recommend a mixed-effects
model or aggregating to one value per unit.

### 2. Independence between groups (Implicit)
The two groups contain different, unrelated units (not paired or matched). If the data
are paired (before/after on the same subjects, matched pairs), this skill does not
apply — recommend a paired t-test.

### 3. Normality within each group (Explicit)
The response is approximately normal in each group. Checked with a Shapiro–Wilk test per
group and a normal Q–Q plot (`diag_qq.png`, shown inline).
- Shapiro p ≥ alpha → no evidence against normality.
- Shapiro p < alpha but that group has n ≥ 30 → the t-test is robust by the Central
  Limit Theorem; note it and proceed.
- Shapiro p < alpha with n < 30 → **warn**: the t-test may be unreliable. Suggest the
  Wilcoxon rank-sum (Mann–Whitney) test or a log transformation for right-skewed
  positive data. Still report the Welch result unless the client asks to change.
- n < 3 in a group → Shapiro–Wilk cannot be computed; warn that normality cannot be
  assessed and results should be interpreted with great caution.
Always weigh the Q–Q plot alongside the p-value: with large n, Shapiro flags trivial
departures; with small n, it has little power.

### 4. Equal variances (Explicit, informational)
Checked with the F-test (`var.test()`) and the SD ratio (larger/smaller). Because the
skill **always** uses Welch's t-test, which does not assume equal variances, this check
never changes the test. Report it so the reader knows whether the variances differ (a
substantive finding in itself) and why Welch is appropriate. Note: the F-test is itself
sensitive to non-normality.

## Note
All relevant plots for assumptions must be shown inline for the client to see — not
only described.
