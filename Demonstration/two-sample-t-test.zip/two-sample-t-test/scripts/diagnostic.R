## Diagnostic -- two-sample t-test (Welch)
#
# Usage (from the skill directory):
#   source('scripts/diagnostic.R')
#   run_diagnostics(g1 = c(...), g2 = c(...), labels = c("A", "B"), plot_dir = "<dir>", alpha = 0.05)
#   run_diagnostics(data = "path.csv", response = "score", group = "arm", plot_dir = "<dir>")
#
# Explicit assumption checks:
#   - Normality per group: Shapiro-Wilk test + normal Q-Q plot (diag_qq.png)
#   - Equal variance (informational only -- Welch is always used): F-test via
#     var.test() and the SD ratio
# Display diag_qq.png inline with its own Read call.

source("scripts/utils.R")
suppressPackageStartupMessages(library(ggplot2))

check_normality <- function(dat, alpha = 0.05) {
  out <- lapply(levels(dat$grp), function(lv) {
    yy <- dat$y[dat$grp == lv]
    n  <- length(yy)
    if (n < 3 || n > 5000) {
      return(data.frame(group = lv, n = n, W = NA, p = NA,
                        verdict = sprintf("Shapiro-Wilk not computable (n = %d); normality cannot be tested numerically -- rely on the Q-Q plot%s",
                                          n, if (n < 3) " and treat the result with caution (very small sample)" else "")))
    }
    sw <- stats::shapiro.test(yy)
    verdict <- if (sw$p.value >= alpha) "no evidence against normality"
               else if (n >= 30) "normality rejected, but n >= 30 so the t-test is robust by the Central Limit Theorem"
               else "normality rejected with n < 30 -- the t-test may be unreliable"
    data.frame(group = lv, n = n, W = unname(sw$statistic), p = sw$p.value, verdict = verdict)
  })
  do.call(rbind, out)
}

check_equal_variance <- function(dat, alpha = 0.05) {
  g <- levels(dat$grp)
  y1 <- dat$y[dat$grp == g[1]]; y2 <- dat$y[dat$grp == g[2]]
  ft <- stats::var.test(y1, y2)
  sds <- c(stats::sd(y1), stats::sd(y2))
  list(F = unname(ft$statistic), df1 = unname(ft$parameter[1]), df2 = unname(ft$parameter[2]),
       p = ft$p.value, sd1 = sds[1], sd2 = sds[2], sd_ratio = max(sds) / min(sds),
       equal = ft$p.value >= alpha)
}

run_diagnostics <- function(g1 = NULL, g2 = NULL, data = NULL, response = NULL,
                            group = NULL, labels = c("Group 1", "Group 2"),
                            levels = NULL, plot_dir = ".", alpha = 0.05) {
  dat <- prepare_data(g1, g2, data, response, group, labels, levels)
  dir.create(plot_dir, showWarnings = FALSE, recursive = TRUE)

  cat("=== Assumption 1 & 2 (implicit): independence within and between groups ===\n")
  cat("Not testable from the data -- confirm from the study design (no pairing/repeated measures, random sampling/assignment).\n\n")

  cat("=== Assumption 3 (explicit): normality of each group ===\n")
  nm <- check_normality(dat, alpha)
  for (i in seq_len(nrow(nm))) {
    if (is.na(nm$p[i])) cat(sprintf("Group '%s' (n = %d): %s\n", nm$group[i], nm$n[i], nm$verdict[i]))
    else cat(sprintf("Group '%s' (n = %d): Shapiro-Wilk W = %.3f, %s -> %s\n",
                     nm$group[i], nm$n[i], nm$W[i], format_p(nm$p[i]), nm$verdict[i]))
  }
  normal_ok <- all(is.na(nm$p) | nm$p >= alpha | nm$n >= 30)
  cat(sprintf("Normality verdict: %s\n\n", if (normal_ok) "HOLDS (or mitigated by n >= 30)" else
    "VIOLATED in a small group -- warn; suggest Wilcoxon rank-sum test (wilcox.test) or a log transform; do NOT switch tests silently"))

  qq <- ggplot(dat, aes(sample = y)) +
    stat_qq(size = 1.8, alpha = 0.8) + stat_qq_line(colour = "firebrick") +
    facet_wrap(~ grp, scales = "free") +
    labs(x = "Theoretical normal quantiles", y = "Sample quantiles",
         title = "Normal Q-Q plot of the response by group") +
    theme_minimal(base_size = 13)
  ggsave(file.path(plot_dir, "diag_qq.png"), qq, width = 8, height = 4.5, dpi = 150)

  cat("=== Assumption 4 (explicit, informational): equal variances ===\n")
  ev <- check_equal_variance(dat, alpha)
  cat(sprintf("F-test: F(%d, %d) = %.3f, %s; SD %s = %.3f, SD %s = %.3f, SD ratio = %.2f\n",
              ev$df1, ev$df2, ev$F, format_p(ev$p), levels(dat$grp)[1], ev$sd1,
              levels(dat$grp)[2], ev$sd2, ev$sd_ratio))
  cat(sprintf("Equal-variance verdict: %s. Welch's t-test does not assume equal variances, so it is used either way.\n",
              if (ev$equal) "no evidence of unequal variances" else "variances differ"))

  cat("\nSaved:", file.path(plot_dir, "diag_qq.png"), "\n")
  invisible(list(normality = nm, normal_ok = normal_ok, equal_variance = ev))
}
