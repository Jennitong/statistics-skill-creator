## EDA code -- two-sample t-test
#
# Usage (from the skill directory):
#   source('scripts/eda_code.R')
#   run_eda(g1 = c(...), g2 = c(...), labels = c("A", "B"), plot_dir = "<dir>")
#   run_eda(data = "path.csv", response = "score", group = "arm", plot_dir = "<dir>")
#
# Produces (all PNGs in plot_dir; display each inline with its own Read call):
#   summary_table.png  -- gtsummary descriptive table by group
#   eda_boxplot.png    -- boxplot + jittered points of the response by group
#   eda_histogram.png  -- histogram of the response, one panel per group
# Do not hand-type means, SDs, or counts -- they must come from this output.

source("scripts/utils.R")
suppressPackageStartupMessages({
  library(ggplot2)
  library(gtsummary)
  library(flextable)
})

run_eda <- function(g1 = NULL, g2 = NULL, data = NULL, response = NULL,
                    group = NULL, labels = c("Group 1", "Group 2"),
                    levels = NULL, plot_dir = ".") {
  dat <- prepare_data(g1, g2, data, response, group, labels, levels)
  resp_name <- attr(dat, "response_name")
  dir.create(plot_dir, showWarnings = FALSE, recursive = TRUE)

  ## Data quality
  cat("=== Data quality ===\n")
  cat(sprintf("Rows supplied: %d | rows dropped for missing values: %d | rows analysed: %d\n",
              attr(dat, "n_total"), attr(dat, "n_dropped"), nrow(dat)))
  for (lv in levels(dat$grp)) {
    yy <- dat$y[dat$grp == lv]
    q  <- stats::quantile(yy, c(.25, .75)); iqr <- diff(q)
    n_out <- sum(yy < q[1] - 1.5 * iqr | yy > q[2] + 1.5 * iqr)
    cat(sprintf("Group '%s': n = %d, values beyond 1.5*IQR: %d\n", lv, length(yy), n_out))
  }

  ## Summary statistics table
  tab_dat <- data.frame(Group = dat$grp, y = dat$y)
  names(tab_dat)[2] <- resp_name
  tbl <- gtsummary::tbl_summary(
    tab_dat, by = Group,
    type = list(dplyr::all_of(resp_name) ~ "continuous2"),
    statistic = list(dplyr::all_of(resp_name) ~ c("{mean} ({sd})", "{median} ({p25}, {p75})", "{min}, {max}")),
    digits = list(dplyr::all_of(resp_name) ~ 2)
  ) |> gtsummary::add_overall() |> gtsummary::modify_header(label ~ "**Variable**")
  ft <- gtsummary::as_flex_table(tbl)
  flextable::save_as_image(ft, path = file.path(plot_dir, "summary_table.png"))
  print(tbl |> gtsummary::as_tibble())

  ## Boxplot + jitter
  p1 <- ggplot(dat, aes(x = grp, y = y, fill = grp)) +
    geom_boxplot(alpha = 0.5, outlier.shape = NA, width = 0.5) +
    geom_jitter(width = 0.12, alpha = 0.7, size = 1.8) +
    stat_summary(fun = mean, geom = "point", shape = 23, size = 3.5, fill = "white") +
    labs(x = "Group", y = resp_name,
         title = paste("The boxplot of", resp_name, "by group"),
         subtitle = "Diamond = group mean") +
    theme_minimal(base_size = 13) + theme(legend.position = "none")
  ggsave(file.path(plot_dir, "eda_boxplot.png"), p1, width = 7, height = 5, dpi = 150)

  ## Histogram per group
  p2 <- ggplot(dat, aes(x = y, fill = grp)) +
    geom_histogram(bins = max(5, min(30, ceiling(sqrt(nrow(dat))) + 2)),
                   colour = "white", alpha = 0.8) +
    facet_wrap(~ grp, ncol = 1) +
    labs(x = resp_name, y = "Count",
         title = paste("Histogram of", resp_name, "by group")) +
    theme_minimal(base_size = 13) + theme(legend.position = "none")
  ggsave(file.path(plot_dir, "eda_histogram.png"), p2, width = 7, height = 6, dpi = 150)

  cat("\nSaved:", file.path(plot_dir, c("summary_table.png", "eda_boxplot.png", "eda_histogram.png")), sep = "\n  ")
  invisible(dat)
}
