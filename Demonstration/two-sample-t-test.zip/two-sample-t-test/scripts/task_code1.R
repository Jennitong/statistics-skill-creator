# task_code1
#
# Task for this R file: Welch two-sample t-test (unequal variances) comparing the
# means of two independent groups, with 95% CI (or 1 - alpha) for the mean
# difference and Cohen's d (pooled SD). Difference = group 1 minus group 2.
#
# Usage (from the skill directory):
#   source('scripts/task_code1.R')
#   main_function1(g1 = c(...), g2 = c(...), labels = c("A", "B"))
#   main_function1(data = "path.csv", response = "score", group = "arm",
#                  alternative = "two.sided", alpha = 0.05, plot_dir = "<dir>")
# If `plot_dir` is given, also saves result_ci_plot.png (group means with CIs and
# the mean difference with its CI) for the moderate/detailed report levels.
# A markdown results table (Table 2) is always printed under "=== RESULTS TABLE ===".

source("scripts/utils.R")
source("scripts/diagnostic.R")

validate_inputs <- function(alternative, alpha, ...) {
  if (!alternative %in% c("two.sided", "less", "greater"))
    stop("`alternative` must be one of 'two.sided', 'less', 'greater'.", call. = FALSE)
  if (!is.numeric(alpha) || length(alpha) != 1 || alpha <= 0 || alpha >= 1)
    stop("`alpha` must be a single number between 0 and 1.", call. = FALSE)
  prepare_data(...)
}

check_assumptions <- function(dat, alpha) {
  nm <- check_normality(dat, alpha)
  ev <- check_equal_variance(dat, alpha)
  list(normality = nm, equal_variance = ev,
       normal_ok = all(is.na(nm$p) | nm$p >= alpha | nm$n >= 30),
       untestable = any(is.na(nm$p)))
}

cohens_d <- function(y1, y2) {
  n1 <- length(y1); n2 <- length(y2)
  sp <- sqrt(((n1 - 1) * stats::var(y1) + (n2 - 1) * stats::var(y2)) / (n1 + n2 - 2))
  (mean(y1) - mean(y2)) / sp
}

d_magnitude <- function(d) {
  a <- abs(d)
  if (a < 0.2) "negligible" else if (a < 0.5) "small" else if (a < 0.8) "medium" else "large"
}

run_test <- function(dat, alternative, alpha) {
  g  <- levels(dat$grp)
  y1 <- dat$y[dat$grp == g[1]]; y2 <- dat$y[dat$grp == g[2]]
  tt <- stats::t.test(y1, y2, alternative = alternative, var.equal = FALSE,
                      conf.level = 1 - alpha)
  d  <- cohens_d(y1, y2)
  list(groups = g, n = c(length(y1), length(y2)), mean = c(mean(y1), mean(y2)),
       sd = c(stats::sd(y1), stats::sd(y2)), diff = mean(y1) - mean(y2),
       t = unname(tt$statistic), df = unname(tt$parameter), p = tt$p.value,
       ci = tt$conf.int, d = d, d_mag = d_magnitude(d),
       alternative = alternative, alpha = alpha, reject = tt$p.value < alpha,
       response = attr(dat, "response_name"), n_dropped = attr(dat, "n_dropped"))
}

report_conclusion <- function(r, a) {
  alt_txt <- switch(r$alternative,
    two.sided = sprintf("the mean %s differs between %s and %s", r$response, r$groups[1], r$groups[2]),
    greater   = sprintf("the mean %s is greater in %s than in %s", r$response, r$groups[1], r$groups[2]),
    less      = sprintf("the mean %s is smaller in %s than in %s", r$response, r$groups[1], r$groups[2]))
  ci_lab <- sprintf("%g%% CI", 100 * (1 - r$alpha))
  ci_txt <- sprintf("[%s, %s]",
                    ifelse(is.finite(r$ci[1]), sprintf("%.3f", r$ci[1]), "-Inf"),
                    ifelse(is.finite(r$ci[2]), sprintf("%.3f", r$ci[2]), "Inf"))

  nm <- a$normality
  norm_txt <- paste(sprintf("%s: %s", nm$group,
                            ifelse(is.na(nm$p), "Shapiro-Wilk not computable",
                                   sprintf("Shapiro-Wilk W = %.3f, %s", nm$W, sapply(nm$p, format_p)))),
                    collapse = "; ")
  ev <- a$equal_variance

  cat("=== RESULT ===\n")
  cat("Test: Welch two-sample t-test (unequal variances)\n")
  cat(sprintf("Alternative: %s | alpha = %g\n", r$alternative, r$alpha))
  if (r$n_dropped > 0) cat(sprintf("Note: %d row(s) with missing values were dropped.\n", r$n_dropped))
  cat(sprintf("%s: n = %d, mean = %.3f, SD = %.3f\n", r$groups[1], r$n[1], r$mean[1], r$sd[1]))
  cat(sprintf("%s: n = %d, mean = %.3f, SD = %.3f\n", r$groups[2], r$n[2], r$mean[2], r$sd[2]))
  cat(sprintf("Mean difference (%s - %s) = %.3f, %s %s\n", r$groups[1], r$groups[2], r$diff, ci_lab, ci_txt))
  cat(sprintf("Welch t = %.3f, df = %.2f, %s (raw p = %.6g)\n", r$t, r$df, format_p(r$p), r$p))
  cat(sprintf("Cohen's d (pooled SD) = %.3f (%s)\n", r$d, r$d_mag))
  cat(sprintf("Normality: %s -> %s\n", norm_txt,
              if (a$normal_ok && !a$untestable) "holds (or mitigated by n >= 30)"
              else if (a$untestable) "WARNING: cannot be assessed numerically (n < 3 in a group); interpret with caution"
              else "WARNING: violated in a group with n < 30; consider Wilcoxon rank-sum test or a log transform"))
  cat(sprintf("Equal variance (informational): F = %.3f, %s, SD ratio = %.2f -> %s\n",
              ev$F, format_p(ev$p), ev$sd_ratio,
              if (ev$equal) "no evidence of unequal variances" else "variances differ"))
  cat(sprintf("Decision: %s H0 at alpha = %g\n\n", if (r$reject) "REJECT" else "FAIL TO REJECT", r$alpha))

  para <- sprintf(paste0(
    "A Welch two-sample t-test was used to compare the mean %s of %s (n = %d, mean = %.3f, SD = %.3f) ",
    "and %s (n = %d, mean = %.3f, SD = %.3f). The estimated mean difference (%s - %s) was %.3f ",
    "(%s %s), with Welch t = %.3f on %.2f degrees of freedom, %s, and Cohen's d = %.3f (%s effect). ",
    "At the %g significance level we %s the null hypothesis of equal means; ",
    "that is, there is %s evidence that %s."),
    r$response, r$groups[1], r$n[1], r$mean[1], r$sd[1],
    r$groups[2], r$n[2], r$mean[2], r$sd[2], r$groups[1], r$groups[2], r$diff,
    ci_lab, ci_txt, r$t, r$df, format_p(r$p), r$d, r$d_mag,
    r$alpha, if (r$reject) "reject" else "fail to reject",
    if (r$reject) "statistically significant" else "no statistically significant",
    alt_txt)
  cat("Conclusion:", para, "\n")
  invisible(r)
}

results_table <- function(r) {
  ci_lab <- sprintf("%g%% CI", 100 * (1 - r$alpha))
  fmt_ci <- function(ci) sprintf("[%s, %s]",
    ifelse(is.finite(ci[1]), sprintf("%.3f", ci[1]), "-Inf"),
    ifelse(is.finite(ci[2]), sprintf("%.3f", ci[2]), "Inf"))
  tab <- data.frame(
    Quantity = c(sprintf("%s: n / mean (SD)", r$groups[1]), sprintf("%s: n / mean (SD)", r$groups[2]),
                 sprintf("Mean difference (%s - %s)", r$groups[1], r$groups[2]), ci_lab,
                 "Welch t (df)", "p-value", "Cohen's d (pooled SD)", "Decision"),
    Value = c(sprintf("%d / %.3f (%.3f)", r$n[1], r$mean[1], r$sd[1]),
              sprintf("%d / %.3f (%.3f)", r$n[2], r$mean[2], r$sd[2]),
              sprintf("%.3f", r$diff), fmt_ci(r$ci), sprintf("%.3f (%.2f)", r$t, r$df),
              format_p(r$p), sprintf("%.3f (%s)", r$d, r$d_mag),
              sprintf("%s H0 at alpha = %g", if (r$reject) "Reject" else "Fail to reject", r$alpha)))
  names(tab) <- c("**Quantity**", "**Value**")
  cat("=== RESULTS TABLE ===\n")
  cat(knitr::kable(tab, format = "pipe", align = c("l", "r")), sep = "\n")
  cat("\n")
}

result_plot <- function(dat, r, plot_dir) {
  dir.create(plot_dir, showWarnings = FALSE, recursive = TRUE)
  conf <- 1 - r$alpha
  grp_ci <- do.call(rbind, lapply(r$groups, function(lv) {
    yy <- dat$y[dat$grp == lv]; ci <- stats::t.test(yy, conf.level = conf)$conf.int
    data.frame(label = lv, est = mean(yy), lo = ci[1], hi = ci[2], panel = "Group means")
  }))
  diff_ci <- data.frame(label = sprintf("%s - %s", r$groups[1], r$groups[2]), est = r$diff,
                        lo = r$ci[1], hi = r$ci[2], panel = "Mean difference (Welch)")
  pd <- rbind(grp_ci, diff_ci)
  pd$lo[!is.finite(pd$lo)] <- NA; pd$hi[!is.finite(pd$hi)] <- NA
  ref <- data.frame(panel = "Mean difference (Welch)", x = 0)
  p <- ggplot(pd, aes(x = est, y = label)) +
    geom_vline(data = ref, aes(xintercept = x), linetype = "dashed", colour = "grey40") +
    geom_errorbar(aes(xmin = lo, xmax = hi), width = 0.15, orientation = "y", colour = "steelblue", na.rm = TRUE) +
    geom_point(size = 3, colour = "steelblue4") +
    geom_text(aes(label = sprintf("%.2f", est)), vjust = -1, size = 3.8) +
    facet_wrap(~ panel, ncol = 1, scales = "free") +
    labs(x = r$response, y = NULL,
         title = sprintf("Group means and mean difference of %s with %g%% CIs", r$response, 100 * conf),
         subtitle = sprintf("Welch t = %.2f, df = %.1f, %s; dashed line = no difference", r$t, r$df, format_p(r$p))) +
    theme_minimal(base_size = 13)
  f <- file.path(plot_dir, "result_ci_plot.png")
  ggsave(f, p, width = 8, height = 5, dpi = 150)
  cat("Saved:", f, "\n")
}

main_function1 <- function(g1 = NULL, g2 = NULL, data = NULL, response = NULL,
                           group = NULL, labels = c("Group 1", "Group 2"),
                           levels = NULL, alternative = "two.sided", alpha = 0.05,
                           plot_dir = NULL) {
  dat    <- validate_inputs(alternative, alpha, g1 = g1, g2 = g2, data = data,
                            response = response, group = group,
                            labels = labels, levels = levels)
  assump <- check_assumptions(dat, alpha)
  result <- run_test(dat, alternative, alpha)
  report_conclusion(result, assump)
  results_table(result)
  if (!is.null(plot_dir)) result_plot(dat, result, plot_dir)
  invisible(result)
}
