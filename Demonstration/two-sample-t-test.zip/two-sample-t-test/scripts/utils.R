# utils.R
#
# Shared helpers for the two-sample t-test skill. Sourced by eda_code.R,
# diagnostic.R and task_code1.R (run every script from the skill directory).
#
# prepare_data() accepts EITHER
#   - two numeric vectors `g1`, `g2` (optionally named via `labels`), OR
#   - a data frame / CSV path `data` plus the column names `response` and `group`
# and returns a clean long-format data frame with columns `y` (numeric) and
# `grp` (2-level factor; the first level is "group 1", the difference is
# reported as group 1 minus group 2). It stops with a clear message on any
# invalid input, and drops NAs while recording how many were dropped.

prepare_data <- function(g1 = NULL, g2 = NULL, data = NULL, response = NULL,
                         group = NULL, labels = c("Group 1", "Group 2"),
                         levels = NULL) {
  if (!is.null(data)) {
    if (is.character(data) && length(data) == 1) {
      if (!file.exists(data)) stop("Data file not found: ", data, call. = FALSE)
      data <- utils::read.csv(data, stringsAsFactors = FALSE)
    }
    if (!is.data.frame(data)) stop("`data` must be a data frame or a CSV file path.", call. = FALSE)
    if (is.null(response) || is.null(group))
      stop("When `data` is supplied, both `response` and `group` column names are required.", call. = FALSE)
    missing_cols <- setdiff(c(response, group), names(data))
    if (length(missing_cols) > 0)
      stop("Column(s) not found in data: ", paste(missing_cols, collapse = ", "), call. = FALSE)
    y   <- data[[response]]
    grp <- data[[group]]
    resp_name <- response
  } else {
    if (is.null(g1) || is.null(g2))
      stop("Supply either two vectors `g1` and `g2`, or `data` + `response` + `group`.", call. = FALSE)
    y   <- c(g1, g2)
    grp <- rep(labels, times = c(length(g1), length(g2)))
    resp_name <- "Response"
    if (is.null(levels)) levels <- labels
  }

  if (!is.numeric(y))
    stop("The response must be numeric (got ", class(y)[1], ").", call. = FALSE)

  n_total <- length(y)
  keep    <- !is.na(y) & !is.na(grp)
  n_drop  <- sum(!keep)
  y   <- y[keep]
  grp <- grp[keep]

  grp_levels <- if (!is.null(levels)) levels else if (is.factor(grp)) levels(droplevels(grp)) else sort(unique(as.character(grp)))
  grp_levels <- grp_levels[grp_levels %in% as.character(grp)]
  if (length(unique(as.character(grp))) != 2 || length(grp_levels) != 2)
    stop("The grouping variable must have exactly 2 groups (found ",
         length(unique(as.character(grp))), ": ",
         paste(unique(as.character(grp)), collapse = ", "), ").", call. = FALSE)
  grp <- factor(as.character(grp), levels = grp_levels)

  for (lv in grp_levels) {
    yy <- y[grp == lv]
    if (length(yy) < 2)
      stop("Group '", lv, "' has fewer than 2 non-missing observations (n = ",
           length(yy), "); a t-test needs at least 2 per group.", call. = FALSE)
    if (stats::sd(yy) == 0)
      stop("Group '", lv, "' has zero variance (all values identical); the t-test is undefined.", call. = FALSE)
  }

  dat <- data.frame(y = y, grp = grp)
  attr(dat, "response_name") <- resp_name
  attr(dat, "n_total")       <- n_total
  attr(dat, "n_dropped")     <- n_drop
  dat
}

# p-value formatting per SKILL.md conventions
format_p <- function(p) {
  if (p < 0.001) "p < 0.001 (***)"
  else if (p < 0.01) "p < 0.01 (**)"
  else if (p < 0.05) "p < 0.05 (*)"
  else sprintf("p = %.4f", p)
}
