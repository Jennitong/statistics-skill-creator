# validation_run.R -- developer-only batched validation (see references/validation.md)
#
# Run from the skill directory:
#   Rscript scripts/validation_run.R
# Runs all 8 simulated / constructed cases through main_function1 in one R
# process, compares key results with the expected outcomes, and prints the
# correctness rate plus a 4-column markdown table.

suppressMessages(suppressWarnings(source("scripts/task_code1.R")))

quiet <- function(expr) {
  out <- NULL
  res <- tryCatch({ out <- utils::capture.output(r <- expr); list(ok = TRUE, r = r) },
                  error = function(e) list(ok = FALSE, msg = conditionMessage(e)))
  res
}
norm_flag <- function(a, b) {
  nm <- check_normality(prepare_data(g1 = a, g2 = b))
  any(!is.na(nm$p) & nm$p < 0.05 & nm$n < 30)
}

cases <- list()

set.seed(1); a <- rnorm(40, 10, 2); b <- rnorm(40, 10, 2); r <- quiet(main_function1(g1 = a, g2 = b))
cases[[1]] <- c("1 Null (no effect)", "Fail to reject; normality & equal var OK",
  sprintf("p = %.4f, %s", r$r$p, if (r$r$reject) "reject" else "fail to reject"),
  !r$r$reject && !norm_flag(a, b) && var.test(a, b)$p.value >= 0.05)

set.seed(2); a <- rnorm(40, 10, 2); b <- rnorm(40, 12, 2); r <- quiet(main_function1(g1 = a, g2 = b))
cases[[2]] <- c("2 Injected effect d = 1", "Reject, p < 0.01 (**), CI excludes 0",
  sprintf("%s, CI [%.3f, %.3f]", format_p(r$r$p), r$r$ci[1], r$r$ci[2]),
  r$r$reject && r$r$p < 0.01 && r$r$p >= 0.001 && r$r$ci[2] < 0)

set.seed(3); a <- rnorm(25, 10, 1); b <- rnorm(60, 11, 4); r <- quiet(main_function1(g1 = a, g2 = b))
fp <- var.test(a, b)$p.value
cases[[3]] <- c("3 Unequal variances", "F-test flags (p < 0.001); Welch rejects",
  sprintf("F-test %s; Welch %s", format_p(fp), format_p(r$r$p)),
  fp < 0.001 && r$r$reject && !norm_flag(a, b))

set.seed(4); a <- rt(20, 3) + 10; b <- rt(20, 3) + 10; r <- quiet(main_function1(g1 = a, g2 = b))
sw <- c(shapiro.test(a)$p.value, shapiro.test(b)$p.value)
cases[[4]] <- c("4 Heavy tails t(3)", "Shapiro flags both (p < 0.01); warn, Welch still run",
  sprintf("SW %s / %s; test ran = %s", format_p(sw[1]), format_p(sw[2]), r$ok),
  all(sw < 0.01) && r$ok && norm_flag(a, b))

r <- quiet(main_function1(g1 = c(1, 2), g2 = c(3, 5)))
nm <- check_normality(prepare_data(g1 = c(1, 2), g2 = c(3, 5)))
cases[[5]] <- c("5 Edge: n = 2 per group", "Runs with small-n warning",
  sprintf("ran = %s, Shapiro not computable = %s", r$ok, all(is.na(nm$p))),
  r$ok && all(is.na(nm$p)))

r <- quiet(main_function1(data = data.frame(y = 1:6, g = c("A","A","B","B","C","C")), response = "y", group = "g"))
cases[[6]] <- c("6 Invalid: 3 groups", "Rejected (exactly 2 groups)",
  if (r$ok) "ran" else r$msg, !r$ok && grepl("exactly 2 groups", r$msg))

r <- quiet(main_function1(g1 = c("a", "b", "c"), g2 = c(1, 2, 3)))
cases[[7]] <- c("7 Invalid: non-numeric", "Rejected (must be numeric)",
  if (r$ok) "ran" else r$msg, !r$ok && grepl("numeric", r$msg))

r1 <- quiet(main_function1(g1 = c(5, 5, 5), g2 = c(1, 2, 3)))
r2 <- quiet(main_function1(g1 = c(4), g2 = c(1, 2, 3)))
cases[[8]] <- c("8 Invalid: zero var / n < 2", "Both rejected",
  sprintf("zero-var rejected = %s; n<2 rejected = %s", !r1$ok, !r2$ok),
  !r1$ok && grepl("zero variance", r1$msg) && !r2$ok && grepl("fewer than 2", r2$msg))

tab <- as.data.frame(do.call(rbind, cases), stringsAsFactors = FALSE)
names(tab) <- c("Test", "Outcome Expected", "Outcome Generated", "Match")
tab$Match <- ifelse(as.logical(tab$Match), "Yes", "No")
cat(sprintf("Correctness rate: %.1f%% (%d/%d)\n\n", 100 * mean(tab$Match == "Yes"),
            sum(tab$Match == "Yes"), nrow(tab)))
cat(knitr::kable(tab, format = "pipe"), sep = "\n")
